package com.personal.movielink

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.personal.movielink.ui.components.FallbackWebViewDialog
import com.personal.movielink.ui.dialogs.HistoryDialog
import com.personal.movielink.ui.dialogs.MyListDialog
import com.personal.movielink.ui.dialogs.SettingsDialog
import com.personal.movielink.ui.dialogs.TrailerDialog
import com.personal.movielink.ui.player.NativeVideoPlayerScreen
import com.personal.movielink.ui.screens.CatalogScreen
import com.personal.movielink.ui.screens.DetailScreen
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import com.personal.movielink.ui.theme.MovieLinkTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            MovieLinkTheme(settings = settings) {
                MovieLinkAppRoot(vm = vm, settings = settings)
            }
        }
    }
}

@Composable
private fun MovieLinkAppRoot(
    vm: MainViewModel,
    settings: UserSettings
) {
    val context = LocalContext.current
    val palette = LocalMovieLinkPalette.current

    val backStack by vm.backStack.collectAsStateWithLifecycle()
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val catalogLoading by vm.catalogLoading.collectAsStateWithLifecycle()
    val catalogError by vm.catalogError.collectAsStateWithLifecycle()

    val detail by vm.detail.collectAsStateWithLifecycle()
    val detailLoading by vm.detailLoading.collectAsStateWithLifecycle()
    val detailError by vm.detailError.collectAsStateWithLifecycle()

    val history by vm.history.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val blockedCount by vm.sessionBlockedCount.collectAsStateWithLifecycle()

    val playerRequest by vm.playerRequest.collectAsStateWithLifecycle()
    val fallbackWeb by vm.fallbackWeb.collectAsStateWithLifecycle()
    val trailerInfo by vm.trailerId.collectAsStateWithLifecycle()
    val pendingVideo by vm.pendingVideoChoice.collectAsStateWithLifecycle()
    val pendingDownloader by vm.pendingDownloaderChoice.collectAsStateWithLifecycle()

    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showMyList by remember { mutableStateOf(false) }

    val activeUa = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT

    fun routeResolvedMediaUrl(
        url: String,
        title: String,
        userAgent: String,
        contentDisposition: String?,
        mimeType: String?
    ) {
        if (DownloadAndPlayerRouter.isVideoUrl(url, mimeType)) {
            when (settings.videoActionMode) {
                Config.VideoActionMode.EXTERNAL_PLAYER -> {
                    DownloadAndPlayerRouter.launchExternalPlayer(context, url, vm.currentUrl(), userAgent, mimeType)
                    return
                }
                Config.VideoActionMode.ASK -> {
                    vm.showVideoChoice(PendingVideoChoice(url, title, userAgent, contentDisposition, mimeType))
                    return
                }
                Config.VideoActionMode.DOWNLOAD -> Unit
            }
        }
        DownloadAndPlayerRouter.launchDownloader(
            context = context,
            mode = settings.downloaderMode,
            url = url,
            referer = vm.currentUrl(),
            userAgent = userAgent,
            contentDisposition = contentDisposition,
            mimeType = mimeType,
            onNeedPicker = {
                vm.showDownloaderChoice(PendingDownloaderChoice(url, userAgent, contentDisposition, mimeType))
            }
        )
    }

    val topScreen = backStack.lastOrNull()
    BackHandler(enabled = playerRequest == null && backStack.size > 1) {
        vm.navigateBack()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = palette.pageBg
    ) {
        if (playerRequest != null) {
            NativeVideoPlayerScreen(
                request = playerRequest!!,
                settings = settings,
                httpClient = vm.httpClient,
                onClose = { vm.closePlayer() }
            )
        } else {
            when (topScreen) {
                is NavScreen.Detail -> {
                    val savedInList = myList.any { it.url == topScreen.url }
                    DetailScreen(
                        detail = detail,
                        currentUrl = topScreen.url,
                        isLoading = detailLoading,
                        errorMessage = detailError,
                        settings = settings,
                        imageLoader = vm.imageLoader,
                        isInMyList = savedInList,
                        myListCount = myList.size,
                        onBack = { vm.navigateBack() },
                        onRefresh = { vm.refreshCurrent() },
                        onWatchTrailer = { ytId ->
                            vm.openTrailer(ytId, detail?.title ?: "Trailer")
                        },
                        onToggleMyList = { d ->
                            vm.settingsStore.toggleMyList(
                                MyListItem(
                                    url = d.url,
                                    title = d.title,
                                    posterUrl = d.posterUrl,
                                    type = d.type,
                                    quality = d.quality,
                                    language = d.language,
                                    addedAt = System.currentTimeMillis()
                                )
                            )
                        },
                        onOpenMyListDialog = { showMyList = true },
                        onWatchOnline = { embedUrl, d ->
                            vm.launchPlayer(
                                PlayerLaunchRequest(
                                    streamUrl = embedUrl,
                                    title = d.title,
                                    subtitle = "${d.language} · ${d.quality}",
                                    refererUrl = d.url,
                                    isEmbedPage = true
                                )
                            )
                        },
                        onDownloadOption = { opt, d ->
                            val target = opt.decodedUrl
                            if (DownloadAndPlayerRouter.isVideoUrl(target)) {
                                routeResolvedMediaUrl(target, "${d.title} — ${opt.label}", activeUa, null, null)
                            } else {
                                // Open /file/... gateway inside fallback WebView resolver to capture direct file/stream link
                                vm.openFallbackWeb(target, "${d.title} — ${opt.label}")
                            }
                        },
                        onOpenRelated = { card ->
                            vm.openUrlSmart(card.url, card.title, card.posterUrl)
                        },
                        onOpenFallbackWeb = { url ->
                            vm.openFallbackWeb(url, detail?.title ?: "MovieLink")
                        },
                        onOpenSettings = { showSettings = true }
                    )
                }

                is NavScreen.Catalog, null -> {
                    CatalogScreen(
                        catalog = catalog,
                        isLoading = catalogLoading,
                        errorMessage = catalogError,
                        settings = settings,
                        imageLoader = vm.imageLoader,
                        myList = myList,
                        history = history,
                        onRefresh = { vm.refreshCurrent() },
                        onSearch = { q -> vm.searchCatalog(q) },
                        onOpenUrl = { u -> vm.openUrlSmart(u) },
                        onOpenMedia = { card -> vm.openUrlSmart(card.url, card.title, card.posterUrl) },
                        onOpenHistoryItem = { item -> vm.openUrlSmart(item.url, item.title, item.posterUrl) },
                        onOpenMyListItem = { item -> vm.openDetailUrl(item.url, item.title, item.posterUrl) },
                        onRemoveMyList = { url -> vm.settingsStore.removeFromMyList(url) },
                        onClearHistory = { vm.settingsStore.clearHistory() },
                        onOpenHistoryDialog = { showHistory = true },
                        onOpenFallbackWeb = { vm.openFallbackWeb(vm.currentUrl(), "MovieLink Browser") },
                        onPlayLocalVideo = { localVideoLauncher.launch("video/*") },
                        onOpenSettings = { showSettings = true }
                    )
                }
            }
        }
    }

    val localVideoLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val fileName = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Local Video" } ?: "Local Video"
            vm.launchPlayer(
                PlayerLaunchRequest(
                    streamUrl = uri.toString(),
                    title = fileName,
                    subtitle = "Local Storage Media",
                    refererUrl = "",
                    isEmbedPage = false
                )
            )
        }
    }

    if (showSettings) {
        SettingsDialog(
            settings = settings,
            currentUrl = vm.currentUrl(),
            sessionBlockedCount = blockedCount,
            onUpdateSettings = { transform -> vm.settingsStore.updateSettings(transform) },
            onReloadHome = { newUrl -> vm.openCatalogUrl(newUrl) },
            onOpenCurrentUrlInPlayer = { url ->
                val target = detail?.watchEmbedUrl ?: url
                vm.launchPlayer(
                    PlayerLaunchRequest(
                        streamUrl = target,
                        title = detail?.title ?: "MovieLink Player",
                        refererUrl = url,
                        isEmbedPage = target.contains("/p/", true)
                    )
                )
            },
            onPlayLocalVideo = {
                localVideoLauncher.launch("video/*")
            },
            onSaveCustomDomains = { blocked, allowed ->
                vm.settingsStore.setCustomDomainsRaw(blocked, allowed)
            },
            onDismiss = { showSettings = false }
        )
    }

    if (showHistory) {
        HistoryDialog(
            items = history,
            onSelect = { item -> vm.openUrlSmart(item.url, item.title, item.posterUrl) },
            onClear = { vm.settingsStore.clearHistory() },
            onDismiss = { showHistory = false }
        )
    }

    if (showMyList) {
        MyListDialog(
            items = myList,
            onSelect = { item -> vm.openDetailUrl(item.url, item.title, item.posterUrl) },
            onRemove = { url -> vm.settingsStore.removeFromMyList(url) },
            onDismiss = { showMyList = false }
        )
    }

    trailerInfo?.let { (ytId, title) ->
        TrailerDialog(
            youtubeId = ytId,
            title = title,
            onDismiss = { vm.closeTrailer() }
        )
    }

    fallbackWeb?.let { req ->
        FallbackWebViewDialog(
            initialUrl = req.url,
            title = req.title,
            settings = settings,
            isCloudflareChallenge = req.isCloudflareChallenge,
            onCloudflareSolved = { vm.onCloudflareSolved() },
            onPlayUrl = { playUrl ->
                vm.closeFallbackWeb()
                vm.launchPlayer(
                    PlayerLaunchRequest(
                        streamUrl = playUrl,
                        title = req.title,
                        refererUrl = vm.currentUrl(),
                        isEmbedPage = !DownloadAndPlayerRouter.isVideoUrl(playUrl)
                    )
                )
            },
            onDownloadDetected = { hit ->
                vm.closeFallbackWeb()
                routeResolvedMediaUrl(hit.url, req.title, hit.userAgent, hit.contentDisposition, hit.mimeType)
            },
            onDismiss = { vm.closeFallbackWeb() }
        )
    }

    pendingVideo?.let { choice ->
        AlertDialog(
            onDismissRequest = { vm.dismissVideoChoice() },
            containerColor = palette.cardBg,
            titleContentColor = palette.textPrimary,
            title = { Text("Video Stream Detected", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            vm.dismissVideoChoice()
                            vm.launchPlayer(
                                PlayerLaunchRequest(
                                    streamUrl = choice.url,
                                    title = choice.title,
                                    refererUrl = vm.currentUrl(),
                                    isEmbedPage = false
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Play in Built-in ExoPlayer", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissVideoChoice()
                            DownloadAndPlayerRouter.launchExternalPlayer(
                                context, choice.url, vm.currentUrl(), choice.userAgent, choice.mimeType
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Play in VLC / MX Player", color = palette.textPrimary)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissVideoChoice()
                            DownloadAndPlayerRouter.launchDownloader(
                                context,
                                settings.downloaderMode,
                                choice.url,
                                vm.currentUrl(),
                                choice.userAgent,
                                choice.contentDisposition,
                                choice.mimeType,
                                onNeedPicker = {
                                    vm.showDownloaderChoice(
                                        PendingDownloaderChoice(choice.url, choice.userAgent, choice.contentDisposition, choice.mimeType)
                                    )
                                }
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Download File", color = palette.textPrimary)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissVideoChoice()
                            DownloadAndPlayerRouter.openInChrome(context, choice.url)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open in Chrome", color = palette.textSecondary)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.dismissVideoChoice() }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }

    pendingDownloader?.let { dl ->
        val installed = DownloadAndPlayerRouter.installedDownloaders(context)
        AlertDialog(
            onDismissRequest = { vm.dismissDownloaderChoice() },
            containerColor = palette.cardBg,
            titleContentColor = palette.textPrimary,
            title = { Text("Choose Downloader", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    installed.forEach { app ->
                        Button(
                            onClick = {
                                vm.dismissDownloaderChoice()
                                DownloadAndPlayerRouter.launchSpecificDownloader(
                                    context, app.packageName, dl.url, vm.currentUrl(), dl.userAgent, dl.contentDisposition, dl.mimeType
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = palette.fg, contentColor = palette.onAccent),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Download with ${app.label}", fontWeight = FontWeight.Bold)
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissDownloaderChoice()
                            DownloadAndPlayerRouter.launchSpecificDownloader(
                                context, null, dl.url, vm.currentUrl(), dl.userAgent, dl.contentDisposition, dl.mimeType
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Android Built-in DownloadManager", color = palette.textPrimary)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.dismissDownloaderChoice()
                            DownloadAndPlayerRouter.openInChrome(context, dl.url)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open in Chrome", color = palette.textSecondary)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.dismissDownloaderChoice() }) {
                    Text("Cancel", color = palette.textSecondary)
                }
            }
        )
    }
}
