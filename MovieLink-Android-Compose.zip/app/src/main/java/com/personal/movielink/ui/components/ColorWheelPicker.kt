package com.personal.movielink.ui.components

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.movielink.Config
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

@Composable
fun ColorWheelDialog(
    title: String,
    initialHex: String,
    minBrightness: Float = 0.04f,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val initialHsv = remember(initialHex) {
        val arr = FloatArray(3)
        try {
            AndroidColor.colorToHSV(AndroidColor.parseColor(initialHex), arr)
        } catch (_: Exception) {
            arr[0] = 200f; arr[1] = 0.7f; arr[2] = 0.85f
        }
        if (arr[2] < minBrightness) arr[2] = minBrightness
        arr
    }

    var hue by remember { mutableFloatStateOf(initialHsv[0]) }
    var sat by remember { mutableFloatStateOf(initialHsv[1]) }
    var brightness by remember { mutableFloatStateOf(initialHsv[2]) }

    val selectedInt = remember(hue, sat, brightness) {
        AndroidColor.HSVToColor(floatArrayOf(hue, sat, brightness))
    }
    val selectedHex = remember(selectedInt) { Config.toHex(selectedInt) }
    val selectedComposeColor = remember(selectedInt) { Color(selectedInt) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        textContentColor = palette.textPrimary,
        title = {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(selectedComposeColor)
                            .border(1.5.dp, palette.boxBorder, RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = selectedHex,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = palette.textPrimary
                    )
                }

                HsvColorWheel(
                    hue = hue,
                    sat = sat,
                    brightness = brightness,
                    onHueSatChange = { h, s ->
                        hue = h
                        sat = s
                    },
                    modifier = Modifier.size(220.dp)
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Brightness", fontSize = 12.sp, color = palette.textSecondary)
                        Text(
                            text = "${(brightness * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = palette.textPrimary
                        )
                    }
                    Slider(
                        value = brightness,
                        onValueChange = { brightness = it.coerceIn(minBrightness, 1f) },
                        valueRange = minBrightness..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = palette.fg,
                            activeTrackColor = palette.fg
                        ),
                        modifier = Modifier.height(36.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(selectedHex) }) {
                Text("Apply", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
private fun HsvColorWheel(
    hue: Float,
    sat: Float,
    brightness: Float,
    onHueSatChange: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val hueColors = remember(brightness) {
        val stops = listOf(0f, 60f, 120f, 180f, 240f, 300f, 360f)
        stops.map { h ->
            Color(AndroidColor.HSVToColor(floatArrayOf(h % 360f, 1f, brightness)))
        }
    }
    val centerWhite = remember(brightness) {
        Color(AndroidColor.HSVToColor(floatArrayOf(0f, 0f, brightness)))
    }

    Canvas(
        modifier = modifier
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val radius = (min(size.width, size.height) / 2f) - 12f
                    if (radius > 0f) {
                        val dx = offset.x - cx
                        val dy = offset.y - cy
                        val dist = min(hypot(dx, dy), radius)
                        var angle = Math.toDegrees(atan2(-dy.toDouble(), dx.toDouble())).toFloat()
                        if (angle < 0f) angle += 360f
                        onHueSatChange(angle, (dist / radius).coerceIn(0f, 1f))
                    }
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    change.consume()
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val radius = (min(size.width, size.height) / 2f) - 12f
                    if (radius > 0f) {
                        val dx = change.position.x - cx
                        val dy = change.position.y - cy
                        val dist = min(hypot(dx, dy), radius)
                        var angle = Math.toDegrees(atan2(-dy.toDouble(), dx.toDouble())).toFloat()
                        if (angle < 0f) angle += 360f
                        onHueSatChange(angle, (dist / radius).coerceIn(0f, 1f))
                    }
                }
            }
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = (min(size.width, size.height) / 2f) - 12f
        if (radius <= 0f) return@Canvas

        // Note: Compose sweepGradient starts at 3 o'clock and goes clockwise, whereas atan2(-dy, dx) goes counter-clockwise.
        // Reversing stops aligns visual wheel angle with mathematical hue angle cleanly.
        drawCircle(
            brush = Brush.sweepGradient(colors = hueColors.reversed(), center = Offset(cx, cy)),
            radius = radius,
            center = Offset(cx, cy)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(centerWhite, Color.Transparent),
                center = Offset(cx, cy),
                radius = radius
            ),
            radius = radius,
            center = Offset(cx, cy)
        )
        drawCircle(
            color = Color(0xFF3F3F46),
            radius = radius,
            center = Offset(cx, cy),
            style = Stroke(width = 3f)
        )

        val rad = Math.toRadians((-hue).toDouble())
        val dist = sat * radius
        val px = (cx + dist * cos(rad)).toFloat()
        val py = (cy + dist * sin(rad)).toFloat()

        drawCircle(
            color = Color(0x99000000),
            radius = 15f,
            center = Offset(px, py),
            style = Stroke(width = 5f)
        )
        drawCircle(
            color = Color.White,
            radius = 15f,
            center = Offset(px, py),
            style = Stroke(width = 3f)
        )
    }
}
