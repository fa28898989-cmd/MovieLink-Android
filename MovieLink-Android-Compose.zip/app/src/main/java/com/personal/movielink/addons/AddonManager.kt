package com.personal.movielink.addons

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

class AddonManager(
    context: Context,
    private val manifestRepository: AddonManifestRepository = AddonManifestRepository()
) {
    private val sp = context.getSharedPreferences("movielink_addons_prefs", Context.MODE_PRIVATE)

    private val _addons = MutableStateFlow(readAddonsSync())
    val addons: StateFlow<List<InstalledAddon>> = _addons.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    suspend fun installAddon(rawUrl: String): Result<InstalledAddon> {
        _isBusy.value = true
        return try {
            val res = manifestRepository.fetchAndValidateManifest(rawUrl)
            res.onSuccess { fetched ->
                val current = _addons.value
                val existing = current.firstOrNull {
                    it.manifestUrl.equals(fetched.manifestUrl, ignoreCase = true) ||
                        it.id.equals(fetched.id, ignoreCase = true)
                }
                val merged = if (existing != null) {
                    val keepEnabled = existing.enabled
                    val nextStatus = when {
                        !keepEnabled -> AddonConnectionStatus.DISABLED
                        fetched.manifest.behaviorHints.configurationRequired -> AddonConnectionStatus.CONFIG_REQUIRED
                        else -> AddonConnectionStatus.CONNECTED
                    }
                    fetched.copy(enabled = keepEnabled, status = nextStatus)
                } else {
                    fetched
                }
                val nextList = current
                    .filterNot {
                        it.manifestUrl.equals(merged.manifestUrl, ignoreCase = true) ||
                            it.id.equals(merged.id, ignoreCase = true)
                    } + merged
                saveAddons(nextList)
            }
            res
        } finally {
            _isBusy.value = false
        }
    }

    fun setAddonEnabled(manifestUrl: String, enabled: Boolean) {
        val next = _addons.value.map { addon ->
            if (addon.manifestUrl == manifestUrl) {
                val nextStatus = when {
                    !enabled -> AddonConnectionStatus.DISABLED
                    addon.manifest.behaviorHints.configurationRequired -> AddonConnectionStatus.CONFIG_REQUIRED
                    addon.lastError != null -> AddonConnectionStatus.UNREACHABLE
                    else -> AddonConnectionStatus.CONNECTED
                }
                addon.copy(enabled = enabled, status = nextStatus)
            } else {
                addon
            }
        }
        saveAddons(next)
    }

    fun removeAddon(manifestUrl: String) {
        saveAddons(_addons.value.filterNot { it.manifestUrl == manifestUrl })
    }

    suspend fun refreshAddon(manifestUrl: String): Result<InstalledAddon> {
        _isBusy.value = true
        return try {
            val existing = _addons.value.firstOrNull { it.manifestUrl == manifestUrl }
                ?: return Result.failure(IllegalArgumentException("Addon not found"))
            val res = manifestRepository.fetchAndValidateManifest(manifestUrl)
            res.fold(
                onSuccess = { fresh ->
                    val status = when {
                        !existing.enabled -> AddonConnectionStatus.DISABLED
                        fresh.manifest.behaviorHints.configurationRequired -> AddonConnectionStatus.CONFIG_REQUIRED
                        else -> AddonConnectionStatus.CONNECTED
                    }
                    val updated = fresh.copy(enabled = existing.enabled, status = status, lastError = null)
                    saveAddons(_addons.value.map { if (it.manifestUrl == manifestUrl) updated else it })
                    Result.success(updated)
                },
                onFailure = { err ->
                    val updated = existing.copy(
                        status = if (existing.enabled) AddonConnectionStatus.UNREACHABLE else AddonConnectionStatus.DISABLED,
                        lastError = err.message ?: "Connection failed",
                        lastCheckedAt = System.currentTimeMillis()
                    )
                    saveAddons(_addons.value.map { if (it.manifestUrl == manifestUrl) updated else it })
                    Result.failure(err)
                }
            )
        } finally {
            _isBusy.value = false
        }
    }

    suspend fun refreshAllAddons() {
        val snapshot = _addons.value
        for (addon in snapshot) {
            refreshAddon(addon.manifestUrl)
        }
    }

    fun enabledAddons(): List<InstalledAddon> =
        _addons.value.filter { it.enabled }

    private fun saveAddons(list: List<InstalledAddon>) {
        _addons.value = list
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY_ADDONS_JSON, arr.toString()).apply()
    }

    private fun readAddonsSync(): List<InstalledAddon> {
        val raw = sp.getString(KEY_ADDONS_JSON, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    InstalledAddon.fromJson(obj)?.let { add(it) }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val KEY_ADDONS_JSON = "installed_addons_json"
    }
}
