package com.personal.movielink.addons

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

enum class StreamType {
    DIRECT_VIDEO,
    EXTERNAL_URL,
    TORRENT_INFO_HASH,
    UNSUPPORTED
}

data class StremioProxyHeaders(
    val requestHeaders: Map<String, String> = emptyMap()
) {
    companion object {
        fun fromJson(obj: JSONObject?): StremioProxyHeaders? {
            if (obj == null) return null
            val map = mutableMapOf<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.optString(k, "").trim()
                if (k.isNotBlank() && v.isNotEmpty()) {
                    map[k] = v
                }
            }
            return if (map.isNotEmpty()) StremioProxyHeaders(map) else null
        }
    }
}

data class StremioStreamItem(
    val streamId: String,
    val addonManifestUrl: String,
    val addonName: String,
    val title: String,
    val name: String,
    val description: String,
    val quality: String,
    val language: String,
    val url: String?,
    val externalUrl: String?,
    val infoHash: String?,
    val fileIdx: Int?,
    val streamType: StreamType,
    val proxyHeaders: StremioProxyHeaders? = null,
    val rawStreamJson: JSONObject
)

data class AddonSubtitleItem(
    val id: String,
    val lang: String,
    val url: String,
    val addonName: String
)

data class AddonStreamGroupResult(
    val addonManifestUrl: String,
    val addonName: String,
    val streams: List<StremioStreamItem> = emptyList(),
    val subtitles: List<AddonSubtitleItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

class AddonStreamRepository {

    private data class StreamCacheEntry(
        val fetchedAtMs: Long,
        val streams: List<StremioStreamItem>,
        val subtitles: List<AddonSubtitleItem>
    )

    private val cache = ConcurrentHashMap<String, StreamCacheEntry>()

    fun buildStreamUrl(addon: InstalledAddon, type: String, streamId: String): String {
        val typeSeg = Uri.encode(type.trim().ifBlank { "movie" })
        val idSeg = Uri.encode(streamId.trim())
        val basePath = "${addon.baseUrl.trimEnd('/')}/stream/$typeSeg/$idSeg.json"
        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    fun buildSubtitleUrl(addon: InstalledAddon, type: String, streamId: String): String {
        val typeSeg = Uri.encode(type.trim().ifBlank { "movie" })
        val idSeg = Uri.encode(streamId.trim())
        val basePath = "${addon.baseUrl.trimEnd('/')}/subtitles/$typeSeg/$idSeg.json"
        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    suspend fun fetchStreamsForAddon(
        addon: InstalledAddon,
        type: String,
        streamId: String,
        forceRefresh: Boolean = false
    ): Result<Pair<List<StremioStreamItem>, List<AddonSubtitleItem>>> {
        if (!addon.enabled) {
            return Result.failure(IllegalStateException("${addon.manifest.name} is disabled"))
        }
        val cleanType = type.trim().ifBlank { "movie" }
        val cleanId = streamId.trim()
        if (cleanId.isBlank()) {
            return Result.failure(IllegalArgumentException("Missing stream identifier"))
        }
        if (!addon.manifest.supportsResource("stream", cleanType, cleanId)) {
            return Result.failure(UnsupportedOperationException("${addon.manifest.name} does not support stream for $cleanType"))
        }

        val cacheKey = "${addon.manifestUrl}|$cleanType|$cleanId"
        if (!forceRefresh) {
            val cached = cache[cacheKey]
            if (cached != null && System.currentTimeMillis() - cached.fetchedAtMs < CACHE_TTL_MS) {
                return Result.success(cached.streams to cached.subtitles)
            }
        }

        return try {
            val streamUrl = buildStreamUrl(addon, cleanType, cleanId)
            val streamJson = AddonHttp.getJsonObject(streamUrl)
            val streamsArr = streamJson.optJSONArray("streams") ?: JSONArray()
            val parsedStreams = buildList {
                for (i in 0 until streamsArr.length()) {
                    val sObj = streamsArr.optJSONObject(i) ?: continue
                    val parsed = parseStreamItem(sObj, addon)
                    if (parsed != null) add(parsed)
                }
            }

            val parsedSubtitles = mutableListOf<AddonSubtitleItem>()
            if (addon.manifest.supportsResource("subtitles", cleanType, cleanId)) {
                try {
                    val subUrl = buildSubtitleUrl(addon, cleanType, cleanId)
                    val subJson = AddonHttp.getJsonObject(subUrl)
                    val subsArr = subJson.optJSONArray("subtitles") ?: JSONArray()
                    for (i in 0 until subsArr.length()) {
                        val subObj = subsArr.optJSONObject(i) ?: continue
                        val subUrlStr = sanitizeHttpUrl(subObj.optString("url", ""))
                        val subLang = subObj.optString("lang", subObj.optString("id", "English")).trim()
                        if (subUrlStr.isNotBlank()) {
                            parsedSubtitles.add(
                                AddonSubtitleItem(
                                    id = subObj.optString("id", "sub_$i"),
                                    lang = subLang.ifBlank { "English" },
                                    url = subUrlStr,
                                    addonName = addon.manifest.name
                                )
                            )
                        }
                    }
                } catch (_: Exception) {
                    // Subtitles endpoint optional; do not fail streams
                }
            }

            if (cache.size > MAX_CACHE_ENTRIES) cache.clear()
            cache[cacheKey] = StreamCacheEntry(System.currentTimeMillis(), parsedStreams, parsedSubtitles)
            Result.success(parsedStreams to parsedSubtitles)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun clearCache() {
        cache.clear()
    }

    private fun parseStreamItem(obj: JSONObject, addon: InstalledAddon): StremioStreamItem? {
        val url = sanitizeHttpUrl(obj.optString("url", ""))
        val externalUrl = sanitizeHttpUrl(obj.optString("externalUrl", ""))
        val infoHash = obj.optString("infoHash", "").trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
        val fileIdx = if (obj.has("fileIdx") && !obj.isNull("fileIdx")) obj.optInt("fileIdx") else null

        val title = obj.optString("title", obj.optString("name", "")).trim()
        val name = obj.optString("name", addon.manifest.name).trim().ifBlank { addon.manifest.name }
        val description = obj.optString("description", obj.optString("behaviorHints", "")).trim()

        val proxyHeaders = StremioProxyHeaders.fromJson(
            obj.optJSONObject("behaviorHints")?.optJSONObject("proxyHeaders")
                ?: obj.optJSONObject("proxyHeaders")
        )

        val streamType = when {
            url.isNotBlank() -> {
                val low = url.lowercase()
                if (low.startsWith("http://") || low.startsWith("https://") || low.startsWith("content://")) {
                    StreamType.DIRECT_VIDEO
                } else {
                    StreamType.UNSUPPORTED
                }
            }
            externalUrl.isNotBlank() -> StreamType.EXTERNAL_URL
            infoHash != null -> StreamType.TORRENT_INFO_HASH
            else -> StreamType.UNSUPPORTED
        }

        val quality = extractQuality(listOf(title, description, name))
        val language = extractLanguage(listOf(title, description))

        return StremioStreamItem(
            streamId = obj.optString("id", title.hashCode().toString()),
            addonManifestUrl = addon.manifestUrl,
            addonName = addon.manifest.name,
            title = title,
            name = name,
            description = description,
            quality = quality,
            language = language,
            url = url.takeIf { it.isNotBlank() },
            externalUrl = externalUrl.takeIf { it.isNotBlank() },
            infoHash = infoHash,
            fileIdx = fileIdx,
            streamType = streamType,
            proxyHeaders = proxyHeaders,
            rawStreamJson = obj
        )
    }

    private fun extractQuality(texts: List<String>): String {
        val combined = texts.joinToString(" ").uppercase()
        return when {
            "2160P" in combined || "4K" in combined || "UHD" in combined -> "4K UHD"
            "1080P" in combined || "FHD" in combined -> "1080p FHD"
            "720P" in combined || "HD" in combined -> "720p HD"
            "480P" in combined || "SD" in combined -> "480p SD"
            else -> "HD"
        }
    }

    private fun extractLanguage(texts: List<String>): String {
        val combined = texts.joinToString(" ").lowercase()
        return when {
            "dual" in combined -> "Dual Audio"
            "hindi" in combined -> "Hindi"
            "bengali" in combined || "bangla" in combined -> "Bangla"
            "english" in combined -> "English"
            "korean" in combined -> "Korean"
            "japanese" in combined -> "Japanese"
            "spanish" in combined -> "Spanish"
            "french" in combined -> "French"
            else -> ""
        }
    }

    private fun sanitizeHttpUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isEmpty() || clean.equals("null", true)) return ""
        return if (clean.startsWith("http://", true) ||
            clean.startsWith("https://", true) ||
            clean.startsWith("magnet://", true) ||
            clean.startsWith("content://", true)
        ) {
            clean
        } else {
            ""
        }
    }

    companion object {
        private const val CACHE_TTL_MS = 3 * 60 * 1000L
        private const val MAX_CACHE_ENTRIES = 50
    }
}
