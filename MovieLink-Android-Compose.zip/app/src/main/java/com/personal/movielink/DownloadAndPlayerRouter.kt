package com.personal.movielink

import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.widget.Toast

object DownloadAndPlayerRouter {

    fun isVideoUrl(url: String, mime: String? = null): Boolean {
        if (!mime.isNullOrBlank() && mime.startsWith("video/", ignoreCase = true)) return true
        val path = url.substringBefore('?').substringBefore('#').lowercase()
        return path.endsWith(".mp4") ||
            path.endsWith(".mkv") ||
            path.endsWith(".webm") ||
            path.endsWith(".m3u8") ||
            path.endsWith(".mpd") ||
            path.endsWith(".avi") ||
            path.endsWith(".mov") ||
            path.endsWith(".ts")
    }

    fun isPackageInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun installedDownloaders(context: Context): List<Config.AppOption> =
        Config.DOWNLOAD_APPS.filter { isPackageInstalled(context, it.packageName) }
            .distinctBy { it.label }

    fun installedPlayers(context: Context): List<Config.AppOption> =
        Config.PLAYER_APPS.filter { isPackageInstalled(context, it.packageName) }

    fun openInChrome(context: Context, url: String) {
        val uri = Uri.parse(url)
        if (tryLaunchPackage(context, "com.android.chrome", uri)) return
        openExternal(context, url)
    }

    fun openExternal(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "No compatible app found to open link", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchDownloader(
        context: Context,
        mode: Config.DownloaderMode,
        url: String,
        referer: String,
        userAgent: String,
        contentDisposition: String? = null,
        mimeType: String? = null,
        onNeedPicker: (() -> Unit)? = null
    ) {
        val uri = Uri.parse(url)
        when (mode) {
            Config.DownloaderMode.AUTO -> {
                for (app in Config.DOWNLOAD_APPS) {
                    if (tryLaunchPackage(context, app.packageName, uri)) return
                }
                enqueueBuiltInDownload(context, uri, url, referer, userAgent, contentDisposition, mimeType)
            }
            Config.DownloaderMode.IDM_PLUS,
            Config.DownloaderMode.IDM -> {
                val pkg = mode.packageName
                if (pkg != null && tryLaunchPackage(context, pkg, uri)) return
                Toast.makeText(context, "${mode.label} not installed — using built-in downloader", Toast.LENGTH_SHORT).show()
                enqueueBuiltInDownload(context, uri, url, referer, userAgent, contentDisposition, mimeType)
            }
            Config.DownloaderMode.ADM -> {
                val admPackages = listOf("idm.internet.download.manager.adm.lite", "com.dv.adm")
                if (admPackages.any { tryLaunchPackage(context, it, uri) }) return
                Toast.makeText(context, "ADM not installed — using built-in downloader", Toast.LENGTH_SHORT).show()
                enqueueBuiltInDownload(context, uri, url, referer, userAgent, contentDisposition, mimeType)
            }
            Config.DownloaderMode.BUILTIN -> {
                enqueueBuiltInDownload(context, uri, url, referer, userAgent, contentDisposition, mimeType)
            }
            Config.DownloaderMode.ASK -> {
                if (onNeedPicker != null) {
                    onNeedPicker()
                } else {
                    enqueueBuiltInDownload(context, uri, url, referer, userAgent, contentDisposition, mimeType)
                }
            }
        }
    }

    fun launchSpecificDownloader(
        context: Context,
        packageName: String?,
        url: String,
        referer: String,
        userAgent: String,
        contentDisposition: String? = null,
        mimeType: String? = null
    ) {
        val uri = Uri.parse(url)
        if (packageName != null && tryLaunchPackage(context, packageName, uri)) return
        enqueueBuiltInDownload(context, uri, url, referer, userAgent, contentDisposition, mimeType)
    }

    fun launchExternalPlayer(
        context: Context,
        url: String,
        referer: String,
        userAgent: String,
        mimeType: String? = null,
        packageName: String? = null,
        extraHeaders: Map<String, String> = emptyMap()
    ): Boolean {
        val uri = Uri.parse(url)
        val videoMime = if (!mimeType.isNullOrBlank() && mimeType.startsWith("video/", true)) mimeType else "video/*"
        val mergedHeaders = linkedMapOf<String, String>()
        extraHeaders.forEach { (k, v) ->
            if (k.isNotBlank() && v.isNotBlank()) mergedHeaders[k] = v
        }
        if (referer.isNotBlank() && mergedHeaders.keys.none { it.equals("Referer", ignoreCase = true) }) {
            mergedHeaders["Referer"] = referer
        }
        if (userAgent.isNotBlank() && mergedHeaders.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
            mergedHeaders["User-Agent"] = userAgent
        }
        val headers = mergedHeaders.entries.flatMap { (k, v) -> listOf(k, v) }.toTypedArray()

        if (packageName != null) {
            return tryLaunchPackage(context, packageName, uri, videoMime, headers)
        }

        val installed = installedPlayers(context)
        for (app in installed) {
            if (tryLaunchPackage(context, app.packageName, uri, videoMime, headers)) return true
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, videoMime)
                if (headers.isNotEmpty()) putExtra("headers", headers)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Open video with"))
            true
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, "No external video player found (install VLC or MX Player)", Toast.LENGTH_SHORT).show()
            false
        }
    }

    fun tryLaunchPackage(
        context: Context,
        pkg: String,
        uri: Uri,
        mimeType: String? = null,
        headers: Array<String>? = null
    ): Boolean {
        if (!isPackageInstalled(context, pkg)) return false
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                if (mimeType != null) setDataAndType(uri, mimeType) else data = uri
                setPackage(pkg)
                if (headers != null) {
                    putExtra("headers", headers)
                }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun enqueueBuiltInDownload(
        context: Context,
        uri: Uri,
        url: String,
        referer: String,
        userAgent: String,
        contentDisposition: String? = null,
        mimeType: String? = null
    ) {
        try {
            val req = DownloadManager.Request(uri)
            if (!mimeType.isNullOrBlank()) req.setMimeType(mimeType)
            CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }?.let {
                req.addRequestHeader("Cookie", it)
            }
            req.addRequestHeader("User-Agent", userAgent)
            req.addRequestHeader("Referer", referer)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(context, "Downloading $fileName…", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            openExternal(context, url)
        }
    }
}
