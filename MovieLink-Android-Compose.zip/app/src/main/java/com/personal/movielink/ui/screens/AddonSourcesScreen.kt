package com.personal.movielink.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.addons.AddonStreamGroupResult
import com.personal.movielink.addons.StremioStreamItem
import com.personal.movielink.addons.StreamType
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddonSourcesScreen(
    contentType: String,
    streamId: String,
    title: String,
    subtitle: String,
    posterUrl: String,
    groupResults: List<AddonStreamGroupResult>,
    isLoadingAny: Boolean,
    imageLoader: ImageLoader,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    onSelectStream: (StremioStreamItem) -> Unit,
    onOpenExternalUrl: (String) -> Unit,
    onRetryGroup: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val totalStreams = groupResults.sumOf { it.streams.size }
    val totalSubtitles = groupResults.sumOf { it.subtitles.size }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = palette.textPrimary
                )
            }
            Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
                Text(
                    text = "Addon Sources",
                    color = palette.textPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = title.ifBlank { streamId },
                    color = palette.fg,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onRefresh) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "Refresh",
                    tint = palette.textPrimary
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = "Settings",
                    tint = palette.fg
                )
            }
        }

        PullToRefreshBox(
            isRefreshing = isLoadingAny && totalStreams == 0,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, top = 8.dp, end = 16.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Banner summary card
                item(key = "source_summary_card") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.cardBg)
                            .border(1.dp, palette.border.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (posterUrl.isNotBlank()) {
                            AsyncImage(
                                model = posterUrl,
                                imageLoader = imageLoader,
                                contentDescription = title,
                                modifier = Modifier
                                    .size(54.dp, 76.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(palette.altBg)
                            )
                        }
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = title,
                                color = palette.textPrimary,
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (subtitle.isNotBlank()) {
                                Text(
                                    text = subtitle,
                                    color = palette.fg,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = "${groupResults.size} enabled addons · $totalStreams streams · $totalSubtitles subtitles",
                                color = palette.textSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (isLoadingAny && totalStreams == 0 && groupResults.all { it.isLoading }) {
                    item(key = "global_loading") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(color = palette.fg)
                                Text(
                                    text = "Querying streams from enabled Stremio addons…",
                                    color = palette.textSecondary,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                } else if (groupResults.isEmpty()) {
                    item(key = "no_addons_enabled") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No enabled Stremio addons available. Install addons in Settings.",
                                color = palette.textSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    items(
                        items = groupResults,
                        key = { it.addonManifestUrl }
                    ) { group ->
                        AddonGroupSection(
                            group = group,
                            imageLoader = imageLoader,
                            onSelectStream = onSelectStream,
                            onOpenExternalUrl = onOpenExternalUrl,
                            onRetry = { onRetryGroup(group.addonManifestUrl) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddonGroupSection(
    group: AddonStreamGroupResult,
    imageLoader: ImageLoader,
    onSelectStream: (StremioStreamItem) -> Unit,
    onOpenExternalUrl: (String) -> Unit,
    onRetry: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Group Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = group.addonName,
                    color = palette.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (group.isLoading) {
                        "Fetching streams…"
                    } else if (group.streams.isEmpty()) {
                        "No streams returned"
                    } else {
                        "${group.streams.size} streams${if (group.subtitles.isNotEmpty()) " · ${group.subtitles.size} subs" else ""}"
                    },
                    color = palette.textSecondary,
                    fontSize = 11.sp
                )
            }

            if (group.isLoading) {
                CircularProgressIndicator(
                    color = palette.fg,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(18.dp)
                )
            } else if (group.error != null) {
                OutlinedButton(
                    onClick = onRetry,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("Retry", color = palette.fg, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (group.error != null && group.streams.isEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = group.error,
                    color = Color(0xFFF87171),
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "If this persists, check addon configuration, internet connection, or try another addon.",
                    color = palette.textSecondary,
                    fontSize = 10.5.sp
                )
            }
        } else if (group.streams.isNotEmpty()) {
            val playableCount = group.streams.count { it.streamType == StreamType.DIRECT_VIDEO }
            val torrentOnlyCount = group.streams.count { it.streamType == StreamType.TORRENT_INFO_HASH }
            if (playableCount == 0 && torrentOnlyCount > 0) {
                Text(
                    text = "Addon returned torrent InfoHash entries only. Direct HTTP streaming requires a Debrid-configured or HTTP-stream addon.",
                    color = Color(0xFFF59E0B),
                    fontSize = 11.sp
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                group.streams.forEach { stream ->
                    StreamRowCard(
                        stream = stream,
                        onSelect = { onSelectStream(stream) },
                        onOpenExternal = { ext -> onOpenExternalUrl(ext) }
                    )
                }
            }
        }
    }
}

@Composable
private fun StreamRowCard(
    stream: StremioStreamItem,
    onSelect: () -> Unit,
    onOpenExternal: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current
    val isPlayable = stream.streamType == StreamType.DIRECT_VIDEO && !stream.url.isNullOrBlank()
    val isExternal = stream.streamType == StreamType.EXTERNAL_URL && !stream.externalUrl.isNullOrBlank()
    val isDash = stream.mimeHint == "application/dash+xml"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(palette.altBg)
            .border(1.dp, palette.border.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .then(
                when {
                    isPlayable -> Modifier.clickable(onClick = onSelect)
                    isExternal -> Modifier.clickable(onClick = { onOpenExternal(stream.externalUrl.orEmpty()) })
                    else -> Modifier
                }
            )
            .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (stream.quality.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(palette.fg)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = stream.quality,
                            color = palette.onAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
                if (stream.language.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(palette.cardBg)
                            .border(1.dp, palette.border.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = stream.language,
                            color = palette.textPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                val formatLabel = when (stream.mimeHint) {
                    "application/x-mpegURL" -> "HLS"
                    "application/dash+xml" -> "DASH"
                    "video/x-matroska" -> "MKV"
                    "video/mp4" -> "MP4"
                    else -> null
                }
                if (formatLabel != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(palette.cardBg)
                            .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = formatLabel,
                            color = palette.fg,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                if (stream.proxyHeaders?.requestHeaders?.isNotEmpty() == true) {
                    Text(
                        text = "Headers",
                        color = palette.textSecondary,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Text(
                text = stream.title.ifBlank { stream.name },
                color = palette.textPrimary,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (stream.description.isNotBlank()) {
                Text(
                    text = stream.description,
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            } else if (stream.streamType == StreamType.TORRENT_INFO_HASH) {
                Text(
                    text = "Torrent Stream (InfoHash) — playback requires Debrid or torrent engine addon",
                    color = Color(0xFFF59E0B),
                    fontSize = 10.5.sp
                )
            } else if (stream.streamType == StreamType.UNSUPPORTED) {
                Text(
                    text = "Unsupported stream payload (missing playable HTTP/HTTPS URL)",
                    color = Color(0xFFF87171),
                    fontSize = 10.5.sp
                )
            }
            if (isDash) {
                Text(
                    text = "DASH stream — use external player (VLC / MX) if built-in playback fails",
                    color = Color(0xFFF59E0B),
                    fontSize = 10.sp
                )
            }
        }

        if (isPlayable) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val hdrs = stream.proxyHeaders?.requestHeaders.orEmpty()
                        val ref = hdrs.entries.firstOrNull { it.key.equals("Referer", true) }?.value.orEmpty()
                        val ua = hdrs.entries.firstOrNull { it.key.equals("User-Agent", true) }?.value
                            ?: Config.MOBILE_USER_AGENT
                        DownloadAndPlayerRouter.launchExternalPlayer(
                            context = context,
                            url = stream.url.orEmpty(),
                            referer = ref,
                            userAgent = ua,
                            mimeType = stream.mimeHint,
                            extraHeaders = hdrs
                        )
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInNew,
                        contentDescription = "Open in VLC / MX Player",
                        tint = palette.fg,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Button(
                    onClick = onSelect,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.fg,
                        contentColor = palette.onAccent
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Play", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        } else if (isExternal) {
            OutlinedButton(
                onClick = { onOpenExternal(stream.externalUrl.orEmpty()) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Text("Open", color = palette.fg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
