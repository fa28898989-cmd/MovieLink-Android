package com.personal.movielink.addons

import android.content.Context
import com.personal.movielink.CatalogSection
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class UnifiedHomeCatalogEntry(
    val key: String,
    val provider: ContentProviderKind,
    val title: String,
    val enabled: Boolean,
    val movieLinkSectionTitle: String? = null,
    val addonManifestUrl: String? = null,
    val addonName: String? = null,
    val addonCatalogType: String? = null,
    val addonCatalogId: String? = null,
    val isAvailable: Boolean = true,
    val availabilityNote: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("key", key)
        put("provider", provider.name)
        put("title", title)
        put("enabled", enabled)
        if (movieLinkSectionTitle != null) put("movieLinkSectionTitle", movieLinkSectionTitle)
        if (addonManifestUrl != null) put("addonManifestUrl", addonManifestUrl)
        if (addonName != null) put("addonName", addonName)
        if (addonCatalogType != null) put("addonCatalogType", addonCatalogType)
        if (addonCatalogId != null) put("addonCatalogId", addonCatalogId)
    }

    companion object {
        fun fromJson(obj: JSONObject): UnifiedHomeCatalogEntry? {
            val key = obj.optString("key", "").trim()
            val title = obj.optString("title", "").trim()
            val providerName = obj.optString("provider", "")
            val provider = ContentProviderKind.entries.firstOrNull { it.name == providerName }
                ?: return null
            if (key.isBlank() || title.isBlank()) return null

            return UnifiedHomeCatalogEntry(
                key = key,
                provider = provider,
                title = title,
                enabled = obj.optBoolean("enabled", false),
                movieLinkSectionTitle = obj.optString("movieLinkSectionTitle", "").takeIf { it.isNotBlank() },
                addonManifestUrl = obj.optString("addonManifestUrl", "").takeIf { it.isNotBlank() },
                addonName = obj.optString("addonName", "").takeIf { it.isNotBlank() },
                addonCatalogType = obj.optString("addonCatalogType", "").takeIf { it.isNotBlank() },
                addonCatalogId = obj.optString("addonCatalogId", "").takeIf { it.isNotBlank() },
                isAvailable = true,
                availabilityNote = null
            )
        }
    }
}

class UnifiedHomeCatalogManager(context: Context) {
    private val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _entries = MutableStateFlow(readEntriesSync())
    val entries: StateFlow<List<UnifiedHomeCatalogEntry>> = _entries.asStateFlow()

    private var knownMovieLinkTitles: List<String> = emptyList()

    fun syncSources(
        movieLinkHomeSections: List<CatalogSection>?,
        installedAddons: List<InstalledAddon>
    ) {
        if (movieLinkHomeSections != null) {
            knownMovieLinkTitles = movieLinkHomeSections
                .map { it.title.trim() }
                .filter { it.isNotEmpty() }
                .distinctBy { it.lowercase() }
        }

        val current = _entries.value.toMutableList()
        val addonByUrl = installedAddons.associateBy { it.manifestUrl }
        val latestMlByLower = knownMovieLinkTitles.associateBy { it.lowercase() }

        // 1. Update availability & metadata on all previously saved entries while keeping exact order
        for (i in current.indices) {
            val item = current[i]
            current[i] = when (item.provider) {
                ContentProviderKind.MOVIELINK_BD -> {
                    val mlTitle = item.movieLinkSectionTitle ?: item.title
                    val lower = mlTitle.trim().lowercase()
                    if (latestMlByLower.isEmpty() || latestMlByLower.containsKey(lower)) {
                        item.copy(
                            title = latestMlByLower[lower] ?: mlTitle,
                            isAvailable = true,
                            availabilityNote = null
                        )
                    } else {
                        item.copy(
                            isAvailable = false,
                            availabilityNote = "Section not on current mirror Home"
                        )
                    }
                }
                ContentProviderKind.STREMIO_ADDON -> {
                    val addon = item.addonManifestUrl?.let { addonByUrl[it] }
                    val catType = item.addonCatalogType
                    val catId = item.addonCatalogId
                    when {
                        addon == null -> item.copy(
                            isAvailable = false,
                            availabilityNote = "Addon removed"
                        )
                        !addon.enabled -> item.copy(
                            addonName = addon.manifest.name,
                            isAvailable = false,
                            availabilityNote = "Addon disabled"
                        )
                        !addon.manifest.supportsResource("catalog", catType) -> item.copy(
                            addonName = addon.manifest.name,
                            isAvailable = false,
                            availabilityNote = "Catalog resource unsupported"
                        )
                        else -> {
                            val spec = addon.manifest.catalogs.firstOrNull {
                                it.type.equals(catType, ignoreCase = true) &&
                                    it.id.equals(catId, ignoreCase = true) &&
                                    !it.requiresSearch()
                            }
                            if (spec == null) {
                                item.copy(
                                    addonName = addon.manifest.name,
                                    isAvailable = false,
                                    availabilityNote = "Catalog unavailable"
                                )
                            } else {
                                item.copy(
                                    title = spec.name,
                                    addonName = addon.manifest.name,
                                    isAvailable = true,
                                    availabilityNote = null
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Append any newly discovered MovieLinkBD Home sections (defaulting max 3-4 enabled initially)
        var enabledMlCount = current.count {
            it.provider == ContentProviderKind.MOVIELINK_BD && it.enabled
        }
        val existingKeys = current.map { it.key }.toMutableSet()

        for (mlTitle in knownMovieLinkTitles) {
            val key = movieLinkKey(mlTitle)
            if (existingKeys.add(key)) {
                val shouldEnableByDefault = isCuratedDefaultMovieLinkSection(mlTitle) || enabledMlCount < 3
                val initialEnabled = shouldEnableByDefault && enabledMlCount < DEFAULT_MAX_ML_HOME_SECTIONS
                if (initialEnabled) enabledMlCount++
                current.add(
                    UnifiedHomeCatalogEntry(
                        key = key,
                        provider = ContentProviderKind.MOVIELINK_BD,
                        title = mlTitle,
                        enabled = initialEnabled,
                        movieLinkSectionTitle = mlTitle,
                        isAvailable = true
                    )
                )
            }
        }

        // 3. Append any newly discovered Stremio Addon catalogs (always OFF by default until user enables)
        for (addon in installedAddons.filter { it.enabled }) {
            for (cat in addon.manifest.catalogs) {
                if (cat.requiresSearch()) continue
                if (!addon.manifest.supportsResource("catalog", cat.type)) continue
                val key = addonKey(addon.manifestUrl, cat.type, cat.id)
                if (existingKeys.add(key)) {
                    current.add(
                        UnifiedHomeCatalogEntry(
                            key = key,
                            provider = ContentProviderKind.STREMIO_ADDON,
                            title = cat.name,
                            enabled = false,
                            addonManifestUrl = addon.manifestUrl,
                            addonName = addon.manifest.name,
                            addonCatalogType = cat.type,
                            addonCatalogId = cat.id,
                            isAvailable = true
                        )
                    )
                }
            }
        }

        saveEntries(current)
    }

    fun setCatalogEnabled(key: String, enabled: Boolean) {
        val next = _entries.value.map { entry ->
            if (entry.key == key) entry.copy(enabled = enabled) else entry
        }
        saveEntries(next)
    }

    fun moveCatalog(fromIndex: Int, toIndex: Int) {
        val list = _entries.value.toMutableList()
        if (fromIndex !in list.indices || toIndex !in list.indices || fromIndex == toIndex) return
        val moved = list.removeAt(fromIndex)
        list.add(toIndex, moved)
        saveEntries(list)
    }

    fun removeEntry(key: String) {
        val next = _entries.value.filterNot { it.key == key }
        saveEntries(next)
    }

    private fun isCuratedDefaultMovieLinkSection(title: String): Boolean {
        val lower = title.trim().lowercase()
        return lower.contains("recently updated") ||
            lower.contains("top 10") ||
            lower.contains("new & popular") ||
            lower.contains("new and popular") ||
            lower == "movies"
    }

    private fun saveEntries(list: List<UnifiedHomeCatalogEntry>) {
        if (list == _entries.value && sp.contains(KEY_UNIFIED_CATALOGS)) return
        _entries.value = list
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp.edit().putString(KEY_UNIFIED_CATALOGS, arr.toString()).apply()
    }

    private fun readEntriesSync(): List<UnifiedHomeCatalogEntry> {
        val raw = sp.getString(KEY_UNIFIED_CATALOGS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    UnifiedHomeCatalogEntry.fromJson(obj)?.let { add(it) }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val PREFS_NAME = "movielink_home_catalogs_prefs"
        private const val KEY_UNIFIED_CATALOGS = "unified_home_catalogs_json"
        private const val DEFAULT_MAX_ML_HOME_SECTIONS = 4

        fun movieLinkKey(sectionTitle: String): String =
            "ml:${sectionTitle.trim().lowercase()}"

        fun addonKey(manifestUrl: String, type: String, catalogId: String): String =
            "addon:${manifestUrl.trim()}|${type.trim().lowercase()}|${catalogId.trim()}"
    }
}
