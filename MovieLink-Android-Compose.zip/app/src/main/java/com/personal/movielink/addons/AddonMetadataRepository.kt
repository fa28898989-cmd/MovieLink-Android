package com.personal.movielink.addons

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

data class AddonEpisodeItem(
    val id: String,
    val title: String,
    val season: Int,
    val episode: Int,
    val overview: String = "",
    val released: String = "",
    val thumbnailUrl: String = ""
)

data class AddonDetailedMeta(
    val id: String,
    val type: String,
    val title: String,
    val posterUrl: String = "",
    val backdropUrl: String = "",
    val logoUrl: String = "",
    val description: String = "",
    val releaseYear: String = "",
    val rating: String = "",
    val runtime: String = "",
    val status: String = "",
    val country: String = "",
    val genres: List<String> = emptyList(),
    val cast: List<String> = emptyList(),
    val director: List<String> = emptyList(),
    val videos: List<AddonEpisodeItem> = emptyList(),
    val sourceAddonName: String = "",
    val sourceManifestUrl: String = "",
    val fromFallbackPreview: Boolean = false
)

class AddonMetadataRepository {

    private data class CacheEntry(
        val fetchedAtMs: Long,
        val meta: AddonDetailedMeta
    )

    private val cache = ConcurrentHashMap<String, CacheEntry>()

    fun buildMetaUrl(addon: InstalledAddon, type: String, id: String): String {
        val typeSeg = Uri.encode(type.trim())
        val idSeg = Uri.encode(id.trim())
        val basePath = "${addon.baseUrl.trimEnd('/')}/meta/$typeSeg/$idSeg.json"
        val query = addon.manifestUrl.substringAfter('?', "")
        return if (query.isNotBlank()) "$basePath?$query" else basePath
    }

    fun candidateMetaAddons(
        addons: List<InstalledAddon>,
        type: String,
        id: String,
        preferredManifestUrl: String? = null
    ): List<InstalledAddon> {
        val enabled = addons.filter { it.enabled }
        val preferred = preferredManifestUrl
            ?.takeIf { it.isNotBlank() }
            ?.let { url -> enabled.firstOrNull { it.manifestUrl == url } }

        val compatibleOthers = enabled.filter { addon ->
            addon.manifestUrl != preferredManifestUrl &&
                addon.manifest.supportsResource("meta", type, id)
        }

        return buildList {
            if (preferred != null && preferred.manifest.supportsResource("meta", type, id)) {
                add(preferred)
            }
            addAll(compatibleOthers)
        }
    }

    suspend fun fetchMeta(
        addons: List<InstalledAddon>,
        type: String,
        id: String,
        preferredManifestUrl: String? = null,
        fallbackPreview: AddonDetailedMeta? = null,
        forceRefresh: Boolean = false
    ): Result<AddonDetailedMeta> {
        val cleanType = type.trim().ifBlank { "movie" }
        val cleanId = id.trim()
        if (cleanId.isBlank()) {
            return Result.failure(IllegalArgumentException("Missing content identifier"))
        }

        val cacheKey = "${preferredManifestUrl.orEmpty()}|$cleanType|$cleanId"
        if (!forceRefresh) {
            val cached = cache[cacheKey]
            if (cached != null && System.currentTimeMillis() - cached.fetchedAtMs < CACHE_TTL_MS) {
                return Result.success(cached.meta)
            }
        }

        val candidates = candidateMetaAddons(addons, cleanType, cleanId, preferredManifestUrl)
        if (candidates.isEmpty()) {
            return if (fallbackPreview != null) {
                Result.success(fallbackPreview.copy(fromFallbackPreview = true))
            } else {
                Result.failure(UnsupportedOperationException("No enabled addon supports metadata for $cleanType ($cleanId)"))
            }
        }

        var lastError: Throwable? = null
        for (addon in candidates) {
            try {
                val url = buildMetaUrl(addon, cleanType, cleanId)
                val json = AddonHttp.getJsonObject(url)
                val metaObj = json.optJSONObject("meta")
                if (metaObj != null) {
                    val parsed = parseDetailedMeta(
                        obj = metaObj,
                        addon = addon,
                        fallbackType = cleanType,
                        fallbackId = cleanId,
                        fallbackPreview = fallbackPreview
                    )
                    if (parsed != null) {
                        if (cache.size > MAX_CACHE_ENTRIES) cache.clear()
                        cache[cacheKey] = CacheEntry(System.currentTimeMillis(), parsed)
                        return Result.success(parsed)
                    }
                }
            } catch (e: Exception) {
                lastError = e
            }
        }

        if (fallbackPreview != null) {
            return Result.success(fallbackPreview.copy(fromFallbackPreview = true))
        }
        return Result.failure(lastError ?: IllegalStateException("Unable to load metadata"))
    }

    fun clearCache() {
        cache.clear()
    }

    private fun parseDetailedMeta(
        obj: JSONObject,
        addon: InstalledAddon,
        fallbackType: String,
        fallbackId: String,
        fallbackPreview: AddonDetailedMeta?
    ): AddonDetailedMeta? {
        val id = obj.optString("id", fallbackId).trim().ifBlank { fallbackId }
        val title = obj.optString("name", obj.optString("title", ""))
            .trim()
            .ifBlank { fallbackPreview?.title.orEmpty() }
        if (title.isBlank()) return null

        val type = obj.optString("type", fallbackType).trim().ifBlank { fallbackType }
        val poster = sanitizeHttpUrl(obj.optString("poster", ""))
            .ifBlank { fallbackPreview?.posterUrl.orEmpty() }
        val backdrop = sanitizeHttpUrl(obj.optString("background", ""))
            .ifBlank { fallbackPreview?.backdropUrl.orEmpty() }
            .ifBlank { poster }
        val logo = sanitizeHttpUrl(obj.optString("logo", ""))
            .ifBlank { fallbackPreview?.logoUrl.orEmpty() }
        val description = obj.optString("description", "")
            .trim()
            .ifBlank { fallbackPreview?.description.orEmpty() }

        val releaseYear = obj.optString("releaseInfo", "").trim()
            .ifBlank {
                val rawYear = obj.opt("year")?.toString()?.trim().orEmpty()
                if (rawYear.equals("null", true)) "" else rawYear
            }
            .ifBlank { fallbackPreview?.releaseYear.orEmpty() }

        val ratingRaw = obj.opt("imdbRating")
        val rating = when (ratingRaw) {
            is Number -> ratingRaw.toString()
            is String -> ratingRaw.trim().takeIf {
                it.isNotEmpty() && !it.equals("null", true) && !it.equals("N/A", true)
            }.orEmpty()
            else -> ""
        }.ifBlank { fallbackPreview?.rating.orEmpty() }

        val runtime = obj.optString("runtime", "").trim().takeUnless { it.equals("null", true) }.orEmpty()
        val status = obj.optString("status", "").trim().takeUnless { it.equals("null", true) }.orEmpty()
        val country = obj.optString("country", "").trim().takeUnless { it.equals("null", true) }.orEmpty()

        val genres = readStringList(obj.optJSONArray("genres") ?: obj.optJSONArray("genre"))
            .ifEmpty { fallbackPreview?.genres.orEmpty() }
        val cast = readCastList(obj)
        val director = readStringList(obj.optJSONArray("director"))

        val videosArr = obj.optJSONArray("videos") ?: JSONArray()
        val episodes = buildList {
            for (i in 0 until videosArr.length()) {
                val vObj = videosArr.optJSONObject(i) ?: continue
                val epNum = vObj.optInt("episode", vObj.optInt("number", 0))
                val seasonNum = vObj.optInt("season", 0)
                val rawEpId = vObj.optString("id", "").trim()
                val epId = rawEpId.ifBlank { "$id:$seasonNum:$epNum" }
                val epTitle = vObj.optString("name", vObj.optString("title", ""))
                    .trim()
                    .ifBlank { if (epNum > 0) "Episode $epNum" else "Video ${i + 1}" }
                val overview = vObj.optString("overview", vObj.optString("description", "")).trim()
                val rawReleased = vObj.optString("released", "").trim()
                val cleanReleased = if (rawReleased.length >= 10 && rawReleased[4] == '-' && rawReleased[7] == '-') {
                    rawReleased.substring(0, 10)
                } else {
                    rawReleased
                }
                val thumb = sanitizeHttpUrl(vObj.optString("thumbnail", ""))
                add(
                    AddonEpisodeItem(
                        id = epId,
                        title = epTitle,
                        season = seasonNum,
                        episode = epNum,
                        overview = overview,
                        released = cleanReleased,
                        thumbnailUrl = thumb
                    )
                )
            }
        }.sortedWith(compareBy<AddonEpisodeItem> { it.season }.thenBy { it.episode })

        return AddonDetailedMeta(
            id = id,
            type = type,
            title = title,
            posterUrl = poster,
            backdropUrl = backdrop,
            logoUrl = logo,
            description = description,
            releaseYear = releaseYear,
            rating = rating,
            runtime = runtime,
            status = status,
            country = country,
            genres = genres,
            cast = cast,
            director = director,
            videos = episodes,
            sourceAddonName = addon.manifest.name,
            sourceManifestUrl = addon.manifestUrl,
            fromFallbackPreview = false
        )
    }

    private fun readStringList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val s = arr.optString(i, "").trim()
                if (s.isNotEmpty() && !s.equals("null", true)) add(s)
            }
        }
    }

    private fun readCastList(obj: JSONObject): List<String> {
        val simple = readStringList(obj.optJSONArray("cast"))
        if (simple.isNotEmpty()) return simple
        val credits = obj.optJSONArray("credits_cast") ?: return emptyList()
        return buildList {
            for (i in 0 until credits.length()) {
                val c = credits.optJSONObject(i) ?: continue
                val n = c.optString("name", "").trim()
                if (n.isNotEmpty()) add(n)
            }
        }
    }

    private fun sanitizeHttpUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isEmpty() || clean.equals("null", true)) return ""
        return if (clean.startsWith("http://", true) || clean.startsWith("https://", true)) {
            clean
        } else {
            ""
        }
    }

    companion object {
        private const val CACHE_TTL_MS = 5 * 60 * 1000L
        private const val MAX_CACHE_ENTRIES = 60
    }
}
