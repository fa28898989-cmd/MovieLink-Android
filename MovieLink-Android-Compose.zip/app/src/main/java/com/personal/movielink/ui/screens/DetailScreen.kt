package com.personal.movielink.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.DownloadOption
import com.personal.movielink.MediaCard
import com.personal.movielink.MediaDetail
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.components.SingleCoverScreenshotsSection
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    detail: MediaDetail?,
    currentUrl: String,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    myListCount: Int,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: (MediaDetail) -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String, MediaDetail) -> Unit,
    onDownloadOption: (DownloadOption, MediaDetail) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = palette.textPrimary
                )
            }
            Text(
                text = detail?.title ?: "Loading…",
                color = palette.textPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { DownloadAndPlayerRouter.openInChrome(context, currentUrl) }) {
                Icon(
                    imageVector = Icons.Rounded.OpenInBrowser,
                    contentDescription = "Open in Chrome",
                    tint = palette.textPrimary
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = "Settings",
                    tint = palette.fg
                )
            }
        }

        PullToRefreshBox(
            isRefreshing = isLoading && detail != null,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isLoading && detail == null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = palette.fg)
                    }
                }
                errorMessage != null && detail == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Could not load page",
                                color = palette.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = errorMessage, color = palette.textSecondary, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onRefresh,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = palette.fg,
                                        contentColor = palette.onAccent
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Retry", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onOpenFallbackWeb(currentUrl) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Open WebView", color = palette.textPrimary)
                                }
                            }
                        }
                    }
                }
                detail != null -> {
                    DetailContentBody(
                        detail = detail,
                        settings = settings,
                        imageLoader = imageLoader,
                        isInMyList = isInMyList,
                        myListCount = myListCount,
                        onWatchTrailer = onWatchTrailer,
                        onToggleMyList = { onToggleMyList(detail) },
                        onOpenMyListDialog = onOpenMyListDialog,
                        onWatchOnline = { embed -> onWatchOnline(embed, detail) },
                        onDownloadOption = { opt -> onDownloadOption(opt, detail) },
                        onOpenRelated = onOpenRelated,
                        onOpenFallbackWeb = onOpenFallbackWeb
                    )
                }
            }
        }
    }
}

@Composable
private fun DetailContentBody(
    detail: MediaDetail,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    myListCount: Int,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: () -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String) -> Unit,
    onDownloadOption: (DownloadOption) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var episodeQuery by remember(detail.url) { mutableStateOf("") }
    val seasons = remember(detail.episodes) {
        detail.episodes.mapNotNull { it.seasonNumber }.distinct().sorted()
    }
    var selectedSeason by remember(detail.url) { mutableStateOf<Int?>(null) }

    val filteredEpisodes = remember(detail.episodes, episodeQuery, selectedSeason) {
        detail.episodes.filter { ep ->
            val seasonMatch = selectedSeason == null || ep.seasonNumber == selectedSeason
            val q = episodeQuery.trim().lowercase()
            val queryMatch = q.isEmpty() || ep.title.lowercase().contains(q)
            seasonMatch && queryMatch
        }
    }

    val boxEnabled = settings.detailBoxEnabled
    val boxScale = settings.detailBoxSizePercent.coerceIn(75, 130) / 100f
    val boxOpacity = if (boxEnabled) settings.detailBoxOpacityPercent.coerceIn(0, 100) / 100f else 0f
    val boxShape: Shape = when (settings.detailBoxStyle) {
        Config.DetailBoxStyle.SQUARE -> RoundedCornerShape(0.dp)
        Config.DetailBoxStyle.CIRCLE -> RoundedCornerShape(50)
        Config.DetailBoxStyle.ROUNDED -> RoundedCornerShape(12.dp)
    }
    val boxBaseColor = remember(settings.detailBoxColorHex) {
        try {
            Color(android.graphics.Color.parseColor(settings.detailBoxColorHex))
        } catch (_: Throwable) {
            Color(0xFF71717A)
        }
    }
    val boxBaseLum = remember(boxBaseColor) { ColorUtils.calculateLuminance(boxBaseColor.toArgb()) }
    val isBlackBoxOnDark = !palette.isLightBg && boxBaseLum < 0.05
    val detailBoxBg = when {
        !boxEnabled || boxOpacity <= 0f -> Color.Transparent
        isBlackBoxOnDark -> Color.Black.copy(alpha = 0.88f * boxOpacity)
        else -> boxBaseColor.copy(alpha = 0.22f * boxOpacity)
    }
    val detailBoxBorder = when {
        !boxEnabled || boxOpacity <= 0f -> Color.Transparent
        isBlackBoxOnDark -> Color(0xFF3F3F46).copy(alpha = boxOpacity)
        else -> boxBaseColor.copy(alpha = boxOpacity)
    }
    val detailBoxLabelColor = if (boxEnabled && boxOpacity > 0.08f) {
        when {
            !palette.isLightBg && boxBaseLum < 0.22 -> Color(0xFFD4D4D8)
            palette.isLightBg && boxBaseLum > 0.72 -> Color(0xFF3F3F46)
            else -> boxBaseColor
        }
    } else {
        palette.textSecondary
    }
    val countPillTextColor = if (boxBaseLum > 0.45) {
        Color(0xFF0A0D12)
    } else {
        Color.White
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Poster + Original Title + English Subtitle / Schedule
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (detail.posterUrl.isNotBlank()) {
                    AsyncImage(
                        model = detail.posterUrl,
                        imageLoader = imageLoader,
                        contentDescription = detail.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(156.dp)
                            .aspectRatio(2f / 3f)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.5.dp, palette.boxBorder, RoundedCornerShape(12.dp))
                    )
                }

                Text(
                    text = detail.title,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = palette.textPrimary,
                    textAlign = TextAlign.Center
                )

                if (detail.subtitle.isNotBlank()) {
                    Text(
                        text = detail.subtitle,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = palette.fg,
                        textAlign = TextAlign.Center
                    )
                }

                if (detail.scheduleText.isNotBlank()) {
                    Text(
                        text = detail.scheduleText,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF4ADE80),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Aligned 3 equal-width centered boxes: Type, Language, Quality (independent box customization)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetaRoundedBox(
                    label = "Type",
                    value = detail.type,
                    shape = boxShape,
                    bg = detailBoxBg,
                    border = detailBoxBorder,
                    labelColor = detailBoxLabelColor,
                    valueColor = palette.textPrimary,
                    sizeScale = boxScale,
                    modifier = Modifier.weight(1f)
                )
                MetaRoundedBox(
                    label = "Language",
                    value = detail.language,
                    shape = boxShape,
                    bg = detailBoxBg,
                    border = detailBoxBorder,
                    labelColor = detailBoxLabelColor,
                    valueColor = palette.textPrimary,
                    sizeScale = boxScale,
                    modifier = Modifier.weight(1f)
                )
                MetaRoundedBox(
                    label = "Quality",
                    value = detail.quality,
                    shape = boxShape,
                    bg = detailBoxBg,
                    border = detailBoxBorder,
                    labelColor = detailBoxLabelColor,
                    valueColor = palette.textPrimary,
                    sizeScale = boxScale,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Centered Watch Trailer + Aligned 2-column row: + My List & ★ My List
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (!detail.trailerYoutubeId.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.5.dp, detailBoxBorder, boxShape)
                            .clickable { onWatchTrailer(detail.trailerYoutubeId) }
                            .padding(
                                horizontal = (22f * boxScale).dp,
                                vertical = (11f * boxScale).dp
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "▶",
                                color = if (boxEnabled) detailBoxLabelColor else palette.textPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Watch Trailer",
                                color = palette.textPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 360.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val savedBorder = if (isInMyList && boxEnabled && boxOpacity > 0f) {
                        Color(0xFF4ADE80).copy(alpha = boxOpacity)
                    } else {
                        detailBoxBorder
                    }
                    val savedText = if (isInMyList) Color(0xFF4ADE80) else palette.textPrimary

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((46f * boxScale).dp)
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.5.dp, savedBorder, boxShape)
                            .clickable(onClick = onToggleMyList),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isInMyList) "✓ In My List" else "＋ My List",
                            color = savedText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((46f * boxScale).dp)
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.5.dp, detailBoxBorder, boxShape)
                            .clickable(onClick = onOpenMyListDialog),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "★ My List",
                                color = palette.textPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1
                            )
                            if (myListCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (boxEnabled) boxBaseColor else palette.altBg)
                                        .padding(horizontal = 6.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = myListCount.toString(),
                                        color = if (boxEnabled) countPillTextColor else palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Watch Online CTA (from /p/... embed) — shape & size linked to Box Style section, color linked to Theme Accent
        if (!detail.watchEmbedUrl.isNullOrBlank()) {
            item {
                val accentLum = ColorUtils.calculateLuminance(palette.accent.toArgb())
                val buttonBorder = if (!palette.isLightBg && accentLum < 0.06) {
                    BorderStroke(1.2.dp, Color(0xFF3F3F46))
                } else {
                    null
                }
                Button(
                    onClick = { onWatchOnline(detail.watchEmbedUrl) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = palette.accent,
                        contentColor = palette.onPureAccent
                    ),
                    border = buttonBorder,
                    shape = boxShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((48f * boxScale).dp)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Watch Online (Ad-Free)", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                }
            }
        }

        // Single-Cover Screenshot Card + Pop-Up Gallery
        if (detail.screenshotUrls.isNotEmpty()) {
            item {
                SingleCoverScreenshotsSection(
                    screenshotUrls = detail.screenshotUrls,
                    imageLoader = imageLoader
                )
            }
        }

        // Direct Movie Download Links
        if (detail.downloadLinks.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Download Links",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    detail.downloadLinks.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Season ZIP Packs
        if (detail.seasonZipLinks.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Complete Season Packs",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    detail.seasonZipLinks.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Series Episodes with Season filter + English Episode Search
        if (detail.episodes.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Episodes (${detail.episodes.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )

                    if (seasons.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                SeasonPill(
                                    label = "All Seasons",
                                    selected = selectedSeason == null,
                                    onClick = { selectedSeason = null }
                                )
                            }
                            items(seasons) { s ->
                                SeasonPill(
                                    label = "Season $s",
                                    selected = selectedSeason == s,
                                    onClick = { selectedSeason = s }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = episodeQuery,
                        onValueChange = { episodeQuery = it },
                        placeholder = {
                            Text(
                                text = "Search season or episode…",
                                fontSize = 13.sp,
                                color = palette.textSecondary
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = palette.cardBg,
                            unfocusedContainerColor = palette.cardBg,
                            focusedBorderColor = palette.boxBorder,
                            unfocusedBorderColor = palette.border.copy(alpha = 0.4f),
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            items(filteredEpisodes) { ep ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.cardBg)
                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = ep.title,
                            color = palette.textPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        if (ep.isNew) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(palette.fg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "NEW",
                                    color = palette.onAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    ep.downloads.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Storyline
        if (detail.storyline.isNotBlank()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.cardBg)
                        .border(1.dp, palette.border.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Storyline",
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.fg
                    )
                    Text(
                        text = detail.storyline,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp,
                        color = palette.textPrimary
                    )
                }
            }
        }

        // Cast Carousel
        if (detail.cast.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Cast",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(detail.cast) { actor ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .width(88.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(palette.cardBg)
                                    .border(1.dp, palette.border.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
                                    .padding(8.dp)
                            ) {
                                if (actor.avatarUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = actor.avatarUrl,
                                        imageLoader = imageLoader,
                                        contentDescription = actor.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(palette.altBg),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = actor.name.take(1).uppercase(),
                                            color = palette.fg,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = actor.name,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = palette.textPrimary,
                                    maxLines = 2,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (actor.role.isNotBlank()) {
                                    Text(
                                        text = actor.role,
                                        fontSize = 10.sp,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        textAlign = TextAlign.Center,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Extra Info / Community Rating
        if (!detail.communityRatingSummary.isNullOrBlank()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.boxBg)
                        .border(1.dp, palette.boxBorder.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = detail.communityRatingSummary,
                        color = palette.textPrimary,
                        fontSize = 12.5.sp
                    )
                }
            }
        }

        // Related Titles
        if (detail.relatedItems.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "You May Also Like",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(detail.relatedItems, key = { it.url }) { rel ->
                            MediaPosterCard(
                                card = rel,
                                imageLoader = imageLoader,
                                onClick = { onOpenRelated(rel) },
                                modifier = Modifier.width(128.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            OutlinedButton(
                onClick = { onOpenFallbackWeb(detail.url) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Open Page in Fallback WebView", color = palette.textSecondary, fontSize = 12.5.sp)
            }
        }

        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun MetaRoundedBox(
    label: String,
    value: String,
    shape: Shape,
    bg: Color,
    border: Color,
    labelColor: Color,
    valueColor: Color,
    sizeScale: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .heightIn(min = (60f * sizeScale).dp)
            .clip(shape)
            .background(bg)
            .border(1.5.dp, border, shape)
            .padding(
                horizontal = (8f * sizeScale).dp,
                vertical = (10f * sizeScale).dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = labelColor,
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun DownloadOptionRow(
    opt: DownloadOption,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.boxBg)
            .border(1.2.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = null,
                tint = palette.fg,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = opt.label,
                color = palette.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = "Open",
            color = palette.fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SeasonPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) palette.fg else palette.boxBg)
            .border(1.dp, if (selected) palette.fg else palette.boxBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) palette.onAccent else palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
