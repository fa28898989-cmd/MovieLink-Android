package com.personal.movielink.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.DownloadOption
import com.personal.movielink.MediaCard
import com.personal.movielink.MediaDetail
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.components.SingleCoverScreenshotsSection
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    detail: MediaDetail?,
    currentUrl: String,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    myListCount: Int,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: (MediaDetail) -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String, MediaDetail) -> Unit,
    onDownloadOption: (DownloadOption, MediaDetail) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        PullToRefreshBox(
            isRefreshing = isLoading && detail != null,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isLoading && detail == null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = palette.fg)
                    }
                }
                errorMessage != null && detail == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Could not load page",
                                color = palette.textPrimary,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(text = errorMessage, color = palette.textSecondary, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = onRefresh,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = palette.fg,
                                        contentColor = palette.onAccent
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Retry", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onOpenFallbackWeb(currentUrl) },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text("Open WebView", color = palette.textPrimary)
                                }
                            }
                        }
                    }
                }
                detail != null -> {
                    DetailContentBody(
                        detail = detail,
                        settings = settings,
                        imageLoader = imageLoader,
                        isInMyList = isInMyList,
                        myListCount = myListCount,
                        onWatchTrailer = onWatchTrailer,
                        onToggleMyList = { onToggleMyList(detail) },
                        onOpenMyListDialog = onOpenMyListDialog,
                        onWatchOnline = { embed -> onWatchOnline(embed, detail) },
                        onDownloadOption = { opt -> onDownloadOption(opt, detail) },
                        onOpenRelated = onOpenRelated,
                        onOpenFallbackWeb = onOpenFallbackWeb
                    )
                }
            }
        }

        // Overlaid translucent circular top controls matching editorial hero detail layout
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            DetailCircleActionButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "Back",
                onClick = onBack
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (detail != null) {
                    DetailCircleActionButton(
                        icon = if (isInMyList) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (isInMyList) "Remove from My List" else "Add to My List",
                        tint = if (isInMyList) Color(0xFFEF4444) else Color.White,
                        onClick = { onToggleMyList(detail) }
                    )
                }
                DetailCircleActionButton(
                    icon = Icons.Rounded.OpenInBrowser,
                    contentDescription = "Open in Chrome",
                    onClick = { DownloadAndPlayerRouter.openInChrome(context, currentUrl) }
                )
                DetailCircleActionButton(
                    icon = Icons.Rounded.Tune,
                    contentDescription = "Settings",
                    tint = palette.fg,
                    onClick = onOpenSettings
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailContentBody(
    detail: MediaDetail,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean,
    myListCount: Int,
    onWatchTrailer: (String) -> Unit,
    onToggleMyList: () -> Unit,
    onOpenMyListDialog: () -> Unit,
    onWatchOnline: (String) -> Unit,
    onDownloadOption: (DownloadOption) -> Unit,
    onOpenRelated: (MediaCard) -> Unit,
    onOpenFallbackWeb: (String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var plotExpanded by remember(detail.url) { mutableStateOf(false) }
    var episodeQuery by remember(detail.url) { mutableStateOf("") }
    val seasons = remember(detail.episodes) {
        detail.episodes.mapNotNull { it.seasonNumber }.distinct().sorted()
    }
    var selectedSeason by remember(detail.url) { mutableStateOf<Int?>(null) }

    val filteredEpisodes = remember(detail.episodes, episodeQuery, selectedSeason) {
        detail.episodes.filter { ep ->
            val seasonMatch = selectedSeason == null || ep.seasonNumber == selectedSeason
            val q = episodeQuery.trim().lowercase()
            val queryMatch = q.isEmpty() || ep.title.lowercase().contains(q)
            seasonMatch && queryMatch
        }
    }

    val boxEnabled = settings.detailBoxEnabled
    val boxScale = settings.detailBoxSizePercent.coerceIn(75, 130) / 100f
    val boxOpacity = if (boxEnabled) settings.detailBoxOpacityPercent.coerceIn(0, 100) / 100f else 0f
    val boxShape: Shape = when (settings.detailBoxStyle) {
        Config.DetailBoxStyle.SQUARE -> RoundedCornerShape(0.dp)
        Config.DetailBoxStyle.CIRCLE -> RoundedCornerShape(50)
        Config.DetailBoxStyle.ROUNDED -> RoundedCornerShape(12.dp)
    }
    val boxBaseColor = remember(settings.detailBoxColorHex) {
        try {
            Color(android.graphics.Color.parseColor(settings.detailBoxColorHex))
        } catch (_: Throwable) {
            Color(0xFF71717A)
        }
    }
    val boxBaseLum = remember(boxBaseColor) { ColorUtils.calculateLuminance(boxBaseColor.toArgb()) }
    val isBlackBoxOnDark = !palette.isLightBg && boxBaseLum < 0.05
    val detailBoxBg = when {
        !boxEnabled || boxOpacity <= 0f -> Color.Transparent
        isBlackBoxOnDark -> Color.Black.copy(alpha = 0.88f * boxOpacity)
        else -> boxBaseColor.copy(alpha = 0.22f * boxOpacity)
    }
    val detailBoxBorder = when {
        !boxEnabled || boxOpacity <= 0f -> Color.Transparent
        isBlackBoxOnDark -> Color(0xFF3F3F46).copy(alpha = boxOpacity)
        else -> boxBaseColor.copy(alpha = boxOpacity)
    }
    val detailBoxLabelColor = if (boxEnabled && boxOpacity > 0.08f) {
        when {
            !palette.isLightBg && boxBaseLum < 0.22 -> Color(0xFFD4D4D8)
            palette.isLightBg && boxBaseLum > 0.72 -> Color(0xFF3F3F46)
            else -> boxBaseColor
        }
    } else {
        palette.textSecondary
    }
    val countPillTextColor = if (boxBaseLum > 0.45) {
        Color(0xFF0A0D12)
    } else {
        Color.White
    }

    val canWatchOnline = settings.movieLinkWatchOnlineEnabled && !detail.watchEmbedUrl.isNullOrBlank()
    val hasTrailer = !detail.trailerYoutubeId.isNullOrBlank()
    val playBtnColor = Color(0xFFE50914)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Full-bleed Hero Artwork + Smooth Scrim + Centered Circular Play CTA
        item(key = "hero_cover") {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                ) {
                    val heroCoverUrl = detail.backdropUrl.ifBlank { detail.posterUrl }
                    if (heroCoverUrl.isNotBlank()) {
                        AsyncImage(
                            model = heroCoverUrl,
                            imageLoader = imageLoader,
                            contentDescription = detail.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(palette.cardBg)
                        )
                    }

                    // Top subtle scrim for back/heart/settings circle contrast
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(86.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0x99000000), Color.Transparent)
                                )
                            )
                    )

                    // Bottom gradient scrim seamlessly blending into pageBg
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(190.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        palette.pageBg.copy(alpha = 0.76f),
                                        palette.pageBg
                                    )
                                )
                            )
                    )

                    // Centered Prominent Play Button (Watch Online or Trailer fallback)
                    if (canWatchOnline || hasTrailer) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 14.dp)
                                .size(58.dp)
                                .shadow(12.dp, CircleShape)
                                .clip(CircleShape)
                                .background(playBtnColor)
                                .clickable {
                                    when {
                                        canWatchOnline -> onWatchOnline(detail.watchEmbedUrl!!)
                                        hasTrailer -> onWatchTrailer(detail.trailerYoutubeId!!)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = if (canWatchOnline) "Watch Online" else "Watch Trailer",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = detail.title,
                        fontSize = 24.sp,
                        lineHeight = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.textPrimary,
                        textAlign = TextAlign.Center
                    )

                    val metaSummary = listOfNotNull(
                        detail.type.takeIf { it.isNotBlank() },
                        detail.language.takeIf { it.isNotBlank() },
                        detail.quality.takeIf { it.isNotBlank() },
                        detail.episodes.takeIf { it.isNotEmpty() }?.let { "${it.size} Episodes" }
                    ).joinToString(" · ")

                    if (metaSummary.isNotBlank()) {
                        Text(
                            text = metaSummary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (detail.subtitle.isNotBlank()) {
                        Text(
                            text = detail.subtitle,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = palette.fg,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (!detail.communityRatingSummary.isNullOrBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = Color(0xFFFBBF24),
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = detail.communityRatingSummary,
                                color = palette.textPrimary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (detail.externalRatings.isNotEmpty()) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            detail.externalRatings.forEach { badge ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(palette.cardBg)
                                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${badge.source} · ${badge.value}",
                                        color = palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    if (detail.scheduleText.isNotBlank()) {
                        Text(
                            text = detail.scheduleText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF4ADE80),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Primary & Secondary CTAs (Watch Online, Watch Trailer, My List)
        item(key = "detail_actions") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canWatchOnline) {
                    val accentLum = ColorUtils.calculateLuminance(palette.accent.toArgb())
                    val buttonBorder = if (!palette.isLightBg && accentLum < 0.06) {
                        BorderStroke(1.2.dp, Color(0xFF3F3F46))
                    } else {
                        null
                    }
                    Button(
                        onClick = { onWatchOnline(detail.watchEmbedUrl!!) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = palette.onPureAccent
                        ),
                        border = buttonBorder,
                        shape = boxShape,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height((48f * boxScale).dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Watch Online (Ad-Free)", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 380.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (hasTrailer) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height((44f * boxScale).dp)
                                .clip(boxShape)
                                .background(detailBoxBg)
                                .border(1.3.dp, detailBoxBorder, boxShape)
                                .clickable { onWatchTrailer(detail.trailerYoutubeId!!) },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = null,
                                    tint = palette.textPrimary,
                                    modifier = Modifier.size(17.dp)
                                )
                                Text(
                                    text = "Trailer",
                                    color = palette.textPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    val savedBorder = if (isInMyList && boxEnabled && boxOpacity > 0f) {
                        Color(0xFF4ADE80).copy(alpha = boxOpacity)
                    } else {
                        detailBoxBorder
                    }
                    val savedText = if (isInMyList) Color(0xFF4ADE80) else palette.textPrimary

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((44f * boxScale).dp)
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.3.dp, savedBorder, boxShape)
                            .clickable(onClick = onToggleMyList),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isInMyList) "✓ In My List" else "＋ My List",
                            color = savedText,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height((44f * boxScale).dp)
                            .clip(boxShape)
                            .background(detailBoxBg)
                            .border(1.3.dp, detailBoxBorder, boxShape)
                            .clickable(onClick = onOpenMyListDialog),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.FormatListBulleted,
                                contentDescription = null,
                                tint = palette.textPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "List",
                                color = palette.textPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                            if (myListCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (boxEnabled) boxBaseColor else palette.altBg)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = myListCount.toString(),
                                        color = if (boxEnabled) countPillTextColor else palette.textPrimary,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Customizable 3 equal-width centered boxes: Type, Language, Quality
        if (boxEnabled) {
            item(key = "meta_boxes") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetaRoundedBox(
                        label = "Type",
                        value = detail.type,
                        shape = boxShape,
                        bg = detailBoxBg,
                        border = detailBoxBorder,
                        labelColor = detailBoxLabelColor,
                        valueColor = palette.textPrimary,
                        sizeScale = boxScale,
                        modifier = Modifier.weight(1f)
                    )
                    MetaRoundedBox(
                        label = "Language",
                        value = detail.language,
                        shape = boxShape,
                        bg = detailBoxBg,
                        border = detailBoxBorder,
                        labelColor = detailBoxLabelColor,
                        valueColor = palette.textPrimary,
                        sizeScale = boxScale,
                        modifier = Modifier.weight(1f)
                    )
                    MetaRoundedBox(
                        label = "Quality",
                        value = detail.quality,
                        shape = boxShape,
                        bg = detailBoxBg,
                        border = detailBoxBorder,
                        labelColor = detailBoxLabelColor,
                        valueColor = palette.textPrimary,
                        sizeScale = boxScale,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // The Plot (Expandable Synopsis matching Reference Image 3)
        if (detail.storyline.isNotBlank()) {
            item(key = "the_plot") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "The Plot",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    Text(
                        text = detail.storyline,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp,
                        color = palette.textSecondary,
                        maxLines = if (plotExpanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (detail.storyline.length > 135) {
                        Text(
                            text = if (plotExpanded) "Show Less" else "Read More",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFEF4444),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { plotExpanded = !plotExpanded }
                                .padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Casts (Circular Avatars Carousel matching Reference Image 3)
        if (detail.cast.isNotEmpty()) {
            item(key = "casts") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Casts",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(detail.cast) { actor ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.width(68.dp)
                            ) {
                                if (actor.avatarUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = actor.avatarUrl,
                                        imageLoader = imageLoader,
                                        contentDescription = actor.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(CircleShape)
                                            .background(palette.cardBg)
                                            .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(60.dp)
                                            .clip(CircleShape)
                                            .background(palette.altBg)
                                            .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = actor.name.take(1).uppercase(),
                                            color = palette.fg,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = actor.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = palette.textPrimary,
                                    maxLines = 1,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (actor.role.isNotBlank()) {
                                    Text(
                                        text = actor.role,
                                        fontSize = 9.5.sp,
                                        color = palette.textSecondary,
                                        maxLines = 1,
                                        textAlign = TextAlign.Center,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Single-Cover Screenshot Card + Pop-Up Gallery
        if (detail.screenshotUrls.isNotEmpty()) {
            item(key = "screenshots") {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    SingleCoverScreenshotsSection(
                        screenshotUrls = detail.screenshotUrls,
                        imageLoader = imageLoader
                    )
                }
            }
        }

        // Direct Movie Download Links
        if (detail.downloadLinks.isNotEmpty()) {
            item(key = "downloads") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Download Links",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    detail.downloadLinks.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Season ZIP Packs
        if (detail.seasonZipLinks.isNotEmpty()) {
            item(key = "season_zips") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Complete Season Packs",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )
                    detail.seasonZipLinks.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Series Episodes with Season filter + English Episode Search
        if (detail.episodes.isNotEmpty()) {
            item(key = "episodes_header") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Episodes (${detail.episodes.size})",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary
                    )

                    if (seasons.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            item {
                                SeasonPill(
                                    label = "All Seasons",
                                    selected = selectedSeason == null,
                                    onClick = { selectedSeason = null }
                                )
                            }
                            items(seasons) { s ->
                                SeasonPill(
                                    label = "Season $s",
                                    selected = selectedSeason == s,
                                    onClick = { selectedSeason = s }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = episodeQuery,
                        onValueChange = { episodeQuery = it },
                        placeholder = {
                            Text(
                                text = "Search season or episode…",
                                fontSize = 13.sp,
                                color = palette.textSecondary
                            )
                        },
                        leadingIcon = {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = palette.cardBg,
                            unfocusedContainerColor = palette.cardBg,
                            focusedBorderColor = palette.boxBorder,
                            unfocusedBorderColor = palette.border.copy(alpha = 0.4f),
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            items(filteredEpisodes) { ep ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.cardBg)
                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = ep.title,
                            color = palette.textPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        if (ep.isNew) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(palette.fg)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "NEW",
                                    color = palette.onAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    ep.downloads.forEach { opt ->
                        DownloadOptionRow(opt = opt, onClick = { onDownloadOption(opt) })
                    }
                }
            }
        }

        // Related Titles
        if (detail.relatedItems.isNotEmpty()) {
            item(key = "related") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "You May Also Like",
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.textPrimary,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(detail.relatedItems, key = { it.url }) { rel ->
                            MediaPosterCard(
                                card = rel,
                                imageLoader = imageLoader,
                                onClick = { onOpenRelated(rel) },
                                modifier = Modifier.width(128.dp)
                            )
                        }
                    }
                }
            }
        }

        item(key = "fallback_web") {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                OutlinedButton(
                    onClick = { onOpenFallbackWeb(detail.url) },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Page in Fallback WebView", color = palette.textSecondary, fontSize = 12.5.sp)
                }
            }
        }
    }
}

@Composable
private fun DetailCircleActionButton(
    icon: ImageVector,
    contentDescription: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x9916161C))
            .border(1.dp, Color(0x2EFFFFFF), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun MetaRoundedBox(
    label: String,
    value: String,
    shape: Shape,
    bg: Color,
    border: Color,
    labelColor: Color,
    valueColor: Color,
    sizeScale: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .heightIn(min = (60f * sizeScale).dp)
            .clip(shape)
            .background(bg)
            .border(1.5.dp, border, shape)
            .padding(
                horizontal = (8f * sizeScale).dp,
                vertical = (10f * sizeScale).dp
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = labelColor,
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Text(
            text = value,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun DownloadOptionRow(
    opt: DownloadOption,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.boxBg)
            .border(1.2.dp, palette.boxBorder.copy(alpha = 0.7f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = null,
                tint = palette.fg,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = opt.label,
                color = palette.textPrimary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = "Open",
            color = palette.fg,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SeasonPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) palette.fg else palette.boxBg)
            .border(1.dp, if (selected) palette.fg else palette.boxBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) palette.onAccent else palette.textPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
