package com.personal.movielink

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

object AdBlocker {
    private val counter = AtomicInteger(0)
    private val _sessionBlockedCount = MutableStateFlow(0)
    val sessionBlockedCount: StateFlow<Int> = _sessionBlockedCount.asStateFlow()

    private val domains = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "2mdn.net",
        "popads.net", "popcash.net", "propellerads.com", "propellerclick.com", "exoclick.com",
        "exosrv.com", "exdynsrv.com", "juicyads.com", "trafficjunky.com", "trafficfactory.biz",
        "adsterra.com", "highperformanceformat.com", "effectivegatecpm.com", "profitablecpmrate.com",
        "profitablegatecpm.com", "highcpmgate.com", "adcash.com", "clickadu.com", "hilltopads.net",
        "hilltopads.com", "onclickads.net", "onclkds.com", "a-ads.com", "adnxs.com", "taboola.com",
        "outbrain.com", "mgid.com", "revcontent.com", "bidvertiser.com", "ad-maven.com",
        "admaven.com", "richads.com", "monetag.com", "pushame.com", "pushails.com", "notifpush.com",
        "adskeeper.com", "adspyglass.com", "ero-advertising.com", "tsyndicate.com", "ads.yahoo.com",
        "histats.com", "mc.yandex.ru", "adform.net", "criteo.com", "pubmatic.com", "rubiconproject.com",
        "openx.net", "smaato.net", "yllix.com", "kdmzu.com", "realsrv.com", "syndication.realsrv.com",
        "bongacams.com", "stripchat.com", "chaturbate.com", "livejasmin.com", "adtng.com",
        "clksite.com", "tzegilo.com", "acscdn.com", "wpadmngr.com", "pemsrv.com"
    )

    private val patterns = listOf(
        "popunder", "/adserver", "adsbygoogle", "/pop.js", "/popup.js", "/banner_ads", "/prebid"
    )

    private val cache = ConcurrentHashMap<String, Boolean>()

    private fun hostMatchesSet(host: String, set: Set<String>): Boolean {
        if (set.isEmpty()) return false
        var h = host
        while (true) {
            if (h in set) return true
            val idx = h.indexOf('.')
            if (idx < 0) break
            h = h.substring(idx + 1)
        }
        return false
    }

    private fun hostBlocked(host: String): Boolean =
        cache.getOrPut(host) { hostMatchesSet(host, domains) }

    private fun recordBlock() {
        _sessionBlockedCount.value = counter.incrementAndGet()
    }

    fun shouldBlock(uri: Uri, settings: UserSettings): Boolean {
        if (!settings.adBlockEnabled) return false
        val host = uri.host?.lowercase(Locale.US) ?: return false
        if (Config.isInternal(host, settings.mirrorUrl)) return false
        if (hostMatchesSet(host, settings.customAllowedDomains)) return false
        if (hostMatchesSet(host, settings.customBlockedDomains)) {
            recordBlock()
            return true
        }
        if (hostBlocked(host)) {
            recordBlock()
            return true
        }
        val raw = uri.toString().lowercase(Locale.US)
        val matched = patterns.any { raw.contains(it) }
        if (matched) recordBlock()
        return matched
    }
}
