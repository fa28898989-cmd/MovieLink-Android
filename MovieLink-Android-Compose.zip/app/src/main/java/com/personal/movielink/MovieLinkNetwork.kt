package com.personal.movielink

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.HttpUrl
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class CloudflareRequiredException(val url: String) : IOException("Cloudflare verification required for $url")

object MovieLinkNetwork {
    private class WebViewCookieJar : CookieJar {
        private val cm: CookieManager by lazy { CookieManager.getInstance() }

        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            val urlStr = url.toString()
            for (cookie in cookies) {
                cm.setCookie(urlStr, cookie.toString())
            }
            cm.flush()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val raw = cm.getCookie(url.toString()) ?: return emptyList()
            return raw.split(";")
                .mapNotNull { part ->
                    val trimmed = part.trim()
                    val eq = trimmed.indexOf('=')
                    if (eq <= 0) return@mapNotNull null
                    val name = trimmed.substring(0, eq).trim()
                    val value = trimmed.substring(eq + 1).trim()
                    Cookie.Builder()
                        .name(name)
                        .value(value)
                        .domain(url.host)
                        .path("/")
                        .build()
                }
        }
    }

    fun buildHttpClient(settingsProvider: () -> UserSettings): OkHttpClient {
        val blockerInterceptor = Interceptor { chain ->
            val req = chain.request()
            val settings = settingsProvider()
            val uri = Uri.parse(req.url.toString())
            if (AdBlocker.shouldBlock(uri, settings)) {
                return@Interceptor Response.Builder()
                    .request(req)
                    .protocol(Protocol.HTTP_1_1)
                    .code(204)
                    .message("Blocked by MovieLink AdBlocker")
                    .body(ByteArray(0).toResponseBody(null))
                    .build()
            }
            val ua = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
            val nextReq = req.newBuilder()
                .header("User-Agent", ua)
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()
            chain.proceed(nextReq)
        }

        return OkHttpClient.Builder()
            .cookieJar(WebViewCookieJar())
            .connectionPool(ConnectionPool(12, 5, TimeUnit.MINUTES))
            .addInterceptor(blockerInterceptor)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(18, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Dedicated HTTP client for direct Stremio/Nuvio addon streams and progressive/HLS media.
     * - Preserves caller/proxyHeaders headers verbatim (never overwrites custom User-Agent).
     * - Does not inject MovieLinkBD WebView cookies or run site AdBlocker against stream CDNs.
     */
    fun buildStreamHttpClient(settingsProvider: () -> UserSettings): OkHttpClient {
        val streamHeaderInterceptor = Interceptor { chain ->
            val req = chain.request()
            val builder = req.newBuilder()
            if (req.header("User-Agent").isNullOrBlank()) {
                val ua = if (settingsProvider().desktopMode) {
                    Config.DESKTOP_USER_AGENT
                } else {
                    Config.MOBILE_USER_AGENT
                }
                builder.header("User-Agent", ua)
            }
            if (req.header("Accept-Language").isNullOrBlank()) {
                builder.header("Accept-Language", "en-US,en;q=0.9")
            }
            chain.proceed(builder.build())
        }

        return OkHttpClient.Builder()
            .cookieJar(CookieJar.NO_COOKIES)
            .connectionPool(ConnectionPool(12, 5, TimeUnit.MINUTES))
            .addInterceptor(streamHeaderInterceptor)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    fun buildImageLoader(context: Context): ImageLoader {
        // R2 poster/screenshot host serves all artwork from one domain; lift OkHttp's default 5/host cap
        val dispatcher = Dispatcher().apply {
            maxRequests = 64
            maxRequestsPerHost = 24
        }
        val httpCacheDir = File(context.cacheDir, "http_image_cache")
        val imageClient = OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            .cache(Cache(httpCacheDir, 80L * 1024L * 1024L))
            .addInterceptor { chain ->
                val req = chain.request().newBuilder()
                    .removeHeader("Referer")
                    .header("User-Agent", Config.MOBILE_USER_AGENT)
                    .header("Referrer-Policy", "no-referrer")
                    .build()
                chain.proceed(req)
            }
            .retryOnConnectionFailure(true)
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()

        return ImageLoader.Builder(context)
            .okHttpClient(imageClient)
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizePercent(0.25)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(context.cacheDir, "coil_image_cache"))
                    .maxSizeBytes(150L * 1024L * 1024L)
                    .build()
            }
            .allowRgb565(true)
            .respectCacheHeaders(false)
            .crossfade(150)
            .build()
    }
}

class MovieLinkRepository(
    private val httpClient: OkHttpClient,
    private val settingsProvider: () -> UserSettings
) {
    suspend fun fetchCatalogPage(url: String): CatalogPage = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val normalized = Config.normalizeUrl(url)
        val (finalUrl, html) = fetchHtml(normalized)
        parseCatalogDocument(finalUrl, html, settings)
    }

    suspend fun searchCatalog(query: String): CatalogPage = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val base = settings.mirrorUrl.trimEnd('/')
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        val searchUrl = "$base/search?q=$encoded"
        val (finalUrl, html) = fetchHtml(searchUrl)
        parseCatalogDocument(finalUrl, html, settings, forceGrid = true, customTitle = "Search: ${query.trim()}")
    }

    suspend fun fetchDetail(url: String): MediaDetail = withContext(Dispatchers.IO) {
        val settings = settingsProvider()
        val (finalUrl, html) = fetchHtml(url)
        parseDetailDocument(finalUrl, html, settings)
    }

    private fun fetchHtml(url: String): Pair<String, String> {
        val req = Request.Builder()
            .url(url)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .build()

        httpClient.newCall(req).execute().use { resp ->
            val finalUrl = resp.request.url.toString()
            val body = resp.body?.string().orEmpty()
            val cfHeader = resp.header("cf-mitigated")
            if (resp.code in listOf(403, 503) ||
                cfHeader.equals("challenge", ignoreCase = true) ||
                looksLikeCloudflareChallenge(body)
            ) {
                throw CloudflareRequiredException(finalUrl)
            }
            if (!resp.isSuccessful && body.isBlank()) {
                throw IOException("HTTP ${resp.code} while loading $finalUrl")
            }
            return finalUrl to body
        }
    }

    private fun looksLikeCloudflareChallenge(html: String): Boolean {
        if (html.length > 35_000) return false
        val lower = html.lowercase()
        return lower.contains("cf-browser-verification") ||
            lower.contains("challenge-platform") ||
            (lower.contains("just a moment") && lower.contains("cloudflare"))
    }

    private fun parseCatalogDocument(
        finalUrl: String,
        html: String,
        settings: UserSettings,
        forceGrid: Boolean = false,
        customTitle: String? = null
    ): CatalogPage {
        val doc = Jsoup.parse(html, finalUrl)
        val polish = settings.sitePolishEnabled
        val categories = extractCategories(doc, finalUrl, settings)

        val sections = mutableListOf<CatalogSection>()
        val seenSectionKeys = hashSetOf<String>()

        val isSearchPage = forceGrid ||
            Uri.parse(finalUrl).path.orEmpty().lowercase().startsWith("/search")

        // 1. Primary .movie-cards-container (Recently Updated on Home, or grid on category/search pages)
        // On search pages only the actual results grid is used. Shared site blocks (rails, recommended,
        // recently updated) would otherwise be merged into the results and look like wrong matches.
        val allContainers = doc.select(".movie-cards-container")
        val containers = if (isSearchPage) {
            val resultsGrid = allContainers.firstOrNull { c ->
                c.closest("section.mlbd-rail-section") == null && c.select(".movie-card").isNotEmpty()
            }
            if (resultsGrid != null) listOf(resultsGrid) else allContainers.toList()
        } else {
            allContainers.toList()
        }
        for (container in containers) {
            val cards = container.select(".movie-card").mapNotNull { parseMovieCard(it, finalUrl, polish) }
                .distinctBy { it.url }
            if (cards.isEmpty()) continue

            val headingEl = findSectionHeading(container)
            val rawHeading = headingEl?.text()?.trim().orEmpty()
            val cleanHeading = cleanSectionTitle(BanglaTranslator.translateUi(rawHeading, polish))
                .ifBlank { if (sections.isEmpty()) "Recently Updated" else "More Titles" }

            val moreHref = headingEl?.parent()?.selectFirst("a[href]")?.absUrl("href")
                ?.takeIf { it.isNotBlank() && !it.contains("/movie/") && !it.contains("/series/") }

            val key = "${cleanHeading.lowercase()}:${cards.first().url}"
            if (seenSectionKeys.add(key)) {
                sections.add(CatalogSection(cleanHeading, cards, moreHref))
            }
        }

        // 2. Homepage horizontal rail sections (.mlbd-rail-section: Top 10, New & Popular, Movies, Series, etc.)
        val railSections = if (isSearchPage && sections.isNotEmpty()) emptyList<Element>() else doc.select("section.mlbd-rail-section").toList()
        for (rail in railSections) {
            val cards = rail.select(".mlbd-rail .movie-card, .movie-card")
                .mapNotNull { parseMovieCard(it, finalUrl, polish) }
                .distinctBy { it.url }
            if (cards.isEmpty()) continue

            val rawTitle = rail.selectFirst(".mlbd-rail-title")?.text()?.trim()
                ?: rail.attr("aria-label").trim()
            val cleanTitle = cleanSectionTitle(BanglaTranslator.translateUi(rawTitle, polish))
                .ifBlank { "Featured" }
            if (cleanTitle.contains("18+") || cleanTitle.contains("adult", ignoreCase = true)) continue

            val moreHref = rail.selectFirst("a.mlbd-rail-showall[href]")?.absUrl("href")
                ?.takeIf { it.isNotBlank() }

            val key = "${cleanTitle.lowercase()}:${cards.first().url}"
            if (seenSectionKeys.add(key)) {
                sections.add(CatalogSection(cleanTitle, cards, moreHref))
            }
        }

        // Fallback if cards are laid out without expected containers
        if (sections.isEmpty()) {
            val allCards = doc.select(".movie-card").mapNotNull { parseMovieCard(it, finalUrl, polish) }
                .distinctBy { it.url }
            if (allCards.isNotEmpty()) {
                sections.add(CatalogSection(customTitle ?: "Catalog", allCards, null))
            }
        }

        val pageTitleRaw = customTitle
            ?: doc.selectFirst("h1, .mlbd-page-title")?.text()?.trim()
            ?: doc.title().substringBefore("—").substringBefore("|").trim().ifBlank { "MovieLink" }

        val pageTitle = cleanSectionTitle(
            BanglaTranslator.translateUi(pageTitleRaw, polish)
                .replace("MovieLinkBD", "MovieLink")
        ).ifBlank { "Catalog" }

        val nextPageUrl = doc.selectFirst("a.next, a[rel=next], .pagination li.active + li a, .pagination a:contains(Next)")
            ?.absUrl("href")
            ?.takeIf { it.isNotBlank() && it != finalUrl }

        val lowerPath = Uri.parse(finalUrl).path.orEmpty().lowercase()
        val isCategoryOrListPath = lowerPath.startsWith("/type/") ||
            lowerPath.startsWith("/genre/") ||
            lowerPath.startsWith("/language/") ||
            lowerPath.startsWith("/category/") ||
            lowerPath.startsWith("/collection/") ||
            lowerPath.startsWith("/ott") ||
            lowerPath.startsWith("/search") ||
            lowerPath.startsWith("/ongoing") ||
            lowerPath.startsWith("/mostwatch") ||
            lowerPath == "/bollywood" ||
            lowerPath == "/live"

        val (ottAllUrl, ottPlatforms) = extractOttPlatforms(doc, finalUrl)

        return CatalogPage(
            url = finalUrl,
            pageTitle = pageTitle,
            sections = sections,
            categories = categories,
            ottPlatforms = ottPlatforms,
            ottAllUrl = ottAllUrl,
            nextPageUrl = nextPageUrl,
            isSearchOrGrid = forceGrid || isCategoryOrListPath || sections.size <= 1
        )
    }

    private fun extractOttPlatforms(doc: Document, baseUrl: String): Pair<String?, List<OttPlatform>> {
        val bar = doc.selectFirst(".mlbd-ottbar") ?: return null to emptyList()
        val allUrl = bar.selectFirst(".mlbd-ottbar-hd a[href]")?.absUrl("href")?.takeIf { it.isNotBlank() }
        val platforms = bar.select("a.mlbd-ott-item[href]").mapNotNull { a ->
            val href = a.attr("href").trim()
            if (href.isEmpty() || href == "#") return@mapNotNull null
            val absUrl = LinkDecoder.resolveUrl(baseUrl, href)
            val name = a.selectFirst(".mlbd-ott-lbl")?.text()?.trim()
                ?.ifBlank { a.attr("title").trim() }
                .orEmpty()
            if (name.isBlank()) return@mapNotNull null

            val img = a.selectFirst("img")
            val iconRaw = img?.attr("src")?.trim()?.takeIf { it.isNotEmpty() && !it.startsWith("data:") }
                ?: img?.attr("data-src")?.trim().orEmpty()
            val iconUrl = if (iconRaw.isNotEmpty()) LinkDecoder.resolveUrl(baseUrl, iconRaw) else ""

            val newBadge = a.selectFirst(".mlbd-ott-new")?.text()?.trim().orEmpty()
            val styleAttr = a.attr("style")
            val colorMatch = Regex("""--oc\s*:\s*(#[0-9a-fA-F]{3,8})""").find(styleAttr)?.groupValues?.getOrNull(1)
            val accentHex = when {
                colorMatch == null -> "#22D3EE"
                colorMatch.length == 4 -> {
                    val r = colorMatch[1]
                    val g = colorMatch[2]
                    val b = colorMatch[3]
                    "#$r$r$g$g$b$b"
                }
                else -> colorMatch
            }

            OttPlatform(
                name = name,
                url = absUrl,
                iconUrl = iconUrl,
                newBadge = newBadge,
                accentHex = accentHex
            )
        }.distinctBy { it.url }
        return allUrl to platforms
    }

    private fun cleanSectionTitle(raw: String): String {
        val stripped = raw
            .replace(Regex("""[^\p{L}\p{N}\p{P}\p{Z}&+/·\-]+"""), " ")
            .replace(Regex("""\s{2,}"""), " ")
            .trim()
        if (stripped.isEmpty()) return ""
        return if (stripped == stripped.uppercase() && stripped.length > 4) {
            stripped.lowercase().split(" ").joinToString(" ") { w ->
                when (w) {
                    "tv" -> "TV"
                    "k/j/c" -> "K/J/C"
                    else -> w.replaceFirstChar { it.uppercase() }
                }
            }
        } else {
            stripped
        }
    }

    private fun extractCategories(doc: Document, baseUrl: String, settings: UserSettings): List<CategoryChip> {
        val chips = linkedMapOf<String, CategoryChip>()
        val links = doc.select("a[href]")
        for (a in links) {
            val href = a.attr("href").trim()
            if (href.isEmpty() || href == "#" || href.startsWith("javascript:", true)) continue
            val abs = LinkDecoder.resolveUrl(baseUrl, href)
            val uri = Uri.parse(abs)
            if (!Config.isInternal(uri.host, settings.mirrorUrl)) continue
            val path = uri.path.orEmpty()
            val isCategoryPath = path.startsWith("/language/") ||
                path.startsWith("/genre/") ||
                path.startsWith("/type/") ||
                path.startsWith("/category/") ||
                path.startsWith("/collection/") ||
                path.startsWith("/ongoing") ||
                path == "/bollywood" ||
                path == "/live"
            if (!isCategoryPath) continue
            if (path.contains("how2download", true)) continue
            val translated = BanglaTranslator.translateUi(a.text().trim(), settings.sitePolishEnabled)
            val cleaned = cleanSectionTitle(translated)
                .replace(Regex("""\s+\d+\s+titles$""", RegexOption.IGNORE_CASE), "")
                .trim()
            if (cleaned.isBlank() || cleaned.length > 30) continue
            if (BanglaTranslator.isClutterText(cleaned)) continue
            chips.putIfAbsent(abs, CategoryChip(cleaned, abs))
        }
        return chips.values.take(36)
    }

    private fun findSectionHeading(container: Element): Element? {
        var prev = container.previousElementSibling()
        var steps = 0
        while (prev != null && steps < 4) {
            val h = prev.selectFirst("h1, h2, h3, h4, .section-title, .mlbd-sec-title") ?: if (prev.tagName().matches(Regex("h[1-4]"))) prev else null
            if (h != null && h.text().isNotBlank() && !BanglaTranslator.isClutterText(h.text())) {
                return h
            }
            prev = prev.previousElementSibling()
            steps++
        }
        val parentPrev = container.parent()?.previousElementSibling()
        val ph = parentPrev?.selectFirst("h1, h2, h3, h4, .section-title, .mlbd-sec-title")
        if (ph != null && ph.text().isNotBlank() && !BanglaTranslator.isClutterText(ph.text())) {
            return ph
        }
        return null
    }

    private fun parseMovieCard(card: Element, baseUrl: String, polish: Boolean): MediaCard? {
        val anchor = card.selectFirst("a[href*=/movie/], a[href*=/series/], a[href*=/drama/], a[href*=/anime/], a[href]")
            ?: return null
        val href = anchor.attr("href").trim()
        if (href.isEmpty() || href == "#") return null
        val absUrl = LinkDecoder.resolveUrl(baseUrl, href)

        val img = card.selectFirst("img")
        val rawTitle = card.selectFirst(".title, .movie-title, h3, h4")?.text()?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: img?.attr("alt")?.trim()
            ?: anchor.attr("title").trim()
        if (rawTitle.isBlank()) return null

        val dataSrc = img?.attr("data-src")?.trim().orEmpty()
        val src = img?.attr("src")?.trim().orEmpty()
        val posterRaw = when {
            dataSrc.isNotEmpty() && !dataSrc.startsWith("data:") && !dataSrc.contains("mlbd_load") -> dataSrc
            src.isNotEmpty() && !src.startsWith("data:") && !src.contains("mlbd_load") -> src
            else -> ""
        }
        val posterUrl = if (posterRaw.isNotEmpty()) LinkDecoder.resolveUrl(baseUrl, posterRaw) else ""

        // Skip PINNED / FEATURED badge clutter so artwork stays clean
        val qualityRaw = card.select(".badge-group .badge, .quality")
            .map { it.text().trim() }
            .firstOrNull { txt ->
                txt.isNotBlank() &&
                    !txt.equals("PINNED", ignoreCase = true) &&
                    !txt.equals("FEATURED", ignoreCase = true)
            }
            .orEmpty()
        val quality = BanglaTranslator.translateUi(qualityRaw, polish)
        val language = BanglaTranslator.translateUi(
            card.selectFirst(".language")?.text()?.trim().orEmpty(),
            polish
        )
        val type = BanglaTranslator.translateUi(
            card.selectFirst(".type")?.text()?.trim().orEmpty(),
            polish
        )

        return MediaCard(
            title = rawTitle, // Strictly keep original movie/series title intact
            url = absUrl,
            posterUrl = posterUrl,
            quality = quality,
            language = language,
            type = type
        )
    }

    private fun parseDetailDocument(finalUrl: String, html: String, settings: UserSettings): MediaDetail {
        val doc = Jsoup.parse(html, finalUrl)
        val polish = settings.sitePolishEnabled

        val infoView = doc.selectFirst(".movie-info-view") ?: doc.body()
        // Keep original movie/series title intact
        val title = infoView.selectFirst("h1")?.text()?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: doc.title().substringBefore("|").substringBefore("—").trim()

        val subtitleRaw = infoView.selectFirst("p.text-yellow, .movie-subtitle")?.text()?.trim().orEmpty()
        val subtitle = BanglaTranslator.translateUi(subtitleRaw, polish)

        val posterImg = doc.selectFirst(".movie-poster img, .poster-img, .image-container img, meta[property=og:image]")
        val posterRaw = when {
            posterImg == null -> ""
            posterImg.tagName() == "meta" -> posterImg.attr("content")
            posterImg.attr("data-src").isNotBlank() && !posterImg.attr("data-src").contains("mlbd_load") -> posterImg.attr("data-src")
            else -> posterImg.attr("src")
        }
        val posterUrl = if (posterRaw.isNotBlank() && !posterRaw.startsWith("data:")) {
            LinkDecoder.resolveUrl(finalUrl, posterRaw)
        } else ""

        var typeVal = if (finalUrl.contains("/series/", true)) "Series" else "Movie"
        var langVal = "Multi"
        var qualVal = "HD"

        val flexItems = doc.select("ul.flex-container li.flex-item")
        for (li in flexItems) {
            val bold = li.selectFirst("b")?.text()?.trim().orEmpty()
            val full = li.text().trim()
            val key = full.removeSuffix(bold).trim().lowercase()
            val cleanVal = BanglaTranslator.translateUi(bold, polish)
            when {
                key.contains("type") -> if (cleanVal.isNotBlank()) typeVal = cleanVal
                key.contains("lang") -> if (cleanVal.isNotBlank()) langVal = cleanVal
                key.contains("qual") -> if (cleanVal.isNotBlank()) qualVal = cleanVal
            }
        }

        val scheduleCandidate = doc.select(".mlbd-ongoing, .ongoing-badge, .series-schedule, .movie-info-view p")
            .map { it.text().trim() }
            .firstOrNull { txt ->
                txt.isNotBlank() &&
                    txt != subtitleRaw &&
                    !BanglaTranslator.isClutterText(txt) &&
                    (txt.contains("Ongoing", true) || txt.contains("পর্ব") || txt.contains("প্রতি") || txt.contains("Every ", true))
            }.orEmpty()
        val scheduleText = BanglaTranslator.translateUi(scheduleCandidate, polish)

        val trailerYoutubeId = doc.selectFirst("[data-mlbd-trailer]")?.attr("data-mlbd-trailer")?.trim()
            ?.takeIf { it.isNotEmpty() }

        val watchSrc = doc.selectFirst("iframe#mlbdHdFrame, iframe[src*=/p/]")?.attr("src")?.trim()
        val watchEmbedUrl = if (!watchSrc.isNullOrBlank()) LinkDecoder.resolveUrl(finalUrl, watchSrc) else null

        val storylineRaw = doc.selectFirst(".storyline-box .story-text, .storyline-box p")?.text()?.trim().orEmpty()
        val storyline = BanglaTranslator.translateUi(storylineRaw, polish)

        val extraLines = doc.select(".movie-extra-info .info-line, .movie-extra-info p")
            .map { BanglaTranslator.translateUi(it.text().trim(), polish) }
            .filter { it.isNotBlank() && !BanglaTranslator.isClutterText(it) }
            .distinct()

        val cast = doc.select(".mlbd-cast__p").mapNotNull { el ->
            val name = el.selectFirst("b")?.text()?.trim().orEmpty()
            if (name.isBlank()) return@mapNotNull null
            val role = el.selectFirst("small")?.text()?.trim().orEmpty()
            val avatar = el.selectFirst("img")?.attr("src")?.trim().orEmpty()
            val profile = el.attr("href").trim().let {
                if (it.isNotEmpty()) LinkDecoder.resolveUrl(finalUrl, it) else ""
            }
            CastMember(name, role, avatar, profile)
        }

        val screenshotImgs = doc.select(
            ".screenshot-wrapper img, .screenshots-wrapper img, .preview-wrapper img, .previews-wrapper img, " +
            ".movie-screenshots img, .movie-previews img, #screenshots img, #previews img, " +
            ".screenshot-box img, .preview-box img, a[data-fancybox] img, a[data-fslightbox] img, a[data-lightbox] img"
        ).mapNotNull { img ->
            val dsrc = img.attr("data-src").trim()
            val src = img.attr("src").trim()
            val u = if (dsrc.isNotEmpty() && !dsrc.contains("mlbd_load")) dsrc else src
            if (u.isNotEmpty() && !u.startsWith("data:") && !u.contains("mlbd_load")) {
                LinkDecoder.resolveUrl(finalUrl, u)
            } else null
        }
        val previewAnchors = doc.select(
            ".screenshot-wrapper a, .preview-wrapper a, .screenshots-wrapper a, .previews-wrapper a, #screenshots a, #previews a"
        ).mapNotNull { a ->
            val href = a.attr("href").trim()
            if (href.isNotEmpty() && (href.endsWith(".jpg", true) || href.endsWith(".png", true) || href.endsWith(".webp", true) || href.endsWith(".jpeg", true))) {
                LinkDecoder.resolveUrl(finalUrl, href)
            } else null
        }
        val screenshotUrls = (screenshotImgs + previewAnchors)
            .filter { it.isNotBlank() && !it.contains("mlbd_load") }
            .distinct()

        // Episodes (for series)
        val episodes = mutableListOf<EpisodeItem>()
        val epCards = doc.select("#mlbdEpisodeDownloadGrid .ep-card")
        for (card in epCards) {
            val epTitleRaw = card.selectFirst(".mlbd-episode-title, h5, h4")?.ownText()?.trim()
                ?.ifBlank { card.selectFirst(".mlbd-episode-title, h5, h4")?.text()?.replace("NEW", "")?.trim().orEmpty() }
                .orEmpty()
            val epTitle = BanglaTranslator.translateUi(epTitleRaw, polish)
            val seasonNum = card.attr("data-season-number").trim().toIntOrNull()
            val epNum = card.attr("data-episode-number").trim().toIntOrNull()
            val isNew = card.selectFirst(".mlbd-ep-flag.is-new") != null
            val epLinks = extractDownloadLinks(card.select("a[data-dl], a.btn-user"), finalUrl, polish)
            if (epLinks.isNotEmpty()) {
                episodes.add(
                    EpisodeItem(
                        title = epTitle.ifBlank { "Episode ${epNum ?: episodes.size + 1}" },
                        seasonNumber = seasonNum,
                        episodeNumber = epNum,
                        isNew = isNew,
                        downloads = epLinks
                    )
                )
            }
        }

        // Season zip packs
        val seasonZips = extractDownloadLinks(
            doc.select("#mlbdSeasonZipDownloads a[data-dl], #mlbdZipDownloadGrid a[data-dl]"),
            finalUrl,
            polish,
            markZip = true
        )

        // Direct movie downloads (excluding those already inside #mlbdEpisodeDownloadGrid or #mlbdSeasonZipDownloads)
        val allAnchors = doc.select("a[data-dl], a.btn-dark.btn-user")
            .filter { el ->
                el.parents().none { p ->
                    p.id() == "mlbdEpisodeDownloadGrid" ||
                        p.id() == "mlbdSeasonZipDownloads" ||
                        p.id() == "mlbdZipDownloadGrid"
                }
            }
        val movieDownloads = extractDownloadLinks(allAnchors, finalUrl, polish)

        val related = doc.select(".movie-card")
            .mapNotNull { parseMovieCard(it, finalUrl, polish) }
            .filterNot { it.url == finalUrl }
            .distinctBy { it.url }
            .take(12)

        val ratingRaw = doc.selectFirst(".mlbd-rating-box, .community-rating, .rating-summary")?.text()?.trim()
        val ratingSummary = ratingRaw?.let { BanglaTranslator.translateUi(it, polish) }
            ?.takeIf { it.isNotBlank() && !BanglaTranslator.isClutterText(it) }

        return MediaDetail(
            url = finalUrl,
            title = title,
            subtitle = subtitle,
            posterUrl = posterUrl,
            type = typeVal,
            language = langVal,
            quality = qualVal,
            scheduleText = scheduleText,
            trailerYoutubeId = trailerYoutubeId,
            watchEmbedUrl = watchEmbedUrl,
            storyline = storyline,
            extraInfoLines = extraLines,
            cast = cast,
            screenshotUrls = screenshotUrls,
            downloadLinks = movieDownloads,
            episodes = episodes,
            seasonZipLinks = seasonZips,
            relatedItems = related,
            communityRatingSummary = ratingSummary
        )
    }

    private fun extractDownloadLinks(
        elements: List<Element>,
        baseUrl: String,
        polish: Boolean,
        markZip: Boolean = false
    ): List<DownloadOption> {
        val out = mutableListOf<DownloadOption>()
        val seen = hashSetOf<String>()
        for (a in elements) {
            val dataDl = a.attr("data-dl").trim()
            val decodedPath = if (dataDl.isNotEmpty()) {
                val ds = a.attr("data-ds").trim()
                val dr = a.attr("data-dr").trim().toIntOrNull() ?: 0
                LinkDecoder.decodeToken(dataDl, ds, dr)
            } else {
                a.attr("href").trim().takeIf { it.isNotEmpty() && it != "#" }
            }
            if (decodedPath.isNullOrBlank()) continue
            val abs = LinkDecoder.resolveUrl(baseUrl, decodedPath)
            if (BanglaTranslator.isClutterText(a.text())) continue
            val rawLabel = a.text().trim().replace(Regex("""\s+"""), " ")
            val label = BanglaTranslator.translateUi(rawLabel, polish)
                .ifBlank { "Download" }
            val key = "$label|$abs"
            if (seen.add(key)) {
                out.add(DownloadOption(label, abs, markZip || label.contains("zip", true)))
            }
        }
        return out
    }
}
