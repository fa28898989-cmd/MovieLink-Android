package com.personal.movielink

import android.util.Base64
import java.net.URI

object LinkDecoder {
    /**
     * Decodes click-based download tokens (`data-dl` / `data-ds` / `data-dr`)
     * using the site's deterministic 32-bit LCG XOR cipher.
     */
    fun decodeToken(dataDl: String, dataDs: String, dataDr: Int): String? {
        if (dataDl.isBlank()) return null
        return try {
            var x = (dataDs.trim().toLongOrNull(16) ?: 0L) and 0xFFFFFFFFL
            val rounds = dataDr.coerceIn(0, 5000)
            repeat(rounds) {
                x = (x * 1103515245L + 12345L) and 0xFFFFFFFFL
            }
            val raw = Base64.decode(dataDl, Base64.DEFAULT)
            val out = StringBuilder(raw.size)
            for (b in raw) {
                x = (x * 1103515245L + 12345L) and 0xFFFFFFFFL
                val keyByte = ((x ushr 16) and 0xFFL).toInt()
                val ch = (b.toInt() and 0xFF) xor keyByte
                out.append(ch.toChar())
            }
            out.toString().takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    fun resolveUrl(baseUrl: String, relativeOrAbsolute: String): String {
        val trimmed = relativeOrAbsolute.trim()
        if (trimmed.isEmpty()) return baseUrl
        return try {
            URI(baseUrl).resolve(trimmed).toString()
        } catch (_: Exception) {
            if (trimmed.startsWith("http", ignoreCase = true)) trimmed
            else baseUrl.trimEnd('/') + "/" + trimmed.trimStart('/')
        }
    }
}
