package com.personal.movielink.ui.player

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.personal.movielink.AdBlocker
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.PlayerLaunchRequest
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import java.io.ByteArrayInputStream
import java.util.Locale
import kotlin.math.pow

@OptIn(UnstableApi::class)
@Composable
fun NativeVideoPlayerScreen(
    request: PlayerLaunchRequest,
    settings: UserSettings,
    httpClient: OkHttpClient,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current
    val palette = LocalMovieLinkPalette.current

    // Perceptual gamma-curved window screen brightness (strictly scoped to fullscreen playback)
    var brightnessLevel by remember { mutableFloatStateOf(0.65f) }
    var showBrightnessHud by remember { mutableStateOf(false) }
    var hasUserAdjustedBrightness by remember { mutableStateOf(false) }

    val initialCutoutMode = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            activity?.window?.attributes?.layoutInDisplayCutoutMode
                ?: WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        } else {
            0
        }
    }

    fun applyWindowBrightness(linearLevel: Float?) {
        val window = activity?.window ?: return
        val lp = window.attributes
        lp.screenBrightness = if (linearLevel == null) {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        } else {
            // Perceptual gamma curve (x^2.2) so slider dims smoothly below default device level
            linearLevel.coerceIn(0f, 1f).pow(2.2f).coerceIn(0.004f, 1.0f)
        }
        window.attributes = lp
    }

    fun setFullscreenSystemUi(enable: Boolean) {
        val window = activity?.window ?: return
        if (enable) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                window.attributes = lp
            }
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = initialCutoutMode
                window.attributes = lp
            }
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.statusBarColor = palette.pageBg.toArgb()
            window.navigationBarColor = palette.pageBg.toArgb()
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    DisposableEffect(Unit) {
        setFullscreenSystemUi(true)
        onDispose {
            applyWindowBrightness(null)
            setFullscreenSystemUi(false)
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE,
                Lifecycle.Event.ON_STOP,
                Lifecycle.Event.ON_DESTROY -> applyWindowBrightness(null)
                Lifecycle.Event.ON_RESUME -> {
                    setFullscreenSystemUi(true)
                    if (settings.playerBrightnessSync && hasUserAdjustedBrightness) {
                        applyWindowBrightness(brightnessLevel)
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    BackHandler {
        applyWindowBrightness(null)
        onClose()
    }

    LaunchedEffect(showBrightnessHud) {
        if (showBrightnessHud) {
            delay(1300)
            showBrightnessHud = false
        }
    }

    var fillScreen by remember { mutableStateOf(false) }

    if (request.isEmbedPage) {
        // Website default /p/... player rendered edge-to-edge (including behind notch) with ad-blocking,
        // theme visual styling, optional bottom mini-progress hiding, and hardware window brightness sync
        var webViewRef by remember { mutableStateOf<WebView?>(null) }
        var isPageLoading by remember { mutableStateOf(true) }
        var showEmbedControls by remember { mutableStateOf(false) }
        val accentHex = remember(palette.fg) { Config.toHex(palette.fg.toArgb()) }

        LaunchedEffect(fillScreen, webViewRef) {
            webViewRef?.let { wv ->
                injectPlayerEnhancements(
                    view = wv,
                    accentHex = accentHex,
                    hideProgressBar = settings.hideVideoProgressBar,
                    brightnessSync = settings.playerBrightnessSync,
                    englishPolish = settings.sitePolishEnabled,
                    fillScreen = fillScreen
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            EmbedPlayerWebView(
                embedUrl = request.streamUrl,
                refererUrl = request.refererUrl,
                settings = settings,
                accentHex = accentHex,
                fillScreen = fillScreen,
                onWebViewReady = { webViewRef = it },
                onLoadingChanged = { loading -> isPageLoading = loading },
                onControlsVisibilityChanged = { visible -> showEmbedControls = visible },
                onBrightnessBridge = { level ->
                    if (settings.playerBrightnessSync) {
                        hasUserAdjustedBrightness = true
                        brightnessLevel = level
                        applyWindowBrightness(level)
                    }
                }
            )

            if (isPageLoading) {
                CircularProgressIndicator(
                    color = palette.fg,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(40.dp)
                )
            }

            // Top-left Back button: only visible when user taps screen (synced with pd2 controls) or while loading
            AnimatedVisibility(
                visible = showEmbedControls || isPageLoading,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(10.dp)
            ) {
                IconButton(
                    onClick = {
                        applyWindowBrightness(null)
                        onClose()
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x99080A0F))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Exit Fullscreen",
                        tint = Color.White
                    )
                }
            }

            // Top-right Fit/Fill & VLC / MX Player handoff buttons: only visible when user taps screen
            AnimatedVisibility(
                visible = showEmbedControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = { fillScreen = !fillScreen },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x99080A0F))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AspectRatio,
                            contentDescription = if (fillScreen) "Fit Video" else "Fill Screen",
                            tint = if (fillScreen) palette.fg else Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            val wv = webViewRef
                            if (wv != null) {
                                wv.evaluateJavascript(
                                    """
                                    (function(){
                                      var p = window.__PD2;
                                      if (!p) return '';
                                      if (p.mp4) return p.mp4;
                                      if (p.episodes && p.episodes.length) {
                                        var ep = p.episodes[0];
                                        if (ep.mp4) return ep.mp4;
                                        if (ep.master) return ep.master;
                                      }
                                      return p.master || '';
                                    })();
                                    """.trimIndent()
                                ) { res ->
                                    val extracted = res?.trim('"').orEmpty()
                                    val target = if (extracted.startsWith("http")) extracted else request.streamUrl
                                    DownloadAndPlayerRouter.launchExternalPlayer(
                                        context = context,
                                        url = target,
                                        referer = request.streamUrl,
                                        userAgent = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
                                    )
                                }
                            } else {
                                DownloadAndPlayerRouter.launchExternalPlayer(
                                    context = context,
                                    url = request.streamUrl,
                                    referer = request.refererUrl,
                                    userAgent = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
                                )
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x99080A0F))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.OpenInNew,
                            contentDescription = "Play in VLC / MX Player",
                            tint = palette.fg
                        )
                    }
                }
            }
        }
        return
    }

    // Native Media3 ExoPlayer path for direct video URLs (.mp4 / .mkv / .m3u8) & local media (content:// / file://)
    var showControls by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var playerError by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var positionMs by remember { mutableLongStateOf(0L) }

    LaunchedEffect(showControls, isPlaying) {
        if (showControls && isPlaying) {
            delay(3000)
            showControls = false
        }
    }

    val exoPlayer = remember(request.streamUrl) {
        val parsedUri = Uri.parse(request.streamUrl)
        val headers = buildMap {
            if (request.refererUrl.isNotBlank()) put("Referer", request.refererUrl)
            put("User-Agent", if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT)
        }
        val okFactory = OkHttpDataSource.Factory(httpClient)
            .setDefaultRequestProperties(headers)
        val dataSourceFactory = DefaultDataSource.Factory(context, okFactory)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build().apply {
                setMediaItem(MediaItem.fromUri(parsedUri))
                prepare()
                playWhenReady = true
            }
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                durationMs = exoPlayer.duration.coerceAtLeast(0L)
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                playerError = error.localizedMessage ?: "Unable to play this video format"
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { showControls = !showControls },
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    keepScreenOn = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv ->
                pv.resizeMode = if (fillScreen) {
                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                } else {
                    AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            }
        )

        // Left-edge vertical brightness gesture zone (strictly controls window.screenBrightness, never media volume)
        if (settings.playerBrightnessSync) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .width(56.dp)
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, dragAmount ->
                            change.consume()
                            val delta = -dragAmount / size.height.toFloat()
                            val next = (brightnessLevel + delta * 1.25f).coerceIn(0f, 1f)
                            brightnessLevel = next
                            hasUserAdjustedBrightness = true
                            showBrightnessHud = true
                            applyWindowBrightness(next)
                        }
                    }
            )
        }

        // Left-edge Brightness HUD bar
        if (showBrightnessHud && settings.playerBrightnessSync) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 20.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xCC0A0C12))
                    .padding(horizontal = 10.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.BrightnessMedium,
                    contentDescription = "Screen Brightness",
                    tint = palette.fg,
                    modifier = Modifier.size(18.dp)
                )
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .height(110.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0x33FFFFFF)),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(brightnessLevel.coerceIn(0.03f, 1f))
                            .background(palette.fg)
                    )
                }
                Text(
                    text = "${(brightnessLevel * 100).toInt()}%",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        if (isBuffering && playerError == null) {
            CircularProgressIndicator(
                color = palette.fg,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
            )
        }

        playerError?.let { err ->
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xDD0A0C12))
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Playback Error",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = err,
                    color = Color(0xFFB4B4BC),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            DownloadAndPlayerRouter.launchExternalPlayer(
                                context = context,
                                url = request.streamUrl,
                                referer = request.refererUrl,
                                userAgent = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.fg,
                            contentColor = palette.onAccent
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Open in VLC / MX", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            applyWindowBrightness(null)
                            onClose()
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Close", color = Color.White, fontSize = 12.5.sp)
                    }
                }
            }
        }

        if (showControls) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    applyWindowBrightness(null)
                    onClose()
                }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Exit Fullscreen",
                        tint = Color.White
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = request.title,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (request.subtitle.isNotBlank()) {
                        Text(
                            text = request.subtitle,
                            color = Color(0xFFB4B4BC),
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(onClick = { fillScreen = !fillScreen }) {
                    Icon(
                        imageVector = Icons.Rounded.AspectRatio,
                        contentDescription = if (fillScreen) "Fit Video" else "Fill Screen",
                        tint = if (fillScreen) palette.fg else Color.White
                    )
                }
                IconButton(onClick = {
                    DownloadAndPlayerRouter.launchExternalPlayer(
                        context = context,
                        url = request.streamUrl,
                        referer = request.refererUrl,
                        userAgent = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
                    )
                }) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInNew,
                        contentDescription = "Play in VLC / MX Player",
                        tint = palette.fg
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(36.dp))
                    .background(Color(0xAA0A0C12))
                    .clickable {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    }
                    .padding(14.dp)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }

            if (!settings.hideVideoProgressBar && durationMs > 0L) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color(0x99000000))
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = formatMs(positionMs), color = Color.White, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = positionMs.toFloat(),
                        onValueChange = { exoPlayer.seekTo(it.toLong()) },
                        valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
                        colors = SliderDefaults.colors(
                            thumbColor = palette.fg,
                            activeTrackColor = palette.fg
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(text = formatMs(durationMs), color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun EmbedPlayerWebView(
    embedUrl: String,
    refererUrl: String,
    settings: UserSettings,
    accentHex: String,
    fillScreen: Boolean,
    onWebViewReady: (WebView) -> Unit,
    onLoadingChanged: (Boolean) -> Unit,
    onControlsVisibilityChanged: (Boolean) -> Unit,
    onBrightnessBridge: (Float) -> Unit
) {
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var customViewContainer by remember { mutableStateOf<FrameLayout?>(null) }
    var customFullscreenView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    class BrightnessBridge {
        @JavascriptInterface
        fun setBrightness(level: Float) {
            mainHandler.post { onBrightnessBridge(level.coerceIn(0f, 1f)) }
        }

        @JavascriptInterface
        fun setControlsVisible(visible: Boolean) {
            mainHandler.post { onControlsVisibilityChanged(visible) }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    keepScreenOn = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    this.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        javaScriptCanOpenWindowsAutomatically = false
                        setSupportMultipleWindows(false)
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        userAgentString = if (settings.desktopMode) {
                            Config.DESKTOP_USER_AGENT
                        } else {
                            Config.MOBILE_USER_AGENT
                        }
                    }

                    addJavascriptInterface(BrightnessBridge(), "MovieLinkPlayerBridge")

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView,
                            request: WebResourceRequest
                        ): WebResourceResponse? {
                            if (AdBlocker.shouldBlock(request.url, settings)) {
                                return WebResourceResponse(
                                    "text/plain",
                                    "utf-8",
                                    ByteArrayInputStream(ByteArray(0))
                                )
                            }
                            return null
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest
                        ): Boolean {
                            val uri = request.url
                            if (uri.scheme != "http" && uri.scheme != "https") return true
                            if (AdBlocker.shouldBlock(uri, settings)) return true
                            val host = uri.host.orEmpty()
                            // Stay inside embed player; block external popup redirects
                            return !Config.isInternal(host, settings.mirrorUrl)
                        }

                        override fun onPageCommitVisible(view: WebView, url: String?) {
                            injectPlayerEnhancements(
                                view = view,
                                accentHex = accentHex,
                                hideProgressBar = settings.hideVideoProgressBar,
                                brightnessSync = settings.playerBrightnessSync,
                                englishPolish = settings.sitePolishEnabled,
                                fillScreen = fillScreen
                            )
                        }

                        override fun onPageFinished(view: WebView, url: String?) {
                            onLoadingChanged(false)
                            CookieManager.getInstance().flush()
                            injectPlayerEnhancements(
                                view = view,
                                accentHex = accentHex,
                                hideProgressBar = settings.hideVideoProgressBar,
                                brightnessSync = settings.playerBrightnessSync,
                                englishPolish = settings.sitePolishEnabled,
                                fillScreen = fillScreen
                            )
                            mainHandler.postDelayed({
                                injectPlayerEnhancements(
                                    view = view,
                                    accentHex = accentHex,
                                    hideProgressBar = settings.hideVideoProgressBar,
                                    brightnessSync = settings.playerBrightnessSync,
                                    englishPolish = settings.sitePolishEnabled,
                                    fillScreen = fillScreen
                                )
                            }, 250)
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            if (view == null) return
                            if (newProgress >= 20) {
                                injectPlayerEnhancements(
                                    view = view,
                                    accentHex = accentHex,
                                    hideProgressBar = settings.hideVideoProgressBar,
                                    brightnessSync = settings.playerBrightnessSync,
                                    englishPolish = settings.sitePolishEnabled,
                                    fillScreen = fillScreen
                                )
                            }
                            if (newProgress >= 80) {
                                onLoadingChanged(false)
                            }
                        }

                        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                            if (view == null) return
                            customFullscreenView?.let { old -> customViewContainer?.removeView(old) }
                            customFullscreenView = view
                            customViewCallback = callback
                            customViewContainer?.apply {
                                visibility = View.VISIBLE
                                addView(
                                    view,
                                    FrameLayout.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                )
                            }
                        }

                        override fun onHideCustomView() {
                            customFullscreenView?.let { customViewContainer?.removeView(it) }
                            customFullscreenView = null
                            customViewContainer?.visibility = View.GONE
                            customViewCallback?.onCustomViewHidden()
                            customViewCallback = null
                        }
                    }

                    loadUrl(embedUrl, mapOf("Referer" to refererUrl))
                    webRef = this
                    onWebViewReady(this)
                }
            }
        )

        // Overlay container for HTML5 fullscreen customView if triggered inside pd2.js
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                FrameLayout(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    visibility = View.GONE
                    customViewContainer = this
                }
            }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                customViewCallback?.onCustomViewHidden()
            } catch (_: Exception) {
            }
            webRef?.stopLoading()
            webRef?.destroy()
            webRef = null
        }
    }
}

private fun injectPlayerEnhancements(
    view: WebView,
    accentHex: String,
    hideProgressBar: Boolean,
    brightnessSync: Boolean,
    englishPolish: Boolean,
    fillScreen: Boolean
) {
    val hideMiniCss = if (hideProgressBar) {
        ".mini-progress,.mini-progress-fill{opacity:0!important;display:none!important;pointer-events:none!important;}" +
            ".player.idle .controls,.player.idle .progress-wrap{opacity:0!important;pointer-events:none!important;}"
    } else ""

    val brightCss = if (brightnessSync) {
        ".bright-veil{opacity:0!important;display:none!important;pointer-events:none!important;}"
    } else ""

    val objectFit = if (fillScreen) "cover" else "contain"

    val js = """
        (function(){
          try {
            var vp = document.querySelector('meta[name="viewport"]');
            if (!vp) {
              vp = document.createElement('meta');
              vp.name = 'viewport';
              (document.head || document.documentElement).appendChild(vp);
            }
            vp.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';

            var st = document.getElementById('__ml_player_theme');
            if (!st) {
              st = document.createElement('style');
              st.id = '__ml_player_theme';
              (document.head || document.documentElement).appendChild(st);
            }
            st.textContent = ':root{--ac:$accentHex!important;--ac2:$accentHex!important;--accent:$accentHex!important;--accent-hi:$accentHex!important;--ac-soft:${accentHex}29!important;--ac-glow:${accentHex}80!important;--accent-glow:${accentHex}59!important;}' +
              'html,body{margin:0!important;padding:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;overflow:hidden!important;background:#000!important;}' +
              '.embed-wrap,#player,.player{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;border-radius:0!important;background:#000!important;}' +
              '#player video,.player video,video{position:absolute!important;inset:0!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;object-fit:$objectFit!important;object-position:center center!important;margin:0 auto!important;background:#000!important;}' +
              '#btnHomeBack,#btnShare,.embed-share-btn{display:none!important;}' +
              '.embed-chrome-top{padding:12px 110px!important;}' +
              '.progress-played,.mini-progress-fill,.vol-hud-fill,.bright-hud .vol-hud-fill{background:$accentHex!important;}' +
              '.progress-handle{background:$accentHex!important;box-shadow:0 0 0 4px ${accentHex}38!important;}' +
              '.pv-orb{border-color:$accentHex!important;}' +
              '$hideMiniCss' +
              '$brightCss';

            if (${englishPolish}) {
              var translatePlayerDom = function() {
                try {
                  var replacements = [
                    ['ভিডিও লোড হচ্ছে...', 'Loading video...'],
                    ['ভিডিও লোড হচ্ছে…', 'Loading video...'],
                    ['ভিডিও লোড হচ্ছে', 'Loading video...'],
                    ['Ready হচ্ছে', 'Loading video'],
                    ['লোড হচ্ছে', 'Loading'],
                    ['এই ভিডিওটি অনলাইনে চলছে না', 'This video cannot play online'],
                    ['কোয়ালিটিটি', 'This quality'],
                    ['আপনার ডিভাইস/ব্রাউজার অনলাইনে চালাতে পারছে না।', 'is not supported by your device/browser.'],
                    ['নিচে থেকে', 'Tap'],
                    ['করে', 'below to watch in'],
                    ['-এ দেখুন।', '.'],
                    ['দেখুন।', '.'],
                    ['Download করুন', 'Download']
                  ];
                  var pvTxt = document.querySelector('.pv-txt');
                  if (pvTxt) {
                    var t = (pvTxt.textContent || '').trim();
                    if (/[\u0980-\u09FF]/.test(t) || t.indexOf('Ready') !== -1) {
                      pvTxt.textContent = 'Loading video…';
                    }
                  }
                  var root = document.body || document.documentElement;
                  if (root && /[\u0980-\u09FF]/.test(root.innerText || '')) {
                    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
                    var node;
                    while ((node = walker.nextNode())) {
                      var val = node.nodeValue;
                      if (!val || !/[\u0980-\u09FF]/.test(val)) continue;
                      var next = val;
                      for (var i = 0; i < replacements.length; i++) {
                        if (next.indexOf(replacements[i][0]) !== -1) {
                          next = next.split(replacements[i][0]).join(replacements[i][1]);
                        }
                      }
                      if (/[\u0980-\u09FF]/.test(next)) {
                        next = next.replace(/[\u0980-\u09FF]+/g, 'Loading');
                      }
                      if (next !== val) node.nodeValue = next;
                    }
                  }
                } catch(_) {}
              };
              translatePlayerDom();
              if (!window.__mlBnObserver && document.documentElement) {
                window.__mlBnObserver = true;
                new MutationObserver(translatePlayerDom).observe(document.documentElement, {
                  childList: true,
                  characterData: true,
                  subtree: true
                });
              }
            }

            if (${brightnessSync} && !window.__mlBrightHooked && window.MovieLinkPlayerBridge) {
              window.__mlBrightHooked = true;
              var lvlEl = document.getElementById('brightHudLevel');
              var veilEl = document.querySelector('.bright-veil');
              var syncFromHud = function() {
                try {
                  if (lvlEl && lvlEl.textContent) {
                    var num = parseFloat(lvlEl.textContent.replace('%','').trim());
                    if (!isNaN(num)) {
                      window.MovieLinkPlayerBridge.setBrightness(Math.max(0.02, Math.min(1, num / 100)));
                      return;
                    }
                  }
                  if (veilEl && veilEl.style && veilEl.style.opacity !== '') {
                    var op = parseFloat(veilEl.style.opacity);
                    if (!isNaN(op)) {
                      var lin = Math.max(0.02, Math.min(1, 1 - (op / 0.8)));
                      window.MovieLinkPlayerBridge.setBrightness(lin);
                    }
                  }
                } catch(_) {}
              };
              if (lvlEl) {
                new MutationObserver(syncFromHud).observe(lvlEl, { childList: true, characterData: true, subtree: true });
              }
              if (veilEl) {
                new MutationObserver(syncFromHud).observe(veilEl, { attributes: true, attributeFilter: ['style'] });
              }
            }

            var pEl = document.getElementById('player');
            if (pEl && !window.__mlControlsHooked && window.MovieLinkPlayerBridge) {
              window.__mlControlsHooked = true;
              var lastVis = null;
              var syncControls = function() {
                try {
                  var isIdle = pEl.classList.contains('idle');
                  var isLocked = pEl.classList.contains('locked');
                  var vis = !isIdle && !isLocked;
                  if (vis !== lastVis) {
                    lastVis = vis;
                    window.MovieLinkPlayerBridge.setControlsVisible(!!vis);
                  }
                } catch(_) {}
              };
              syncControls();
              new MutationObserver(syncControls).observe(pEl, { attributes: true, attributeFilter: ['class'] });
            }

            if (!window.__mlAutoPlayTried) {
              var tryPlay = function() {
                try {
                  var v = document.getElementById('video');
                  if (v && v.paused) {
                    window.__mlAutoPlayTried = true;
                    var orb = document.getElementById('pvLoad') || document.querySelector('.big-play');
                    if (orb && orb.click) orb.click();
                    if (v.play) v.play().catch(function(){});
                  }
                } catch(_) {}
              };
              tryPlay();
              setTimeout(tryPlay, 120);
            }
          } catch(e) {}
        })();
    """.trimIndent()

    view.evaluateJavascript(js, null)
}

private fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600L
    val m = (totalSec % 3600L) / 60L
    val s = totalSec % 60L
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}
