package com.personal.movielink.ui.player

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.personal.movielink.AdBlocker
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.PlayerLaunchRequest
import com.personal.movielink.PlayerSubtitleTrack
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlinx.coroutines.delay
import okhttp3.OkHttpClient
import org.json.JSONArray
import java.io.ByteArrayInputStream
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale
import javax.net.ssl.SSLException
import kotlin.math.pow
import kotlin.math.roundToInt

private enum class PlayerAspectMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    ZOOM("Zoom"),
    STRETCH("Stretch"),
    ORIGINAL("Original")
}

private enum class PlayerOverlayPanel {
    NONE,
    ASPECT,
    SPEED,
    SUBTITLES,
    AUDIO
}

private data class SelectableTrackItem(
    val groupIndex: Int,
    val trackIndex: Int,
    val label: String,
    val subtitle: String,
    val isSelected: Boolean
)

private val PLAYBACK_SPEED_OPTIONS = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)

@OptIn(UnstableApi::class)
@Composable
fun NativeVideoPlayerScreen(
    request: PlayerLaunchRequest,
    settings: UserSettings,
    httpClient: OkHttpClient,
    savedPositionMs: Long = 0L,
    onSaveProgress: (positionMs: Long, durationMs: Long) -> Unit = { _, _ -> },
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current
    val palette = LocalMovieLinkPalette.current

    val audioManager = remember(context) {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }
    val maxVolume = remember(audioManager) {
        (audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15).coerceAtLeast(1)
    }
    var volumeLevel by remember {
        val currentVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 8
        mutableFloatStateOf((currentVol.toFloat() / maxVolume.toFloat()).coerceIn(0f, 1f))
    }
    var showVolumeHud by remember { mutableStateOf(false) }

    // Perceptual gamma-curved window screen brightness (strictly scoped to fullscreen playback)
    var brightnessLevel by remember { mutableFloatStateOf(0.65f) }
    var showBrightnessHud by remember { mutableStateOf(false) }
    var hasUserAdjustedBrightness by remember { mutableStateOf(false) }

    var aspectMode by remember(request.streamUrl) { mutableStateOf(PlayerAspectMode.FIT) }
    var playbackSpeed by remember(request.streamUrl) { mutableFloatStateOf(1.0f) }
    var activePanel by remember(request.streamUrl) { mutableStateOf(PlayerOverlayPanel.NONE) }
    var showAspectHud by remember { mutableStateOf(false) }
    var seekHudDeltaSec by remember { mutableStateOf<Int?>(null) }
    var seekHudNonce by remember { mutableIntStateOf(0) }
    var resumeHudMessage by remember(request.streamUrl) { mutableStateOf<String?>(null) }

    val initialCutoutMode = remember {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            activity?.window?.attributes?.layoutInDisplayCutoutMode
                ?: WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        } else {
            0
        }
    }

    fun applyWindowBrightness(linearLevel: Float?) {
        val window = activity?.window ?: return
        val lp = window.attributes
        lp.screenBrightness = if (linearLevel == null) {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        } else {
            linearLevel.coerceIn(0f, 1f).pow(2.2f).coerceIn(0.004f, 1.0f)
        }
        window.attributes = lp
    }

    fun applyMediaVolume(fraction: Float) {
        val clamped = fraction.coerceIn(0f, 1f)
        volumeLevel = clamped
        val targetIndex = (clamped * maxVolume).roundToInt().coerceIn(0, maxVolume)
        try {
            audioManager?.setStreamVolume(AudioManager.STREAM_MUSIC, targetIndex, 0)
        } catch (_: Exception) {
        }
        showVolumeHud = true
    }

    fun setFullscreenSystemUi(enable: Boolean) {
        val window = activity?.window ?: return
        if (enable) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else {
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                window.attributes = lp
            }
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = initialCutoutMode
                window.attributes = lp
            }
            WindowCompat.setDecorFitsSystemWindows(window, true)
            window.statusBarColor = palette.pageBg.toArgb()
            window.navigationBarColor = palette.pageBg.toArgb()
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    DisposableEffect(Unit) {
        setFullscreenSystemUi(true)
        onDispose {
            applyWindowBrightness(null)
            setFullscreenSystemUi(false)
        }
    }

    LaunchedEffect(showBrightnessHud) {
        if (showBrightnessHud) {
            delay(1300)
            showBrightnessHud = false
        }
    }

    LaunchedEffect(showVolumeHud) {
        if (showVolumeHud) {
            delay(1300)
            showVolumeHud = false
        }
    }

    LaunchedEffect(showAspectHud, aspectMode) {
        if (showAspectHud) {
            delay(1300)
            showAspectHud = false
        }
    }

    LaunchedEffect(seekHudNonce) {
        if (seekHudNonce > 0) {
            delay(800)
            seekHudDeltaSec = null
        }
    }

    LaunchedEffect(resumeHudMessage) {
        if (resumeHudMessage != null) {
            delay(2200)
            resumeHudMessage = null
        }
    }

    if (request.isEmbedPage) {
        var webViewRef by remember { mutableStateOf<WebView?>(null) }
        var isPageLoading by remember { mutableStateOf(true) }
        var isEmbedBuffering by remember { mutableStateOf(true) }
        var isEmbedPlaying by remember { mutableStateOf(false) }
        var showEmbedControls by remember { mutableStateOf(false) }
        var embedPositionMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
        var embedDurationMs by remember(request.streamUrl) { mutableLongStateOf(0L) }
        var embedTextTracks by remember(request.streamUrl) { mutableStateOf<List<SelectableTrackItem>>(emptyList()) }
        var embedAudioTracks by remember(request.streamUrl) { mutableStateOf<List<SelectableTrackItem>>(emptyList()) }
        var hasAppliedEmbedResume by remember(request.streamUrl) { mutableStateOf(false) }
        val accentHex = remember(palette.fg) { Config.toHex(palette.fg.toArgb()) }

        fun persistEmbedProgressNow() {
            if (embedPositionMs >= 5_000L || (embedDurationMs > 60_000L && embedPositionMs >= embedDurationMs - 20_000L)) {
                onSaveProgress(embedPositionMs, embedDurationMs)
            }
        }

        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                when (event) {
                    Lifecycle.Event.ON_PAUSE,
                    Lifecycle.Event.ON_STOP,
                    Lifecycle.Event.ON_DESTROY -> {
                        persistEmbedProgressNow()
                        applyWindowBrightness(null)
                    }
                    Lifecycle.Event.ON_RESUME -> {
                        setFullscreenSystemUi(true)
                        if (settings.playerBrightnessSync && hasUserAdjustedBrightness) {
                            applyWindowBrightness(brightnessLevel)
                        }
                    }
                    else -> Unit
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                persistEmbedProgressNow()
                lifecycleOwner.lifecycle.removeObserver(observer)
            }
        }

        BackHandler {
            persistEmbedProgressNow()
            applyWindowBrightness(null)
            onClose()
        }

        LaunchedEffect(aspectMode, playbackSpeed, webViewRef) {
            webViewRef?.let { wv ->
                injectPlayerEnhancements(
                    view = wv,
                    accentHex = accentHex,
                    hideProgressBar = settings.hideVideoProgressBar,
                    brightnessSync = settings.playerBrightnessSync,
                    englishPolish = settings.sitePolishEnabled,
                    aspectMode = aspectMode,
                    playbackSpeed = playbackSpeed
                )
            }
        }

        val showSingleLoading = isPageLoading || isEmbedBuffering

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            EmbedPlayerWebView(
                embedUrl = request.streamUrl,
                refererUrl = request.refererUrl,
                settings = settings,
                accentHex = accentHex,
                aspectMode = aspectMode,
                playbackSpeed = playbackSpeed,
                onWebViewReady = { webViewRef = it },
                onLoadingChanged = { loading -> isPageLoading = loading },
                onMediaStateChanged = { playing, buffering ->
                    isEmbedPlaying = playing
                    isEmbedBuffering = buffering
                },
                onMediaProgress = { posMs, durMs ->
                    embedPositionMs = posMs
                    if (durMs > 0L) embedDurationMs = durMs
                    if (!hasAppliedEmbedResume && savedPositionMs >= 5_000L && durMs > 15_000L && savedPositionMs < durMs - 15_000L) {
                        hasAppliedEmbedResume = true
                        val targetSec = (savedPositionMs / 1000.0)
                        webViewRef?.evaluateJavascript(
                            "(function(){var v=document.getElementById('video')||document.querySelector('video');if(v&&v.duration>15){v.currentTime=$targetSec;}})();",
                            null
                        )
                        resumeHudMessage = "Resumed from ${formatMs(savedPositionMs)}"
                    }
                },
                onTracksUpdated = { textList, audioList ->
                    embedTextTracks = textList
                    embedAudioTracks = audioList
                },
                onSeekHud = { deltaSec ->
                    seekHudDeltaSec = deltaSec
                    seekHudNonce++
                },
                onControlsVisibilityChanged = { visible ->
                    showEmbedControls = visible
                    if (!visible) activePanel = PlayerOverlayPanel.NONE
                },
                onBrightnessBridge = { level ->
                    if (settings.playerBrightnessSync) {
                        hasUserAdjustedBrightness = true
                        brightnessLevel = level
                        applyWindowBrightness(level)
                    }
                }
            )

            // Right-edge vertical media volume gesture zone (does not intercept single taps on player controls)
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(vertical = 58.dp)
                    .fillMaxHeight()
                    .width(56.dp)
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onDragStart = {
                                val curr = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                                volumeLevel = (curr.toFloat() / maxVolume.toFloat()).coerceIn(0f, 1f)
                            }
                        ) { change, dragAmount ->
                            change.consume()
                            val delta = -dragAmount / size.height.toFloat()
                            applyMediaVolume(volumeLevel + delta * 1.25f)
                        }
                    }
            )

            if (showVolumeHud) {
                VerticalHudMeter(
                    icon = if (volumeLevel <= 0.01f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                    contentDescription = "Media Volume",
                    level = volumeLevel,
                    accent = palette.fg,
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 20.dp)
                )
            }

            // Center state: strictly show EITHER single loading spinner OR single Play/Pause toggle, never both
            if (showSingleLoading) {
                CircularProgressIndicator(
                    color = palette.fg,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(40.dp)
                )
            } else if (showEmbedControls) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(36.dp))
                        .background(Color(0xAA0A0C12))
                        .clickable {
                            webViewRef?.evaluateJavascript(
                                "(function(){var v=document.getElementById('video')||document.querySelector('video');if(!v)return;if(v.paused){v.play&&v.play().catch(function(){});}else{v.pause&&v.pause();}})();",
                                null
                            )
                        }
                        .padding(14.dp)
                ) {
                    Icon(
                        imageVector = if (isEmbedPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isEmbedPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }
            }

            seekHudDeltaSec?.let { delta ->
                SeekDeltaHud(
                    deltaSec = delta,
                    accent = palette.fg,
                    modifier = Modifier
                        .align(if (delta < 0) Alignment.CenterStart else Alignment.CenterEnd)
                        .padding(horizontal = 64.dp)
                )
            }

            val topHudText = resumeHudMessage ?: if (showAspectHud) "Aspect: ${aspectMode.label}" else null
            if (topHudText != null) {
                PlayerTopToastHud(
                    text = topHudText,
                    accent = palette.fg,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .windowInsetsPadding(WindowInsets.displayCutout)
                        .padding(top = 56.dp)
                )
            }

            AnimatedVisibility(
                visible = showEmbedControls || showSingleLoading,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(10.dp)
            ) {
                IconButton(
                    onClick = {
                        persistEmbedProgressNow()
                        applyWindowBrightness(null)
                        onClose()
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x99080A0F))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Exit Fullscreen",
                        tint = Color.White
                    )
                }
            }

            AnimatedVisibility(
                visible = showEmbedControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(10.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlayerActionPill(
                        icon = Icons.Rounded.Speed,
                        label = formatSpeedLabel(playbackSpeed),
                        accent = palette.fg,
                        active = activePanel == PlayerOverlayPanel.SPEED,
                        onClick = {
                            activePanel = if (activePanel == PlayerOverlayPanel.SPEED) PlayerOverlayPanel.NONE else PlayerOverlayPanel.SPEED
                        }
                    )
                    PlayerActionPill(
                        icon = Icons.Rounded.AspectRatio,
                        label = aspectMode.label,
                        accent = palette.fg,
                        active = activePanel == PlayerOverlayPanel.ASPECT,
                        onClick = {
                            activePanel = if (activePanel == PlayerOverlayPanel.ASPECT) PlayerOverlayPanel.NONE else PlayerOverlayPanel.ASPECT
                        }
                    )
                    IconButton(
                        onClick = {
                            val wv = webViewRef
                            if (wv != null) {
                                wv.evaluateJavascript(
                                    """
                                    (function(){
                                      var p = window.__PD2;
                                      if (!p) return '';
                                      if (p.mp4) return p.mp4;
                                      if (p.episodes && p.episodes.length) {
                                        var ep = p.episodes[0];
                                        if (ep.mp4) return ep.mp4;
                                        if (ep.master) return ep.master;
                                      }
                                      return p.master || '';
                                    })();
                                    """.trimIndent()
                                ) { res ->
                                    val extracted = res?.trim('"').orEmpty()
                                    val target = if (extracted.startsWith("http")) extracted else request.streamUrl
                                    DownloadAndPlayerRouter.launchExternalPlayer(
                                        context = context,
                                        url = target,
                                        referer = request.streamUrl,
                                        userAgent = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
                                    )
                                }
                            } else {
                                DownloadAndPlayerRouter.launchExternalPlayer(
                                    context = context,
                                    url = request.streamUrl,
                                    referer = request.refererUrl,
                                    userAgent = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
                                )
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x99080A0F))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.OpenInNew,
                            contentDescription = "Play in VLC / MX Player",
                            tint = palette.fg
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showEmbedControls,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(end = 14.dp, bottom = if (settings.hideVideoProgressBar) 14.dp else 54.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (activePanel) {
                        PlayerOverlayPanel.ASPECT -> {
                            AspectModeSelectorStrip(
                                activeMode = aspectMode,
                                accent = palette.fg,
                                onAccent = palette.onAccent,
                                onSelectMode = { mode ->
                                    aspectMode = mode
                                    activePanel = PlayerOverlayPanel.NONE
                                    showAspectHud = true
                                }
                            )
                        }
                        PlayerOverlayPanel.SPEED -> {
                            SpeedSelectorStrip(
                                activeSpeed = playbackSpeed,
                                accent = palette.fg,
                                onAccent = palette.onAccent,
                                onSelectSpeed = { spd ->
                                    playbackSpeed = spd
                                    activePanel = PlayerOverlayPanel.NONE
                                }
                            )
                        }
                        PlayerOverlayPanel.SUBTITLES -> {
                            TrackSelectorPanel(
                                title = "Subtitles",
                                items = embedTextTracks,
                                includeOffOption = true,
                                noneSelected = embedTextTracks.none { it.isSelected },
                                accent = palette.fg,
                                showLocalSubtitlePicker = false,
                                localPickerError = null,
                                onPickLocalSubtitle = {},
                                onSelectOff = {
                                    webViewRef?.evaluateJavascript(
                                        "(function(){var v=document.getElementById('video')||document.querySelector('video');if(v&&v.textTracks){for(var i=0;i<v.textTracks.length;i++){v.textTracks[i].mode='disabled';}}})();",
                                        null
                                    )
                                    embedTextTracks = embedTextTracks.map { it.copy(isSelected = false) }
                                    activePanel = PlayerOverlayPanel.NONE
                                },
                                onSelectTrack = { opt ->
                                    webViewRef?.evaluateJavascript(
                                        "(function(){var v=document.getElementById('video')||document.querySelector('video');if(v&&v.textTracks){for(var i=0;i<v.textTracks.length;i++){v.textTracks[i].mode=(i===${opt.trackIndex}?'showing':'disabled');}}})();",
                                        null
                                    )
                                    embedTextTracks = embedTextTracks.map {
                                        it.copy(isSelected = it.trackIndex == opt.trackIndex)
                                    }
                                    activePanel = PlayerOverlayPanel.NONE
                                },
                                onClose = { activePanel = PlayerOverlayPanel.NONE }
                            )
                        }
                        PlayerOverlayPanel.AUDIO -> {
                            TrackSelectorPanel(
                                title = "Audio Track",
                                items = embedAudioTracks,
                                includeOffOption = false,
                                noneSelected = false,
                                accent = palette.fg,
                                showLocalSubtitlePicker = false,
                                localPickerError = null,
                                onPickLocalSubtitle = {},
                                onSelectOff = {},
                                onSelectTrack = { opt ->
                                    webViewRef?.evaluateJavascript(
                                        "(function(){var v=document.getElementById('video')||document.querySelector('video');if(v&&v.audioTracks){for(var i=0;i<v.audioTracks.length;i++){v.audioTracks[i].enabled=(i===${opt.trackIndex});}}})();",
                                        null
                                    )
                                    embedAudioTracks = embedAudioTracks.map {
                                        it.copy(isSelected = it.trackIndex == opt.trackIndex)
                                    }
                                    activePanel = PlayerOverlayPanel.NONE
                                },
                                onClose = { activePanel = PlayerOverlayPanel.NONE }
                            )
                        }
                        PlayerOverlayPanel.NONE -> Unit
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PlayerActionPill(
                            icon = Icons.Rounded.Subtitles,
                            label = "Sub",
                            accent = palette.fg,
                            active = activePanel == PlayerOverlayPanel.SUBTITLES,
                            onClick = {
                                activePanel = if (activePanel == PlayerOverlayPanel.SUBTITLES) PlayerOverlayPanel.NONE else PlayerOverlayPanel.SUBTITLES
                            }
                        )
                        if (embedAudioTracks.size > 1) {
                            PlayerActionPill(
                                icon = Icons.Rounded.Audiotrack,
                                label = "Audio",
                                accent = palette.fg,
                                active = activePanel == PlayerOverlayPanel.AUDIO,
                                onClick = {
                                    activePanel = if (activePanel == PlayerOverlayPanel.AUDIO) PlayerOverlayPanel.NONE else PlayerOverlayPanel.AUDIO
                                }
                            )
                        }
                        PlayerActionPill(
                            icon = Icons.Rounded.Speed,
                            label = formatSpeedLabel(playbackSpeed),
                            accent = palette.fg,
                            active = activePanel == PlayerOverlayPanel.SPEED,
                            onClick = {
                                activePanel = if (activePanel == PlayerOverlayPanel.SPEED) PlayerOverlayPanel.NONE else PlayerOverlayPanel.SPEED
                            }
                        )
                        PlayerActionPill(
                            icon = Icons.Rounded.AspectRatio,
                            label = aspectMode.label,
                            accent = palette.fg,
                            active = activePanel == PlayerOverlayPanel.ASPECT,
                            onClick = {
                                activePanel = if (activePanel == PlayerOverlayPanel.ASPECT) PlayerOverlayPanel.NONE else PlayerOverlayPanel.ASPECT
                            }
                        )
                    }
                }
            }
        }
        return
    }

    // Native Media3 ExoPlayer path for direct streams (MovieLink / Nuvio / Stremio addons) & local media (content:// / file://)
    val isLocalMediaSource = remember(request.streamUrl, request.isLocalMedia) {
        request.isLocalMedia ||
            request.streamUrl.startsWith("content://", ignoreCase = true) ||
            request.streamUrl.startsWith("file://", ignoreCase = true)
    }

    var showControls by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(true) }
    var videoSize by remember { mutableStateOf(VideoSize.UNKNOWN) }
    var containerSize by remember { mutableStateOf(IntSize.Zero) }
    var retryNonce by remember(request.streamUrl) { mutableIntStateOf(0) }
    var forceHlsOnRetry by remember(request.streamUrl) { mutableStateOf(false) }
    var playerError by remember(request.streamUrl, retryNonce) { mutableStateOf<PlaybackDiagnostic?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var currentTracks by remember(request.streamUrl) { mutableStateOf(Tracks.EMPTY) }
    var extraLocalSubtitles by remember(request.streamUrl) { mutableStateOf(request.subtitles) }
    var localSubPickerError by remember(request.streamUrl) { mutableStateOf<String?>(null) }
    var hasAppliedInitialResume by remember(request.streamUrl) { mutableStateOf(false) }
    var pendingReloadSeekMs by remember(request.streamUrl) { mutableLongStateOf(-1L) }

    val validatedUri = remember(request.streamUrl) {
        val parsed = Uri.parse(request.streamUrl.trim())
        val scheme = parsed.scheme?.lowercase(Locale.US)
        val schemeValid = scheme == "http" || scheme == "https" || scheme == "content" || scheme == "file"
        val hostValid = if (scheme == "http" || scheme == "https") !parsed.host.isNullOrBlank() else true
        if (request.streamUrl.isNotBlank() && schemeValid && hostValid) parsed else null
    }

    LaunchedEffect(request.streamUrl, validatedUri) {
        if (validatedUri == null) {
            isBuffering = false
            playerError = PlaybackDiagnostic(
                origin = "App / Invalid Stream URL",
                summary = "The addon returned an invalid or unsupported stream URL.",
                detail = request.streamUrl.ifBlank { "Empty stream URL" }
            )
        }
    }

    LaunchedEffect(showControls, isPlaying, activePanel) {
        if (showControls && isPlaying && activePanel == PlayerOverlayPanel.NONE) {
            delay(3200)
            showControls = false
        }
    }

    val defaultUa = if (settings.desktopMode) Config.DESKTOP_USER_AGENT else Config.MOBILE_USER_AGENT
    val effectiveReferer = remember(request.refererUrl, request.requestHeaders) {
        request.requestHeaders.entries
            .firstOrNull { it.key.equals("Referer", ignoreCase = true) }
            ?.value
            ?.takeIf { it.isNotBlank() }
            ?: request.refererUrl
    }
    val effectiveUserAgent = remember(defaultUa, request.requestHeaders) {
        request.requestHeaders.entries
            .firstOrNull { it.key.equals("User-Agent", ignoreCase = true) }
            ?.value
            ?.takeIf { it.isNotBlank() }
            ?: defaultUa
    }

    fun buildExoMediaItem(subs: List<PlayerSubtitleTrack>): MediaItem? {
        val uri = validatedUri ?: return null
        val subtitleConfigs = subs.mapNotNull { sub ->
            val subUri = Uri.parse(sub.url)
            val scheme = subUri.scheme?.lowercase(Locale.US)
            if (scheme != "http" && scheme != "https" && scheme != "content" && scheme != "file") {
                return@mapNotNull null
            }
            val subMime = sub.mimeType ?: inferSubtitleMimeType(sub.url)
            MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(subMime)
                .setLanguage(sub.lang.takeIf { it.isNotBlank() })
                .setLabel(sub.label ?: sub.lang)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
        }
        val mediaBuilder = MediaItem.Builder().setUri(uri)
        val mime = when {
            forceHlsOnRetry -> MimeTypes.APPLICATION_M3U8
            !request.mimeTypeHint.isNullOrBlank() -> request.mimeTypeHint
            else -> null
        }
        if (mime != null) {
            mediaBuilder.setMimeType(mime)
        }
        if (subtitleConfigs.isNotEmpty()) {
            mediaBuilder.setSubtitleConfigurations(subtitleConfigs)
        }
        return mediaBuilder.build()
    }

    val exoPlayer = remember(request.streamUrl, retryNonce, forceHlsOnRetry) {
        val headers = linkedMapOf<String, String>()
        request.requestHeaders.forEach { (k, v) ->
            if (k.isNotBlank() && v.isNotBlank()) headers[k] = v
        }
        if (request.refererUrl.isNotBlank() && headers.keys.none { it.equals("Referer", ignoreCase = true) }) {
            headers["Referer"] = request.refererUrl
        }
        if (headers.keys.none { it.equals("User-Agent", ignoreCase = true) }) {
            headers["User-Agent"] = defaultUa
        }

        val okFactory = OkHttpDataSource.Factory(httpClient)
            .setDefaultRequestProperties(headers)
        val dataSourceFactory = DefaultDataSource.Factory(context, okFactory)
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build().apply {
                buildExoMediaItem(extraLocalSubtitles)?.let { item ->
                    setMediaItem(item)
                    prepare()
                    playWhenReady = true
                }
            }
    }

    LaunchedEffect(exoPlayer, playbackSpeed) {
        exoPlayer.setPlaybackSpeed(playbackSpeed)
    }

    fun persistExoProgressNow() {
        val pos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val dur = exoPlayer.duration.coerceAtLeast(0L)
        if (hasAppliedInitialResume || pos >= 5_000L) {
            onSaveProgress(pos, dur)
        }
    }

    val localSubtitleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { subUri ->
        if (subUri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.takePersistableUriPermission(
                subUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        val displayName = resolveDocumentDisplayName(context, subUri)
        val contentMime = context.contentResolver.getType(subUri).orEmpty().lowercase(Locale.US)
        val lowerName = displayName.lowercase(Locale.US)
        val resolvedMime = when {
            lowerName.endsWith(".vtt") || contentMime == "text/vtt" -> MimeTypes.TEXT_VTT
            lowerName.endsWith(".srt") || contentMime.contains("subrip") || contentMime.contains("srt") -> MimeTypes.APPLICATION_SUBRIP
            lowerName.endsWith(".ass") || lowerName.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            lowerName.isEmpty() || (!lowerName.contains('.') && contentMime.startsWith("text/")) -> MimeTypes.APPLICATION_SUBRIP
            else -> null
        }

        if (resolvedMime == null) {
            localSubPickerError = "Please select an .srt or .vtt subtitle file."
            return@rememberLauncherForActivityResult
        }

        localSubPickerError = null
        val newTrack = PlayerSubtitleTrack(
            id = "local_sub_${System.currentTimeMillis()}",
            lang = "ext",
            url = subUri.toString(),
            mimeType = resolvedMime,
            label = displayName.ifBlank { "Local Subtitle" }
        )
        val updatedSubs = extraLocalSubtitles + newTrack
        extraLocalSubtitles = updatedSubs

        val resumePos = exoPlayer.currentPosition.coerceAtLeast(0L)
        val wasPlaying = exoPlayer.playWhenReady
        pendingReloadSeekMs = resumePos

        buildExoMediaItem(updatedSubs)?.let { updatedItem ->
            val paramsBuilder = exoPlayer.trackSelectionParameters.buildUpon()
            paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            exoPlayer.trackSelectionParameters = paramsBuilder.build()
            exoPlayer.setMediaItem(updatedItem, resumePos)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = wasPlaying
            exoPlayer.setPlaybackSpeed(playbackSpeed)
        }
        activePanel = PlayerOverlayPanel.NONE
    }

    DisposableEffect(lifecycleOwner, exoPlayer) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE,
                Lifecycle.Event.ON_STOP,
                Lifecycle.Event.ON_DESTROY -> {
                    persistExoProgressNow()
                    applyWindowBrightness(null)
                }
                Lifecycle.Event.ON_RESUME -> {
                    setFullscreenSystemUi(true)
                    if (settings.playerBrightnessSync && hasUserAdjustedBrightness) {
                        applyWindowBrightness(brightnessLevel)
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    BackHandler {
        persistExoProgressNow()
        applyWindowBrightness(null)
        onClose()
    }

    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                isBuffering = playbackState == Player.STATE_BUFFERING
                val dur = exoPlayer.duration.coerceAtLeast(0L)
                durationMs = dur
                if (playbackState == Player.STATE_READY) {
                    currentTracks = exoPlayer.currentTracks
                    if (!hasAppliedInitialResume) {
                        hasAppliedInitialResume = true
                        if (savedPositionMs >= 5_000L && (dur == 0L || savedPositionMs < dur - 15_000L)) {
                            exoPlayer.seekTo(savedPositionMs)
                            positionMs = savedPositionMs
                            resumeHudMessage = "Resumed from ${formatMs(savedPositionMs)}"
                        }
                    } else if (pendingReloadSeekMs >= 0L) {
                        exoPlayer.seekTo(pendingReloadSeekMs)
                        positionMs = pendingReloadSeekMs
                        pendingReloadSeekMs = -1L
                    }
                } else if (playbackState == Player.STATE_ENDED && dur > 0L) {
                    onSaveProgress(dur, dur)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                currentTracks = tracks
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onVideoSizeChanged(size: VideoSize) {
                videoSize = size
            }

            override fun onPlayerError(error: PlaybackException) {
                isBuffering = false
                playerError = classifyPlaybackError(error, request.mimeTypeHint)
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            persistExoProgressNow()
            exoPlayer.removeListener(listener)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer) {
        var tick = 0
        while (true) {
            positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            tick++
            if (tick % 6 == 0 && exoPlayer.isPlaying) {
                persistExoProgressNow()
            }
            delay(500)
        }
    }

    val audioTracks = remember(currentTracks) {
        extractSelectableTracks(currentTracks, C.TRACK_TYPE_AUDIO)
    }
    val subtitleTracks = remember(currentTracks) {
        extractSelectableTracks(currentTracks, C.TRACK_TYPE_TEXT)
    }

    val videoScale = remember(aspectMode, videoSize, containerSize) {
        when (aspectMode) {
            PlayerAspectMode.ZOOM -> 1.20f
            PlayerAspectMode.ORIGINAL -> {
                if (videoSize.width > 0 && videoSize.height > 0 &&
                    containerSize.width > 0 && containerSize.height > 0
                ) {
                    val fitScale = minOf(
                        containerSize.width.toFloat() / videoSize.width.toFloat(),
                        containerSize.height.toFloat() / videoSize.height.toFloat()
                    )
                    if (fitScale > 1f) (1f / fitScale).coerceIn(0.25f, 1f) else 1f
                } else {
                    1f
                }
            }
            else -> 1f
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds()
            .background(Color.Black)
            .onSizeChanged { containerSize = it }
    ) {
        AndroidView(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = videoScale
                    scaleY = videoScale
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            showControls = !showControls
                            if (!showControls) activePanel = PlayerOverlayPanel.NONE
                        },
                        onDoubleTap = { offset ->
                            val deltaSec = if (offset.x < size.width / 2f) -10 else 10
                            val maxDur = exoPlayer.duration.takeIf { it > 0L } ?: Long.MAX_VALUE
                            val target = (exoPlayer.currentPosition + deltaSec * 1000L).coerceIn(0L, maxDur)
                            exoPlayer.seekTo(target)
                            positionMs = target
                            seekHudDeltaSec = deltaSec
                            seekHudNonce++
                        }
                    )
                },
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    keepScreenOn = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { pv ->
                pv.resizeMode = when (aspectMode) {
                    PlayerAspectMode.FIT, PlayerAspectMode.ORIGINAL -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    PlayerAspectMode.FILL, PlayerAspectMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    PlayerAspectMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                }
            }
        )

        // Left-edge vertical brightness gesture zone (strictly controls window.screenBrightness)
        if (settings.playerBrightnessSync) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(vertical = 58.dp)
                    .fillMaxHeight()
                    .width(64.dp)
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, dragAmount ->
                            change.consume()
                            val delta = -dragAmount / size.height.toFloat()
                            val next = (brightnessLevel + delta * 1.25f).coerceIn(0f, 1f)
                            brightnessLevel = next
                            hasUserAdjustedBrightness = true
                            showBrightnessHud = true
                            applyWindowBrightness(next)
                        }
                    }
            )
        }

        // Right-edge vertical media volume gesture zone (controls AudioManager STREAM_MUSIC)
        Box(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(vertical = 58.dp)
                .fillMaxHeight()
                .width(64.dp)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = {
                            val curr = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 0
                            volumeLevel = (curr.toFloat() / maxVolume.toFloat()).coerceIn(0f, 1f)
                        }
                    ) { change, dragAmount ->
                        change.consume()
                        val delta = -dragAmount / size.height.toFloat()
                        applyMediaVolume(volumeLevel + delta * 1.25f)
                    }
                }
        )

        // Left-edge Brightness HUD bar
        if (showBrightnessHud && settings.playerBrightnessSync) {
            VerticalHudMeter(
                icon = Icons.Rounded.BrightnessMedium,
                contentDescription = "Screen Brightness",
                level = brightnessLevel,
                accent = palette.fg,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 20.dp)
            )
        }

        // Right-edge Volume HUD bar
        if (showVolumeHud) {
            VerticalHudMeter(
                icon = if (volumeLevel <= 0.01f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                contentDescription = "Media Volume",
                level = volumeLevel,
                accent = palette.fg,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 20.dp)
            )
        }

        // Single centered state: show either buffering indicator OR single play/pause toggle, never both at once
        if (isBuffering && playerError == null) {
            CircularProgressIndicator(
                color = palette.fg,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(44.dp)
            )
        } else if (showControls && playerError == null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(36.dp))
                    .background(Color(0xAA0A0C12))
                    .clickable {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    }
                    .padding(14.dp)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Play",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }
        }

        seekHudDeltaSec?.let { delta ->
            SeekDeltaHud(
                deltaSec = delta,
                accent = palette.fg,
                modifier = Modifier
                    .align(if (delta < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 64.dp)
            )
        }

        val topHudText = resumeHudMessage ?: if (showAspectHud) "Aspect: ${aspectMode.label}" else null
        if (topHudText != null) {
            PlayerTopToastHud(
                text = topHudText,
                accent = palette.fg,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(top = 56.dp)
            )
        }

        playerError?.let { diag ->
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xEE0A0C12))
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = diag.origin,
                    color = palette.fg,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = diag.summary,
                    color = Color.White,
                    fontSize = 14.5.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                if (diag.detail.isNotBlank()) {
                    Text(
                        text = diag.detail,
                        color = Color(0xFFB4B4BC),
                        fontSize = 11.5.sp,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (validatedUri != null) {
                        OutlinedButton(
                            onClick = {
                                if (diag.suggestHlsRetry && !forceHlsOnRetry) {
                                    forceHlsOnRetry = true
                                }
                                isBuffering = true
                                retryNonce++
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (diag.suggestHlsRetry && !forceHlsOnRetry) "Retry as HLS" else "Retry",
                                color = palette.fg,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Button(
                        onClick = {
                            DownloadAndPlayerRouter.launchExternalPlayer(
                                context = context,
                                url = request.streamUrl,
                                referer = effectiveReferer,
                                userAgent = effectiveUserAgent,
                                mimeType = request.mimeTypeHint,
                                extraHeaders = request.requestHeaders
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.fg,
                            contentColor = palette.onAccent
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Open in VLC / MX", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            persistExoProgressNow()
                            applyWindowBrightness(null)
                            onClose()
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Close", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        if (showControls) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(onClick = {
                    persistExoProgressNow()
                    applyWindowBrightness(null)
                    onClose()
                }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Exit Fullscreen",
                        tint = Color.White
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = request.title,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (request.subtitle.isNotBlank()) {
                        Text(
                            text = request.subtitle,
                            color = Color(0xFFB4B4BC),
                            fontSize = 11.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                PlayerActionPill(
                    icon = Icons.Rounded.Speed,
                    label = formatSpeedLabel(playbackSpeed),
                    accent = palette.fg,
                    active = activePanel == PlayerOverlayPanel.SPEED,
                    onClick = {
                        activePanel = if (activePanel == PlayerOverlayPanel.SPEED) PlayerOverlayPanel.NONE else PlayerOverlayPanel.SPEED
                    }
                )
                PlayerActionPill(
                    icon = Icons.Rounded.AspectRatio,
                    label = aspectMode.label,
                    accent = palette.fg,
                    active = activePanel == PlayerOverlayPanel.ASPECT,
                    onClick = {
                        activePanel = if (activePanel == PlayerOverlayPanel.ASPECT) PlayerOverlayPanel.NONE else PlayerOverlayPanel.ASPECT
                    }
                )
                IconButton(onClick = {
                    DownloadAndPlayerRouter.launchExternalPlayer(
                        context = context,
                        url = request.streamUrl,
                        referer = effectiveReferer,
                        userAgent = effectiveUserAgent,
                        mimeType = request.mimeTypeHint,
                        extraHeaders = request.requestHeaders
                    )
                }) {
                    Icon(
                        imageVector = Icons.Rounded.OpenInNew,
                        contentDescription = "Play in VLC / MX Player",
                        tint = palette.fg
                    )
                }
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.displayCutout),
                horizontalAlignment = Alignment.End
            ) {
                if (activePanel != PlayerOverlayPanel.NONE) {
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        when (activePanel) {
                            PlayerOverlayPanel.ASPECT -> {
                                AspectModeSelectorStrip(
                                    activeMode = aspectMode,
                                    accent = palette.fg,
                                    onAccent = palette.onAccent,
                                    onSelectMode = { mode ->
                                        aspectMode = mode
                                        activePanel = PlayerOverlayPanel.NONE
                                        showAspectHud = true
                                    }
                                )
                            }
                            PlayerOverlayPanel.SPEED -> {
                                SpeedSelectorStrip(
                                    activeSpeed = playbackSpeed,
                                    accent = palette.fg,
                                    onAccent = palette.onAccent,
                                    onSelectSpeed = { spd ->
                                        playbackSpeed = spd
                                        exoPlayer.setPlaybackSpeed(spd)
                                        activePanel = PlayerOverlayPanel.NONE
                                    }
                                )
                            }
                            PlayerOverlayPanel.SUBTITLES -> {
                                val textDisabled = exoPlayer.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
                                TrackSelectorPanel(
                                    title = "Subtitles",
                                    items = subtitleTracks,
                                    includeOffOption = true,
                                    noneSelected = textDisabled || subtitleTracks.none { it.isSelected },
                                    accent = palette.fg,
                                    showLocalSubtitlePicker = isLocalMediaSource,
                                    localPickerError = localSubPickerError,
                                    onPickLocalSubtitle = {
                                        localSubPickerError = null
                                        localSubtitleLauncher.launch(
                                            arrayOf("application/x-subrip", "text/vtt", "text/plain", "*/*")
                                        )
                                    },
                                    onSelectOff = {
                                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                            .buildUpon()
                                            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                                            .build()
                                        activePanel = PlayerOverlayPanel.NONE
                                    },
                                    onSelectTrack = { opt ->
                                        val group = currentTracks.groups.getOrNull(opt.groupIndex)
                                        if (group != null) {
                                            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                                .buildUpon()
                                                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                                                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                                .addOverride(TrackSelectionOverride(group.mediaTrackGroup, opt.trackIndex))
                                                .build()
                                        }
                                        activePanel = PlayerOverlayPanel.NONE
                                    },
                                    onClose = { activePanel = PlayerOverlayPanel.NONE }
                                )
                            }
                            PlayerOverlayPanel.AUDIO -> {
                                TrackSelectorPanel(
                                    title = "Audio Track",
                                    items = audioTracks,
                                    includeOffOption = false,
                                    noneSelected = false,
                                    accent = palette.fg,
                                    showLocalSubtitlePicker = false,
                                    localPickerError = null,
                                    onPickLocalSubtitle = {},
                                    onSelectOff = {},
                                    onSelectTrack = { opt ->
                                        val group = currentTracks.groups.getOrNull(opt.groupIndex)
                                        if (group != null) {
                                            exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                                                .buildUpon()
                                                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                                                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                                .addOverride(TrackSelectionOverride(group.mediaTrackGroup, opt.trackIndex))
                                                .build()
                                        }
                                        activePanel = PlayerOverlayPanel.NONE
                                    },
                                    onClose = { activePanel = PlayerOverlayPanel.NONE }
                                )
                            }
                            PlayerOverlayPanel.NONE -> Unit
                        }
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x99000000))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!settings.hideVideoProgressBar && durationMs > 0L) {
                        Text(text = formatMs(positionMs), color = Color.White, fontSize = 12.sp)
                        Slider(
                            value = positionMs.toFloat().coerceIn(0f, durationMs.toFloat().coerceAtLeast(1f)),
                            onValueChange = { exoPlayer.seekTo(it.toLong()) },
                            valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
                            colors = SliderDefaults.colors(
                                thumbColor = palette.fg,
                                activeTrackColor = palette.fg
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Text(text = formatMs(durationMs), color = Color.White, fontSize = 12.sp)
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    PlayerActionPill(
                        icon = Icons.Rounded.Subtitles,
                        label = "Sub",
                        accent = palette.fg,
                        active = activePanel == PlayerOverlayPanel.SUBTITLES,
                        onClick = {
                            activePanel = if (activePanel == PlayerOverlayPanel.SUBTITLES) PlayerOverlayPanel.NONE else PlayerOverlayPanel.SUBTITLES
                        }
                    )
                    PlayerActionPill(
                        icon = Icons.Rounded.Audiotrack,
                        label = "Audio",
                        accent = palette.fg,
                        active = activePanel == PlayerOverlayPanel.AUDIO,
                        onClick = {
                            activePanel = if (activePanel == PlayerOverlayPanel.AUDIO) PlayerOverlayPanel.NONE else PlayerOverlayPanel.AUDIO
                        }
                    )
                    PlayerActionPill(
                        icon = Icons.Rounded.Speed,
                        label = formatSpeedLabel(playbackSpeed),
                        accent = palette.fg,
                        active = activePanel == PlayerOverlayPanel.SPEED,
                        onClick = {
                            activePanel = if (activePanel == PlayerOverlayPanel.SPEED) PlayerOverlayPanel.NONE else PlayerOverlayPanel.SPEED
                        }
                    )
                    PlayerActionPill(
                        icon = Icons.Rounded.AspectRatio,
                        label = aspectMode.label,
                        accent = palette.fg,
                        active = activePanel == PlayerOverlayPanel.ASPECT,
                        onClick = {
                            activePanel = if (activePanel == PlayerOverlayPanel.ASPECT) PlayerOverlayPanel.NONE else PlayerOverlayPanel.ASPECT
                        }
                    )
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun EmbedPlayerWebView(
    embedUrl: String,
    refererUrl: String,
    settings: UserSettings,
    accentHex: String,
    aspectMode: PlayerAspectMode,
    playbackSpeed: Float,
    onWebViewReady: (WebView) -> Unit,
    onLoadingChanged: (Boolean) -> Unit,
    onMediaStateChanged: (playing: Boolean, buffering: Boolean) -> Unit,
    onMediaProgress: (positionMs: Long, durationMs: Long) -> Unit,
    onTracksUpdated: (textTracks: List<SelectableTrackItem>, audioTracks: List<SelectableTrackItem>) -> Unit,
    onSeekHud: (deltaSec: Int) -> Unit,
    onControlsVisibilityChanged: (Boolean) -> Unit,
    onBrightnessBridge: (Float) -> Unit
) {
    val mainHandler = remember { Handler(Looper.getMainLooper()) }
    var webRef by remember { mutableStateOf<WebView?>(null) }
    var customViewContainer by remember { mutableStateOf<FrameLayout?>(null) }
    var customFullscreenView by remember { mutableStateOf<View?>(null) }
    var customViewCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    class PlayerJsBridge {
        @JavascriptInterface
        fun setBrightness(level: Float) {
            mainHandler.post { onBrightnessBridge(level.coerceIn(0f, 1f)) }
        }

        @JavascriptInterface
        fun setControlsVisible(visible: Boolean) {
            mainHandler.post { onControlsVisibilityChanged(visible) }
        }

        @JavascriptInterface
        fun setMediaState(playing: Boolean, buffering: Boolean) {
            mainHandler.post { onMediaStateChanged(playing, buffering) }
        }

        @JavascriptInterface
        fun onProgress(positionMs: Long, durationMs: Long) {
            mainHandler.post { onMediaProgress(positionMs.coerceAtLeast(0L), durationMs.coerceAtLeast(0L)) }
        }

        @JavascriptInterface
        fun onDoubleTapSeek(deltaSec: Int) {
            mainHandler.post { onSeekHud(deltaSec) }
        }

        @JavascriptInterface
        fun onTracks(textJson: String, audioJson: String) {
            val textItems = parseEmbedTracksJson(textJson)
            val audioItems = parseEmbedTracksJson(audioJson)
            mainHandler.post { onTracksUpdated(textItems, audioItems) }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    keepScreenOn = true
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    this.settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        javaScriptCanOpenWindowsAutomatically = false
                        setSupportMultipleWindows(false)
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        userAgentString = if (settings.desktopMode) {
                            Config.DESKTOP_USER_AGENT
                        } else {
                            Config.MOBILE_USER_AGENT
                        }
                    }

                    addJavascriptInterface(PlayerJsBridge(), "MovieLinkPlayerBridge")

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView,
                            request: WebResourceRequest
                        ): WebResourceResponse? {
                            if (AdBlocker.shouldBlock(request.url, settings)) {
                                return WebResourceResponse(
                                    "text/plain",
                                    "utf-8",
                                    ByteArrayInputStream(ByteArray(0))
                                )
                            }
                            return null
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView,
                            request: WebResourceRequest
                        ): Boolean {
                            val uri = request.url
                            if (uri.scheme != "http" && uri.scheme != "https") return true
                            if (AdBlocker.shouldBlock(uri, settings)) return true
                            val host = uri.host.orEmpty()
                            return !Config.isInternal(host, settings.mirrorUrl)
                        }

                        override fun onPageCommitVisible(view: WebView, url: String?) {
                            onLoadingChanged(false)
                            injectPlayerEnhancements(
                                view = view,
                                accentHex = accentHex,
                                hideProgressBar = settings.hideVideoProgressBar,
                                brightnessSync = settings.playerBrightnessSync,
                                englishPolish = settings.sitePolishEnabled,
                                aspectMode = aspectMode,
                                playbackSpeed = playbackSpeed
                            )
                        }

                        override fun onPageFinished(view: WebView, url: String?) {
                            onLoadingChanged(false)
                            CookieManager.getInstance().flush()
                            injectPlayerEnhancements(
                                view = view,
                                accentHex = accentHex,
                                hideProgressBar = settings.hideVideoProgressBar,
                                brightnessSync = settings.playerBrightnessSync,
                                englishPolish = settings.sitePolishEnabled,
                                aspectMode = aspectMode,
                                playbackSpeed = playbackSpeed
                            )
                            mainHandler.postDelayed({
                                injectPlayerEnhancements(
                                    view = view,
                                    accentHex = accentHex,
                                    hideProgressBar = settings.hideVideoProgressBar,
                                    brightnessSync = settings.playerBrightnessSync,
                                    englishPolish = settings.sitePolishEnabled,
                                    aspectMode = aspectMode,
                                    playbackSpeed = playbackSpeed
                                )
                            }, 250)
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            if (view == null) return
                            if (newProgress >= 20) {
                                injectPlayerEnhancements(
                                    view = view,
                                    accentHex = accentHex,
                                    hideProgressBar = settings.hideVideoProgressBar,
                                    brightnessSync = settings.playerBrightnessSync,
                                    englishPolish = settings.sitePolishEnabled,
                                    aspectMode = aspectMode,
                                    playbackSpeed = playbackSpeed
                                )
                            }
                            if (newProgress >= 65) {
                                onLoadingChanged(false)
                            }
                        }

                        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                            if (view == null) return
                            customFullscreenView?.let { old -> customViewContainer?.removeView(old) }
                            customFullscreenView = view
                            customViewCallback = callback
                            customViewContainer?.apply {
                                visibility = View.VISIBLE
                                addView(
                                    view,
                                    FrameLayout.LayoutParams(
                                        ViewGroup.LayoutParams.MATCH_PARENT,
                                        ViewGroup.LayoutParams.MATCH_PARENT
                                    )
                                )
                            }
                        }

                        override fun onHideCustomView() {
                            customFullscreenView?.let { customViewContainer?.removeView(it) }
                            customFullscreenView = null
                            customViewContainer?.visibility = View.GONE
                            customViewCallback?.onCustomViewHidden()
                            customViewCallback = null
                        }
                    }

                    loadUrl(embedUrl, mapOf("Referer" to refererUrl))
                    webRef = this
                    onWebViewReady(this)
                }
            }
        )

        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                FrameLayout(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    visibility = View.GONE
                    customViewContainer = this
                }
            }
        )
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                customViewCallback?.onCustomViewHidden()
            } catch (_: Exception) {
            }
            webRef?.stopLoading()
            webRef?.destroy()
            webRef = null
        }
    }
}

@Composable
private fun VerticalHudMeter(
    icon: ImageVector,
    contentDescription: String,
    level: Float,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xCC0A0C12))
            .padding(horizontal = 10.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = accent,
            modifier = Modifier.size(18.dp)
        )
        Box(
            modifier = Modifier
                .width(6.dp)
                .height(110.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0x33FFFFFF)),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(level.coerceIn(0.03f, 1f))
                    .background(accent)
            )
        }
        Text(
            text = "${(level * 100).roundToInt()}%",
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SeekDeltaHud(
    deltaSec: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xCC0A0C12))
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (deltaSec < 0) Icons.Rounded.Replay10 else Icons.Rounded.Forward10,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = if (deltaSec < 0) "${deltaSec}s" else "+${deltaSec}s",
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun PlayerTopToastHud(
    text: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xCC0A0C12))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = accent,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun PlayerActionPill(
    icon: ImageVector,
    label: String,
    accent: Color,
    active: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) accent.copy(alpha = 0.22f) else Color(0xAA080A0F))
            .border(
                1.dp,
                if (active) accent else accent.copy(alpha = 0.45f),
                RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = accent,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun AspectModeSelectorStrip(
    activeMode: PlayerAspectMode,
    accent: Color,
    onAccent: Color,
    onSelectMode: (PlayerAspectMode) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xDD0A0C12))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PlayerAspectMode.entries.forEach { mode ->
            val selected = mode == activeMode
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) accent else Color.Transparent)
                    .clickable { onSelectMode(mode) }
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = mode.label,
                    color = if (selected) onAccent else Color.White,
                    fontSize = 11.5.sp,
                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun SpeedSelectorStrip(
    activeSpeed: Float,
    accent: Color,
    onAccent: Color,
    onSelectSpeed: (Float) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xDD0A0C12))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PLAYBACK_SPEED_OPTIONS.forEach { spd ->
            val selected = kotlin.math.abs(spd - activeSpeed) < 0.01f
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) accent else Color.Transparent)
                    .clickable { onSelectSpeed(spd) }
                    .padding(horizontal = 9.dp, vertical = 5.dp)
            ) {
                Text(
                    text = formatSpeedLabel(spd),
                    color = if (selected) onAccent else Color.White,
                    fontSize = 11.5.sp,
                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun TrackSelectorPanel(
    title: String,
    items: List<SelectableTrackItem>,
    includeOffOption: Boolean,
    noneSelected: Boolean,
    accent: Color,
    showLocalSubtitlePicker: Boolean,
    localPickerError: String?,
    onPickLocalSubtitle: () -> Unit,
    onSelectOff: () -> Unit,
    onSelectTrack: (SelectableTrackItem) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .widthIn(min = 240.dp, max = 330.dp)
            .heightIn(max = 220.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xEB0A0C12))
            .border(1.dp, accent.copy(alpha = 0.38f), RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = "Close",
                tint = Color(0xFFB4B4BC),
                modifier = Modifier
                    .size(18.dp)
                    .clickable(onClick = onClose)
            )
        }

        if (showLocalSubtitlePicker) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(9.dp))
                    .background(accent.copy(alpha = 0.14f))
                    .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(9.dp))
                    .clickable(onClick = onPickLocalSubtitle)
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Load .srt / .vtt File",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            if (!localPickerError.isNullOrBlank()) {
                Text(
                    text = localPickerError,
                    color = Color(0xFFFF7A7A),
                    fontSize = 11.sp
                )
            }
        }

        Column(
            modifier = Modifier.verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (includeOffOption) {
                TrackRowItem(
                    label = "Off",
                    subtitle = "",
                    selected = noneSelected,
                    accent = accent,
                    onClick = onSelectOff
                )
            }
            if (items.isEmpty()) {
                Text(
                    text = if (includeOffOption) "No subtitle tracks detected in this stream" else "Default audio track active",
                    color = Color(0xFF9E9EA8),
                    fontSize = 11.5.sp,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            } else {
                items.forEach { item ->
                    TrackRowItem(
                        label = item.label,
                        subtitle = item.subtitle,
                        selected = item.isSelected,
                        accent = accent,
                        onClick = { onSelectTrack(item) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackRowItem(
    label: String,
    subtitle: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) accent.copy(alpha = 0.16f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                color = if (selected) accent else Color.White,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle.isNotBlank()) {
                Text(
                    text = subtitle,
                    color = Color(0xFF9E9EA8),
                    fontSize = 10.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (selected) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "Selected",
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@OptIn(UnstableApi::class)
private fun extractSelectableTracks(tracks: Tracks, trackType: Int): List<SelectableTrackItem> {
    val result = mutableListOf<SelectableTrackItem>()
    tracks.groups.forEachIndexed { groupIdx, group ->
        if (group.type != trackType) return@forEachIndexed
        for (i in 0 until group.length) {
            if (!group.isTrackSupported(i)) continue
            val fmt = group.getTrackFormat(i)
            val langName = fmt.language
                ?.takeIf { it.isNotBlank() && it != "und" }
                ?.let { code -> Locale.forLanguageTag(code).displayLanguage.ifBlank { code } }
                .orEmpty()
            val rawLabel = fmt.label?.takeIf { it.isNotBlank() }
            val title = when {
                rawLabel != null && langName.isNotBlank() && !rawLabel.contains(langName, ignoreCase = true) ->
                    "$langName · $rawLabel"
                rawLabel != null -> rawLabel
                langName.isNotBlank() -> langName
                else -> "Track ${result.size + 1}"
            }
            val metaParts = buildList {
                if (trackType == C.TRACK_TYPE_AUDIO && fmt.channelCount > 0) {
                    add(
                        when (fmt.channelCount) {
                            1 -> "Mono"
                            2 -> "Stereo"
                            6 -> "5.1"
                            8 -> "7.1"
                            else -> "${fmt.channelCount}ch"
                        }
                    )
                }
                fmt.sampleMimeType?.substringAfter('/')?.uppercase(Locale.US)?.let { add(it) }
            }
            result.add(
                SelectableTrackItem(
                    groupIndex = groupIdx,
                    trackIndex = i,
                    label = title,
                    subtitle = metaParts.joinToString(" · "),
                    isSelected = group.isTrackSelected(i)
                )
            )
        }
    }
    return result
}

private fun parseEmbedTracksJson(raw: String): List<SelectableTrackItem> {
    if (raw.isBlank() || raw == "[]") return emptyList()
    return try {
        val arr = JSONArray(raw)
        buildList {
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                add(
                    SelectableTrackItem(
                        groupIndex = 0,
                        trackIndex = obj.optInt("index", i),
                        label = obj.optString("label", "Track ${i + 1}"),
                        subtitle = obj.optString("lang", ""),
                        isSelected = obj.optBoolean("active", false)
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun resolveDocumentDisplayName(context: Context, uri: Uri): String {
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) {
                    val name = cursor.getString(idx)?.trim()
                    if (!name.isNullOrBlank()) return name
                }
            }
        }
    } catch (_: Exception) {
    }
    return uri.lastPathSegment?.substringAfterLast('/').orEmpty()
}

private fun formatSpeedLabel(speed: Float): String {
    return if (speed % 1f == 0f) "${speed.toInt()}.0x" else "${speed}x"
}

private fun injectPlayerEnhancements(
    view: WebView,
    accentHex: String,
    hideProgressBar: Boolean,
    brightnessSync: Boolean,
    englishPolish: Boolean,
    aspectMode: PlayerAspectMode,
    playbackSpeed: Float
) {
    val hideMiniCss = if (hideProgressBar) {
        ".mini-progress,.mini-progress-fill{opacity:0!important;display:none!important;pointer-events:none!important;}" +
            ".player.idle .controls,.player.idle .progress-wrap{opacity:0!important;pointer-events:none!important;}"
    } else ""

    val brightCss = if (brightnessSync) {
        ".bright-veil{opacity:0!important;display:none!important;pointer-events:none!important;}"
    } else ""

    val videoAspectCss = when (aspectMode) {
        PlayerAspectMode.FIT ->
            "inset:0!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;object-fit:contain!important;object-position:center center!important;transform:none!important;"
        PlayerAspectMode.FILL ->
            "inset:0!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;object-fit:cover!important;object-position:center center!important;transform:none!important;"
        PlayerAspectMode.ZOOM ->
            "inset:0!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;object-fit:cover!important;object-position:center center!important;transform:scale(1.20)!important;"
        PlayerAspectMode.STRETCH ->
            "inset:0!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;object-fit:fill!important;object-position:center center!important;transform:none!important;"
        PlayerAspectMode.ORIGINAL ->
            "inset:auto!important;left:50%!important;top:50%!important;width:auto!important;height:auto!important;max-width:100%!important;max-height:100%!important;object-fit:none!important;transform:translate(-50%,-50%)!important;"
    }

    val js = """
        (function(){
          try {
            var vp = document.querySelector('meta[name="viewport"]');
            if (!vp) {
              vp = document.createElement('meta');
              vp.name = 'viewport';
              (document.head || document.documentElement).appendChild(vp);
            }
            vp.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';

            var st = document.getElementById('__ml_player_theme');
            if (!st) {
              st = document.createElement('style');
              st.id = '__ml_player_theme';
              (document.head || document.documentElement).appendChild(st);
            }
            st.textContent = ':root{--ac:$accentHex!important;--ac2:$accentHex!important;--accent:$accentHex!important;--accent-hi:$accentHex!important;--ac-soft:${accentHex}29!important;--ac-glow:${accentHex}80!important;--accent-glow:${accentHex}59!important;}' +
              'html,body{margin:0!important;padding:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;overflow:hidden!important;background:#000!important;}' +
              '.embed-wrap,#player,.player{position:fixed!important;inset:0!important;width:100vw!important;height:100vh!important;height:100dvh!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;border-radius:0!important;background:#000!important;overflow:hidden!important;}' +
              '#player video,.player video,video{position:absolute!important;$videoAspectCss margin:0 auto!important;background:#000!important;}' +
              '#btnHomeBack,#btnShare,.embed-share-btn,#pvLoad,.pv-orb,.pv-overlay,.big-play,#btnPlay,.btn-play,#btnAspect,#btnRatio,.btn-aspect,[data-action="aspect"]{display:none!important;opacity:0!important;pointer-events:none!important;}' +
              '.embed-chrome-top{padding:12px 210px 12px 64px!important;}' +
              '.controls,.embed-chrome-bottom{padding-right:190px!important;}' +
              '.progress-played,.mini-progress-fill,.vol-hud-fill,.bright-hud .vol-hud-fill{background:$accentHex!important;}' +
              '.progress-handle{background:$accentHex!important;box-shadow:0 0 0 4px ${accentHex}38!important;}' +
              '$hideMiniCss' +
              '$brightCss';

            if (${englishPolish}) {
              var translatePlayerDom = function() {
                try {
                  var replacements = [
                    ['ভিডিও লোড হচ্ছে...', 'Loading video...'],
                    ['ভিডিও লোড হচ্ছে…', 'Loading video...'],
                    ['ভিডিও লোড হচ্ছে', 'Loading video...'],
                    ['Ready হচ্ছে', 'Loading video'],
                    ['লোড হচ্ছে', 'Loading'],
                    ['এই ভিডিওটি অনলাইনে চলছে না', 'This video cannot play online'],
                    ['কোয়ালিটিটি', 'This quality'],
                    ['আপনার ডিভাইস/ব্রাউজার অনলাইনে চালাতে পারছে না।', 'is not supported by your device/browser.'],
                    ['নিচে থেকে', 'Tap'],
                    ['করে', 'below to watch in'],
                    ['-এ দেখুন।', '.'],
                    ['দেখুন।', '.'],
                    ['Download করুন', 'Download']
                  ];
                  var pvTxt = document.querySelector('.pv-txt');
                  if (pvTxt) {
                    var t = (pvTxt.textContent || '').trim();
                    if (/[\u0980-\u09FF]/.test(t) || t.indexOf('Ready') !== -1) {
                      pvTxt.textContent = 'Loading video…';
                    }
                  }
                  var root = document.body || document.documentElement;
                  if (root && /[\u0980-\u09FF]/.test(root.innerText || '')) {
                    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
                    var node;
                    while ((node = walker.nextNode())) {
                      var val = node.nodeValue;
                      if (!val || !/[\u0980-\u09FF]/.test(val)) continue;
                      var next = val;
                      for (var i = 0; i < replacements.length; i++) {
                        if (next.indexOf(replacements[i][0]) !== -1) {
                          next = next.split(replacements[i][0]).join(replacements[i][1]);
                        }
                      }
                      if (/[\u0980-\u09FF]/.test(next)) {
                        next = next.replace(/[\u0980-\u09FF]+/g, 'Loading');
                      }
                      if (next !== val) node.nodeValue = next;
                    }
                  }
                } catch(_) {}
              };
              translatePlayerDom();
              if (!window.__mlBnObserver && document.documentElement) {
                window.__mlBnObserver = true;
                new MutationObserver(translatePlayerDom).observe(document.documentElement, {
                  childList: true,
                  characterData: true,
                  subtree: true
                });
              }
            }

            var syncVideoTracks = function(v) {
              try {
                if (!v || !window.MovieLinkPlayerBridge) return;
                var tt = [];
                if (v.textTracks) {
                  for (var i = 0; i < v.textTracks.length; i++) {
                    var tr = v.textTracks[i];
                    tt.push({
                      index: i,
                      label: tr.label || tr.language || ('Subtitle ' + (i + 1)),
                      lang: tr.language || '',
                      active: tr.mode === 'showing'
                    });
                  }
                }
                var at = [];
                if (v.audioTracks) {
                  for (var j = 0; j < v.audioTracks.length; j++) {
                    var au = v.audioTracks[j];
                    at.push({
                      index: j,
                      label: au.label || au.language || ('Audio ' + (j + 1)),
                      lang: au.language || '',
                      active: !!au.enabled
                    });
                  }
                }
                window.MovieLinkPlayerBridge.onTracks(JSON.stringify(tt), JSON.stringify(at));
              } catch(_) {}
            };

            var hookVideo = function() {
              try {
                var v = document.getElementById('video') || document.querySelector('video');
                if (!v || !window.MovieLinkPlayerBridge) return;
                v.playbackRate = $playbackSpeed;
                var emitState = function(bufferingOverride) {
                  var isPlayingNow = !v.paused && !v.ended && v.readyState >= 2;
                  var isBuf = bufferingOverride !== undefined
                    ? bufferingOverride
                    : (v.readyState < 3 && !v.paused && !v.ended);
                  window.MovieLinkPlayerBridge.setMediaState(!!isPlayingNow, !!isBuf);
                };
                if (!v.__mlMediaHooked) {
                  v.__mlMediaHooked = true;
                  var lastSent = 0;
                  var emitProgress = function(force) {
                    var now = Date.now();
                    if (!force && now - lastSent < 2000) return;
                    lastSent = now;
                    var pos = Math.floor((v.currentTime || 0) * 1000);
                    var dur = (v.duration && isFinite(v.duration)) ? Math.floor(v.duration * 1000) : 0;
                    window.MovieLinkPlayerBridge.onProgress(pos, dur);
                  };
                  v.addEventListener('loadstart', function(){ emitState(true); });
                  v.addEventListener('waiting', function(){ emitState(true); });
                  v.addEventListener('stalled', function(){ emitState(true); });
                  v.addEventListener('loadedmetadata', function(){ emitProgress(true); syncVideoTracks(v); });
                  v.addEventListener('canplay', function(){ emitState(false); emitProgress(true); syncVideoTracks(v); });
                  v.addEventListener('playing', function(){ emitState(false); v.playbackRate = $playbackSpeed; });
                  v.addEventListener('pause', function(){ emitState(false); emitProgress(true); });
                  v.addEventListener('timeupdate', function(){ emitProgress(false); });
                  v.addEventListener('ended', function(){ emitState(false); emitProgress(true); });
                  v.addEventListener('error', function(){ emitState(false); });
                  if (v.textTracks && v.textTracks.addEventListener) {
                    v.textTracks.addEventListener('change', function(){ syncVideoTracks(v); });
                    v.textTracks.addEventListener('addtrack', function(){ syncVideoTracks(v); });
                  }
                }
                emitState();
                syncVideoTracks(v);
              } catch(_) {}
            };
            hookVideo();
            if (!window.__mlVideoObserver && document.documentElement) {
              window.__mlVideoObserver = true;
              new MutationObserver(hookVideo).observe(document.documentElement, { childList: true, subtree: true });
            }

            if (!window.__mlDoubleTapHooked) {
              window.__mlDoubleTapHooked = true;
              var lastTapTime = 0;
              var lastTapX = 0;
              document.addEventListener('touchend', function(e) {
                try {
                  if (!e.changedTouches || e.changedTouches.length !== 1) return;
                  var tgt = e.target;
                  if (tgt && tgt.closest && tgt.closest('.controls,.embed-chrome-top,.embed-chrome-bottom,.ep-bar,.progress-wrap,button,a')) return;
                  var now = Date.now();
                  var x = e.changedTouches[0].clientX;
                  if (now - lastTapTime < 280 && Math.abs(x - lastTapX) < 90) {
                    lastTapTime = 0;
                    var v = document.getElementById('video') || document.querySelector('video');
                    if (v) {
                      var delta = (x < window.innerWidth * 0.5) ? -10 : 10;
                      var maxT = (v.duration && isFinite(v.duration)) ? v.duration : (v.currentTime + 10);
                      v.currentTime = Math.max(0, Math.min(maxT, (v.currentTime || 0) + delta));
                      if (window.MovieLinkPlayerBridge) {
                        window.MovieLinkPlayerBridge.onDoubleTapSeek(delta);
                      }
                    }
                  } else {
                    lastTapTime = now;
                    lastTapX = x;
                  }
                } catch(_) {}
              }, { passive: true });
            }

            if (${brightnessSync} && !window.__mlBrightHooked && window.MovieLinkPlayerBridge) {
              window.__mlBrightHooked = true;
              var lvlEl = document.getElementById('brightHudLevel');
              var veilEl = document.querySelector('.bright-veil');
              var syncFromHud = function() {
                try {
                  if (lvlEl && lvlEl.textContent) {
                    var num = parseFloat(lvlEl.textContent.replace('%','').trim());
                    if (!isNaN(num)) {
                      window.MovieLinkPlayerBridge.setBrightness(Math.max(0.02, Math.min(1, num / 100)));
                      return;
                    }
                  }
                  if (veilEl && veilEl.style && veilEl.style.opacity !== '') {
                    var op = parseFloat(veilEl.style.opacity);
                    if (!isNaN(op)) {
                      var lin = Math.max(0.02, Math.min(1, 1 - (op / 0.8)));
                      window.MovieLinkPlayerBridge.setBrightness(lin);
                    }
                  }
                } catch(_) {}
              };
              if (lvlEl) {
                new MutationObserver(syncFromHud).observe(lvlEl, { childList: true, characterData: true, subtree: true });
              }
              if (veilEl) {
                new MutationObserver(syncFromHud).observe(veilEl, { attributes: true, attributeFilter: ['style'] });
              }
            }

            var pEl = document.getElementById('player');
            if (pEl && !window.__mlControlsHooked && window.MovieLinkPlayerBridge) {
              window.__mlControlsHooked = true;
              var lastVis = null;
              var syncControls = function() {
                try {
                  var isIdle = pEl.classList.contains('idle');
                  var isLocked = pEl.classList.contains('locked');
                  var vis = !isIdle && !isLocked;
                  if (vis !== lastVis) {
                    lastVis = vis;
                    window.MovieLinkPlayerBridge.setControlsVisible(!!vis);
                  }
                } catch(_) {}
              };
              syncControls();
              new MutationObserver(syncControls).observe(pEl, { attributes: true, attributeFilter: ['class'] });
            }

            if (!window.__mlAutoPlayTried) {
              var tryPlay = function() {
                try {
                  var v = document.getElementById('video') || document.querySelector('video');
                  if (v && v.paused) {
                    window.__mlAutoPlayTried = true;
                    var orb = document.getElementById('pvLoad') || document.querySelector('.big-play');
                    if (orb && orb.click) orb.click();
                    if (v.play) v.play().catch(function(){});
                  }
                } catch(_) {}
              };
              tryPlay();
              setTimeout(tryPlay, 120);
            }
          } catch(e) {}
        })();
    """.trimIndent()

    view.evaluateJavascript(js, null)
}

private data class PlaybackDiagnostic(
    val origin: String,
    val summary: String,
    val detail: String,
    val suggestHlsRetry: Boolean = false
)

@OptIn(UnstableApi::class)
private fun classifyPlaybackError(error: PlaybackException, mimeHint: String?): PlaybackDiagnostic {
    val cause = error.cause
    return when {
        cause is HttpDataSource.InvalidResponseCodeException -> {
            val code = cause.responseCode
            val msg = when (code) {
                401, 403 -> "Stream host rejected playback (HTTP $code Forbidden). Required token or proxy header may have expired."
                404, 410 -> "Stream link expired or missing on server (HTTP $code)."
                429 -> "Stream host rate-limited requests (HTTP 429)."
                in 500..599 -> "Addon/CDN stream server returned error HTTP $code."
                else -> "Stream server returned HTTP $code."
            }
            PlaybackDiagnostic(
                origin = "Addon / Stream Server Error",
                summary = msg,
                detail = "Try another stream source from the addon list or open in VLC / MX Player."
            )
        }
        cause is HttpDataSource.CleartextNotPermittedException -> PlaybackDiagnostic(
            origin = "App / Transport Security",
            summary = "Cleartext HTTP playback was blocked.",
            detail = cause.localizedMessage.orEmpty()
        )
        cause is HttpDataSource.HttpDataSourceException -> {
            val netCause = cause.cause
            val detailMsg = when (netCause) {
                is UnknownHostException -> "DNS lookup failed: unable to resolve stream host."
                is SocketTimeoutException -> "Connection timed out waiting for the stream server."
                is SSLException -> "TLS/SSL handshake failed with stream host."
                else -> netCause?.localizedMessage ?: cause.localizedMessage.orEmpty()
            }
            PlaybackDiagnostic(
                origin = "Network / Internet Error",
                summary = "Unable to stream from server over the current network.",
                detail = detailMsg
            )
        }
        error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> PlaybackDiagnostic(
            origin = "Network / Internet Error",
            summary = "Network connection timed out or dropped while buffering.",
            detail = error.localizedMessage.orEmpty()
        )
        error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ||
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED ||
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED ||
            error.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> PlaybackDiagnostic(
            origin = "Unsupported Format / Container",
            summary = if (mimeHint == "application/dash+xml") {
                "DASH (.mpd) streams require an external player such as VLC or MX Player."
            } else {
                "ExoPlayer could not parse this stream container or manifest."
            },
            detail = "Try 'Retry as HLS' if this is an extensionless HLS link, or open in VLC / MX Player.",
            suggestHlsRetry = mimeHint != MimeTypes.APPLICATION_M3U8 && mimeHint != "application/dash+xml"
        )
        error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
            error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED -> PlaybackDiagnostic(
            origin = "Unsupported Media Codec",
            summary = "Device hardware/ExoPlayer could not decode this video or audio track.",
            detail = "Open in VLC / MX Player for software/AC3/DTS/HEVC codec support."
        )
        else -> PlaybackDiagnostic(
            origin = "Playback Failed (${error.errorCodeName})",
            summary = error.localizedMessage ?: "Unable to play this video stream",
            detail = cause?.localizedMessage.orEmpty()
        )
    }
}

private fun inferSubtitleMimeType(url: String): String {
    val clean = url.substringBefore('?').substringBefore('#').lowercase(Locale.US)
    return when {
        clean.endsWith(".vtt") -> MimeTypes.TEXT_VTT
        clean.endsWith(".srt") -> MimeTypes.APPLICATION_SUBRIP
        clean.endsWith(".ass") || clean.endsWith(".ssa") -> MimeTypes.TEXT_SSA
        clean.endsWith(".ttml") || clean.endsWith(".dfxp") || clean.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
        else -> MimeTypes.APPLICATION_SUBRIP
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val h = totalSec / 3600L
    val m = (totalSec % 3600L) / 60L
    val s = totalSec % 60L
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}
