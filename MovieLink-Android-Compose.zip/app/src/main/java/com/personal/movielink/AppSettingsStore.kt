package com.personal.movielink

import android.content.Context
import android.text.format.DateUtils
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val Context.movieLinkDataStore by preferencesDataStore(name = "movielink_datastore")

class AppSettingsStore(private val context: Context) {
    private val sp = context.getSharedPreferences("movielink_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _settings = MutableStateFlow(readFromPrefsSync())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private val _history = MutableStateFlow(readHistorySync())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    private val _myList = MutableStateFlow(readMyListSync())
    val myList: StateFlow<List<MyListItem>> = _myList.asStateFlow()

    init {
        scope.launch {
            val prefs = context.movieLinkDataStore.data.first()
            if (prefs.asMap().isNotEmpty()) {
                val synced = UserSettings(
                    mirrorUrl = Config.normalizeUrl(prefs[KEY_MIRROR_URL] ?: _settings.value.mirrorUrl),
                    resumeLastPage = prefs[KEY_RESUME_LAST] ?: _settings.value.resumeLastPage,
                    lastVisitedUrl = prefs[KEY_LAST_URL] ?: _settings.value.lastVisitedUrl,
                    downloaderMode = Config.DownloaderMode.fromId(prefs[KEY_DOWNLOADER_MODE] ?: _settings.value.downloaderMode.id),
                    videoActionMode = Config.VideoActionMode.fromId(prefs[KEY_VIDEO_MODE] ?: _settings.value.videoActionMode.id),
                    hideVideoProgressBar = prefs[KEY_HIDE_VIDEO_BAR] ?: _settings.value.hideVideoProgressBar,
                    playerBrightnessSync = prefs[KEY_PLAYER_BRIGHTNESS] ?: _settings.value.playerBrightnessSync,
                    desktopMode = prefs[KEY_DESKTOP_MODE] ?: _settings.value.desktopMode,
                    adBlockEnabled = prefs[KEY_ADBLOCK_ENABLED] ?: _settings.value.adBlockEnabled,
                    sitePolishEnabled = prefs[KEY_SITE_POLISH] ?: _settings.value.sitePolishEnabled,
                    showOttSection = prefs[KEY_SHOW_OTT] ?: _settings.value.showOttSection,
                    floatingNavBar = prefs[KEY_FLOATING_NAV] ?: _settings.value.floatingNavBar,
                    floatingNavHeightDp = prefs[KEY_FLOATING_HEIGHT] ?: _settings.value.floatingNavHeightDp,
                    floatingNavWidthPercent = prefs[KEY_FLOATING_WIDTH] ?: _settings.value.floatingNavWidthPercent,
                    floatingNavSpacingDp = prefs[KEY_FLOATING_SPACING] ?: _settings.value.floatingNavSpacingDp,
                    floatingNavAlphaPercent = prefs[KEY_FLOATING_ALPHA] ?: _settings.value.floatingNavAlphaPercent,
                    floatingNavColorHex = prefs[KEY_FLOATING_COLOR] ?: _settings.value.floatingNavColorHex,
                    detailBoxEnabled = prefs[KEY_DETAIL_BOX_ENABLED] ?: _settings.value.detailBoxEnabled,
                    detailBoxStyle = Config.DetailBoxStyle.fromId(prefs[KEY_DETAIL_BOX_STYLE] ?: _settings.value.detailBoxStyle.id),
                    detailBoxOpacityPercent = prefs[KEY_DETAIL_BOX_OPACITY] ?: _settings.value.detailBoxOpacityPercent,
                    detailBoxSizePercent = prefs[KEY_DETAIL_BOX_SIZE] ?: _settings.value.detailBoxSizePercent,
                    detailBoxColorHex = prefs[KEY_DETAIL_BOX_COLOR] ?: _settings.value.detailBoxColorHex,
                    bgPresetId = prefs[KEY_BG_PRESET] ?: _settings.value.bgPresetId,
                    customBgHex = prefs[KEY_CUSTOM_BG_HEX] ?: _settings.value.customBgHex,
                    themePresetId = prefs[KEY_THEME_PRESET] ?: _settings.value.themePresetId,
                    customThemeHex = prefs[KEY_CUSTOM_THEME_HEX] ?: _settings.value.customThemeHex,
                    customBlockedDomains = parseDomains(prefs[KEY_CUSTOM_BLOCKED] ?: ""),
                    customAllowedDomains = parseDomains(prefs[KEY_CUSTOM_ALLOWED] ?: ""),
                    showLocalPlayerTab = prefs[KEY_SHOW_LOCAL_TAB] ?: _settings.value.showLocalPlayerTab,
                    nuvioIntegrationEnabled = prefs[KEY_NUVIO_INTEGRATION] ?: _settings.value.nuvioIntegrationEnabled,
                    nuvioHomeCatalogsEnabled = prefs[KEY_NUVIO_HOME_CATALOGS] ?: _settings.value.nuvioHomeCatalogsEnabled,
                    nuvioHeroEnabled = prefs[KEY_NUVIO_HERO] ?: _settings.value.nuvioHeroEnabled,
                    nuvioSearchEnabled = prefs[KEY_NUVIO_SEARCH] ?: _settings.value.nuvioSearchEnabled,
                    watchFromAddonsEnabled = prefs[KEY_WATCH_FROM_ADDONS] ?: _settings.value.watchFromAddonsEnabled,
                    movieLinkHeroEnabled = prefs[KEY_ML_HERO] ?: _settings.value.movieLinkHeroEnabled,
                    movieLinkSearchEnabled = prefs[KEY_ML_SEARCH] ?: _settings.value.movieLinkSearchEnabled,
                    movieLinkWatchOnlineEnabled = prefs[KEY_ML_WATCH_ONLINE] ?: _settings.value.movieLinkWatchOnlineEnabled,
                    heroSourceKey = prefs[KEY_HERO_SOURCE_KEY] ?: _settings.value.heroSourceKey,
                    heroAutoRotate = prefs[KEY_HERO_AUTO_ROTATE] ?: _settings.value.heroAutoRotate
                )
                _settings.value = synced
            }
        }
    }

    fun startupUrl(): String {
        val s = _settings.value
        val last = s.lastVisitedUrl
        return if (s.resumeLastPage && !last.isNullOrBlank()) last else s.mirrorUrl
    }

    fun updateSettings(transform: (UserSettings) -> UserSettings) {
        val updated = transform(_settings.value).let {
            it.copy(mirrorUrl = Config.normalizeUrl(it.mirrorUrl))
        }
        _settings.value = updated
        persistSync(updated)
        scope.launch {
            context.movieLinkDataStore.edit { p ->
                p[KEY_MIRROR_URL] = updated.mirrorUrl
                p[KEY_RESUME_LAST] = updated.resumeLastPage
                if (updated.lastVisitedUrl != null) p[KEY_LAST_URL] = updated.lastVisitedUrl else p.remove(KEY_LAST_URL)
                p[KEY_DOWNLOADER_MODE] = updated.downloaderMode.id
                p[KEY_VIDEO_MODE] = updated.videoActionMode.id
                p[KEY_HIDE_VIDEO_BAR] = updated.hideVideoProgressBar
                p[KEY_PLAYER_BRIGHTNESS] = updated.playerBrightnessSync
                p[KEY_DESKTOP_MODE] = updated.desktopMode
                p[KEY_ADBLOCK_ENABLED] = updated.adBlockEnabled
                p[KEY_SITE_POLISH] = updated.sitePolishEnabled
                p[KEY_SHOW_OTT] = updated.showOttSection
                p[KEY_FLOATING_NAV] = updated.floatingNavBar
                p[KEY_FLOATING_HEIGHT] = updated.floatingNavHeightDp
                p[KEY_FLOATING_WIDTH] = updated.floatingNavWidthPercent
                p[KEY_FLOATING_SPACING] = updated.floatingNavSpacingDp
                p[KEY_FLOATING_ALPHA] = updated.floatingNavAlphaPercent
                if (updated.floatingNavColorHex != null) p[KEY_FLOATING_COLOR] = updated.floatingNavColorHex else p.remove(KEY_FLOATING_COLOR)
                p[KEY_DETAIL_BOX_ENABLED] = updated.detailBoxEnabled
                p[KEY_DETAIL_BOX_STYLE] = updated.detailBoxStyle.id
                p[KEY_DETAIL_BOX_OPACITY] = updated.detailBoxOpacityPercent
                p[KEY_DETAIL_BOX_SIZE] = updated.detailBoxSizePercent
                p[KEY_DETAIL_BOX_COLOR] = updated.detailBoxColorHex
                p[KEY_BG_PRESET] = updated.bgPresetId
                if (updated.customBgHex != null) p[KEY_CUSTOM_BG_HEX] = updated.customBgHex else p.remove(KEY_CUSTOM_BG_HEX)
                p[KEY_THEME_PRESET] = updated.themePresetId
                if (updated.customThemeHex != null) p[KEY_CUSTOM_THEME_HEX] = updated.customThemeHex else p.remove(KEY_CUSTOM_THEME_HEX)
                p[KEY_CUSTOM_BLOCKED] = updated.customBlockedDomains.sorted().joinToString("\n")
                p[KEY_CUSTOM_ALLOWED] = updated.customAllowedDomains.sorted().joinToString("\n")
                p[KEY_SHOW_LOCAL_TAB] = updated.showLocalPlayerTab
                p[KEY_NUVIO_INTEGRATION] = updated.nuvioIntegrationEnabled
                p[KEY_NUVIO_HOME_CATALOGS] = updated.nuvioHomeCatalogsEnabled
                p[KEY_NUVIO_HERO] = updated.nuvioHeroEnabled
                p[KEY_NUVIO_SEARCH] = updated.nuvioSearchEnabled
                p[KEY_WATCH_FROM_ADDONS] = updated.watchFromAddonsEnabled
                p[KEY_ML_HERO] = updated.movieLinkHeroEnabled
                p[KEY_ML_SEARCH] = updated.movieLinkSearchEnabled
                p[KEY_ML_WATCH_ONLINE] = updated.movieLinkWatchOnlineEnabled
                if (updated.heroSourceKey != null) p[KEY_HERO_SOURCE_KEY] = updated.heroSourceKey else p.remove(KEY_HERO_SOURCE_KEY)
                p[KEY_HERO_AUTO_ROTATE] = updated.heroAutoRotate
            }
        }
    }

    fun setCustomDomainsRaw(blockedRaw: String, allowedRaw: String) {
        updateSettings {
            it.copy(
                customBlockedDomains = parseDomains(blockedRaw),
                customAllowedDomains = parseDomains(allowedRaw)
            )
        }
    }

    fun recordHistory(title: String?, url: String, posterUrl: String = "") {
        if (url.isBlank() || url.startsWith("data:") || url == "about:blank") return
        val cleanTitle = title?.trim()?.takeIf { it.isNotEmpty() } ?: url
        val next = _history.value
            .filterNot { it.url == url }
            .toMutableList()
            .apply { add(0, HistoryItem(cleanTitle, url, posterUrl, System.currentTimeMillis())) }
            .take(MAX_HISTORY)

        _history.value = next
        val arr = JSONArray()
        for (item in next) {
            arr.put(JSONObject().apply {
                put("title", item.title)
                put("url", item.url)
                put("poster", item.posterUrl)
                put("ts", item.timestamp)
            })
        }
        sp.edit().putString("history_json", arr.toString()).apply()
        updateSettings { it.copy(lastVisitedUrl = url) }
    }

    fun clearHistory() {
        _history.value = emptyList()
        sp.edit().remove("history_json").remove("last_url").apply()
        updateSettings { it.copy(lastVisitedUrl = null) }
    }

    fun toggleMyList(item: MyListItem): Boolean {
        val current = _myList.value
        val exists = current.any { it.url == item.url }
        val next = if (exists) {
            current.filterNot { it.url == item.url }
        } else {
            listOf(item) + current
        }
        saveMyList(next)
        return !exists
    }

    fun removeFromMyList(url: String) {
        saveMyList(_myList.value.filterNot { it.url == url })
    }

    fun isInMyList(url: String): Boolean = _myList.value.any { it.url == url }

    private fun saveMyList(items: List<MyListItem>) {
        _myList.value = items
        val arr = JSONArray()
        for (item in items) {
            arr.put(JSONObject().apply {
                put("url", item.url)
                put("title", item.title)
                put("poster", item.posterUrl)
                put("type", item.type)
                put("quality", item.quality)
                put("language", item.language)
                put("ts", item.addedAt)
            })
        }
        sp.edit().putString("mylist_json", arr.toString()).apply()
    }

    private fun readFromPrefsSync(): UserSettings {
        return UserSettings(
            mirrorUrl = Config.normalizeUrl(sp.getString("mirror_url", Config.DEFAULT_HOME_URL) ?: Config.DEFAULT_HOME_URL),
            resumeLastPage = sp.getBoolean("resume_last_page", true),
            lastVisitedUrl = sp.getString("last_url", null),
            downloaderMode = Config.DownloaderMode.fromId(sp.getString("downloader_mode", Config.DownloaderMode.AUTO.id)),
            videoActionMode = Config.VideoActionMode.fromId(sp.getString("video_action_mode", Config.VideoActionMode.ASK.id)),
            hideVideoProgressBar = sp.getBoolean("hide_video_progress_bar", true),
            playerBrightnessSync = sp.getBoolean("player_brightness_sync", true),
            desktopMode = sp.getBoolean("desktop_mode", false),
            adBlockEnabled = sp.getBoolean("adblock_enabled", true),
            sitePolishEnabled = sp.getBoolean("site_polish_enabled", true),
            showOttSection = sp.getBoolean("show_ott_section", true),
            floatingNavBar = sp.getBoolean("floating_nav_bar", false),
            floatingNavHeightDp = sp.getInt("floating_nav_height", 56),
            floatingNavWidthPercent = sp.getInt("floating_nav_width", 88),
            floatingNavSpacingDp = sp.getInt("floating_nav_spacing", 14),
            floatingNavAlphaPercent = sp.getInt("floating_nav_alpha", 90),
            floatingNavColorHex = sp.getString("floating_nav_color", null),
            detailBoxEnabled = sp.getBoolean("detail_box_enabled", true),
            detailBoxStyle = Config.DetailBoxStyle.fromId(sp.getString("detail_box_style", Config.DetailBoxStyle.ROUNDED.id)),
            detailBoxOpacityPercent = sp.getInt("detail_box_opacity", 85),
            detailBoxSizePercent = sp.getInt("detail_box_size", 100),
            detailBoxColorHex = sp.getString("detail_box_color", "#71717A") ?: "#71717A",
            bgPresetId = sp.getString("bg_preset", Config.BgPreset.BLACK.id) ?: Config.BgPreset.BLACK.id,
            customBgHex = sp.getString("custom_bg_hex", null),
            themePresetId = sp.getString("theme_preset", Config.ThemePreset.CYAN.id) ?: Config.ThemePreset.CYAN.id,
            customThemeHex = sp.getString("custom_theme_hex", null),
            customBlockedDomains = parseDomains(sp.getString("custom_blocked", "") ?: ""),
            customAllowedDomains = parseDomains(sp.getString("custom_allowed", "") ?: ""),
            showLocalPlayerTab = sp.getBoolean("show_local_player_tab", true),
            nuvioIntegrationEnabled = sp.getBoolean("nuvio_integration_enabled", false),
            nuvioHomeCatalogsEnabled = sp.getBoolean("nuvio_home_catalogs_enabled", false),
            nuvioHeroEnabled = sp.getBoolean("nuvio_hero_enabled", false),
            nuvioSearchEnabled = sp.getBoolean("nuvio_search_enabled", false),
            watchFromAddonsEnabled = sp.getBoolean("watch_from_addons_enabled", false),
            movieLinkHeroEnabled = sp.getBoolean("movielink_hero_enabled", true),
            movieLinkSearchEnabled = sp.getBoolean("movielink_search_enabled", true),
            movieLinkWatchOnlineEnabled = sp.getBoolean("movielink_watch_online_enabled", true),
            heroSourceKey = sp.getString("hero_source_key", null),
            heroAutoRotate = sp.getBoolean("hero_auto_rotate", false)
        )
    }

    private fun persistSync(s: UserSettings) {
        sp.edit()
            .putString("mirror_url", s.mirrorUrl)
            .putBoolean("resume_last_page", s.resumeLastPage)
            .putString("last_url", s.lastVisitedUrl)
            .putString("downloader_mode", s.downloaderMode.id)
            .putString("video_action_mode", s.videoActionMode.id)
            .putBoolean("hide_video_progress_bar", s.hideVideoProgressBar)
            .putBoolean("player_brightness_sync", s.playerBrightnessSync)
            .putBoolean("desktop_mode", s.desktopMode)
            .putBoolean("adblock_enabled", s.adBlockEnabled)
            .putBoolean("site_polish_enabled", s.sitePolishEnabled)
            .putBoolean("show_ott_section", s.showOttSection)
            .putBoolean("floating_nav_bar", s.floatingNavBar)
            .putInt("floating_nav_height", s.floatingNavHeightDp)
            .putInt("floating_nav_width", s.floatingNavWidthPercent)
            .putInt("floating_nav_spacing", s.floatingNavSpacingDp)
            .putInt("floating_nav_alpha", s.floatingNavAlphaPercent)
            .putString("floating_nav_color", s.floatingNavColorHex)
            .putBoolean("detail_box_enabled", s.detailBoxEnabled)
            .putString("detail_box_style", s.detailBoxStyle.id)
            .putInt("detail_box_opacity", s.detailBoxOpacityPercent)
            .putInt("detail_box_size", s.detailBoxSizePercent)
            .putString("detail_box_color", s.detailBoxColorHex)
            .putString("bg_preset", s.bgPresetId)
            .putString("custom_bg_hex", s.customBgHex)
            .putString("theme_preset", s.themePresetId)
            .putString("custom_theme_hex", s.customThemeHex)
            .putString("custom_blocked", s.customBlockedDomains.sorted().joinToString("\n"))
            .putString("custom_allowed", s.customAllowedDomains.sorted().joinToString("\n"))
            .putBoolean("show_local_player_tab", s.showLocalPlayerTab)
            .putBoolean("nuvio_integration_enabled", s.nuvioIntegrationEnabled)
            .putBoolean("nuvio_home_catalogs_enabled", s.nuvioHomeCatalogsEnabled)
            .putBoolean("nuvio_hero_enabled", s.nuvioHeroEnabled)
            .putBoolean("nuvio_search_enabled", s.nuvioSearchEnabled)
            .putBoolean("watch_from_addons_enabled", s.watchFromAddonsEnabled)
            .putBoolean("movielink_hero_enabled", s.movieLinkHeroEnabled)
            .putBoolean("movielink_search_enabled", s.movieLinkSearchEnabled)
            .putBoolean("movielink_watch_online_enabled", s.movieLinkWatchOnlineEnabled)
            .putString("hero_source_key", s.heroSourceKey)
            .putBoolean("hero_auto_rotate", s.heroAutoRotate)
            .apply()
    }

    private fun readHistorySync(): List<HistoryItem> {
        val raw = sp.getString("history_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val url = obj.optString("url", "")
                    if (url.isNotEmpty()) {
                        add(
                            HistoryItem(
                                title = obj.optString("title", url),
                                url = url,
                                posterUrl = obj.optString("poster", ""),
                                timestamp = obj.optLong("ts", 0L)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun readMyListSync(): List<MyListItem> {
        val raw = sp.getString("mylist_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val url = obj.optString("url", "")
                    if (url.isNotEmpty()) {
                        add(
                            MyListItem(
                                url = url,
                                title = obj.optString("title", url),
                                posterUrl = obj.optString("poster", ""),
                                type = obj.optString("type", "Title"),
                                quality = obj.optString("quality", "HD"),
                                language = obj.optString("language", "Multi"),
                                addedAt = obj.optLong("ts", 0L)
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        private const val MAX_HISTORY = 25

        private val KEY_MIRROR_URL = stringPreferencesKey("mirror_url")
        private val KEY_RESUME_LAST = booleanPreferencesKey("resume_last_page")
        private val KEY_LAST_URL = stringPreferencesKey("last_url")
        private val KEY_DOWNLOADER_MODE = stringPreferencesKey("downloader_mode")
        private val KEY_VIDEO_MODE = stringPreferencesKey("video_action_mode")
        private val KEY_HIDE_VIDEO_BAR = booleanPreferencesKey("hide_video_progress_bar")
        private val KEY_PLAYER_BRIGHTNESS = booleanPreferencesKey("player_brightness_sync")
        private val KEY_DESKTOP_MODE = booleanPreferencesKey("desktop_mode")
        private val KEY_ADBLOCK_ENABLED = booleanPreferencesKey("adblock_enabled")
        private val KEY_SITE_POLISH = booleanPreferencesKey("site_polish_enabled")
        private val KEY_SHOW_OTT = booleanPreferencesKey("show_ott_section")
        private val KEY_FLOATING_NAV = booleanPreferencesKey("floating_nav_bar")
        private val KEY_FLOATING_HEIGHT = intPreferencesKey("floating_nav_height")
        private val KEY_FLOATING_WIDTH = intPreferencesKey("floating_nav_width")
        private val KEY_FLOATING_SPACING = intPreferencesKey("floating_nav_spacing")
        private val KEY_FLOATING_ALPHA = intPreferencesKey("floating_nav_alpha")
        private val KEY_FLOATING_COLOR = stringPreferencesKey("floating_nav_color")
        private val KEY_DETAIL_BOX_ENABLED = booleanPreferencesKey("detail_box_enabled")
        private val KEY_DETAIL_BOX_STYLE = stringPreferencesKey("detail_box_style")
        private val KEY_DETAIL_BOX_OPACITY = intPreferencesKey("detail_box_opacity")
        private val KEY_DETAIL_BOX_SIZE = intPreferencesKey("detail_box_size")
        private val KEY_DETAIL_BOX_COLOR = stringPreferencesKey("detail_box_color")
        private val KEY_BG_PRESET = stringPreferencesKey("bg_preset")
        private val KEY_CUSTOM_BG_HEX = stringPreferencesKey("custom_bg_hex")
        private val KEY_THEME_PRESET = stringPreferencesKey("theme_preset")
        private val KEY_CUSTOM_THEME_HEX = stringPreferencesKey("custom_theme_hex")
        private val KEY_CUSTOM_BLOCKED = stringPreferencesKey("custom_blocked")
        private val KEY_CUSTOM_ALLOWED = stringPreferencesKey("custom_allowed")
        private val KEY_SHOW_LOCAL_TAB = booleanPreferencesKey("show_local_player_tab")
        private val KEY_NUVIO_INTEGRATION = booleanPreferencesKey("nuvio_integration_enabled")
        private val KEY_NUVIO_HOME_CATALOGS = booleanPreferencesKey("nuvio_home_catalogs_enabled")
        private val KEY_NUVIO_HERO = booleanPreferencesKey("nuvio_hero_enabled")
        private val KEY_NUVIO_SEARCH = booleanPreferencesKey("nuvio_search_enabled")
        private val KEY_WATCH_FROM_ADDONS = booleanPreferencesKey("watch_from_addons_enabled")
        private val KEY_ML_HERO = booleanPreferencesKey("movielink_hero_enabled")
        private val KEY_ML_SEARCH = booleanPreferencesKey("movielink_search_enabled")
        private val KEY_ML_WATCH_ONLINE = booleanPreferencesKey("movielink_watch_online_enabled")
        private val KEY_HERO_SOURCE_KEY = stringPreferencesKey("hero_source_key")
        private val KEY_HERO_AUTO_ROTATE = booleanPreferencesKey("hero_auto_rotate")

        fun parseDomains(raw: String): Set<String> =
            raw.split(',', '\n', '\r', ' ')
                .map {
                    it.trim().lowercase(Locale.US)
                        .removePrefix("https://")
                        .removePrefix("http://")
                        .substringBefore('/')
                }
                .filter { it.contains('.') && !it.contains(' ') }
                .toSet()

        fun formatRelativeTime(timestamp: Long): String {
            if (timestamp <= 0L) return ""
            return DateUtils.getRelativeTimeSpanString(
                timestamp,
                System.currentTimeMillis(),
                DateUtils.MINUTE_IN_MILLIS
            ).toString()
        }
    }
}
