package com.personal.movielink.addons

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

enum class AddonErrorCategory {
    ADDON_SERVER,
    NETWORK,
    APP_OR_CONFIG
}

class AddonHttpException(
    val category: AddonErrorCategory,
    val httpCode: Int? = null,
    override val message: String,
    cause: Throwable? = null
) : IOException(message, cause)

object AddonHttp {
    private const val MAX_JSON_BYTES = 5 * 1024 * 1024 // 5 MB safety limit per addon response

    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectionPool(ConnectionPool(8, 3, TimeUnit.MINUTES))
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    fun normalizeAndValidateManifestUrl(rawInput: String): Pair<String, String> {
        var trimmed = rawInput.trim()
        if (trimmed.isEmpty()) throw IllegalArgumentException("Manifest URL cannot be empty")
        if (trimmed.startsWith("stremio://", ignoreCase = true)) {
            trimmed = "https://" + trimmed.substring("stremio://".length)
        }
        if (!trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true)
        ) {
            trimmed = "https://$trimmed"
        }

        val parsed = Uri.parse(trimmed)
        val scheme = parsed.scheme?.lowercase()
        val host = parsed.host
        if ((scheme != "http" && scheme != "https") || host.isNullOrBlank()) {
            throw IllegalArgumentException("Enter a valid http:// or https:// addon manifest URL")
        }

        // Preserve base path (including addon configuration tokens) cleanly
        val noFragment = trimmed.substringBefore('#')
        val queryPart = noFragment.substringAfter('?', "")
        val withoutQuery = noFragment.substringBefore('?')

        val cleanWithoutQuery = when {
            withoutQuery.endsWith("/manifest.json", ignoreCase = true) -> withoutQuery
            withoutQuery.endsWith("/configure", ignoreCase = true) ->
                withoutQuery.dropLast("/configure".length).trimEnd('/') + "/manifest.json"
            else -> withoutQuery.trimEnd('/') + "/manifest.json"
        }

        val manifestUrl = if (queryPart.isNotBlank()) "$cleanWithoutQuery?$queryPart" else cleanWithoutQuery
        val baseUrl = cleanWithoutQuery.dropLast("/manifest.json".length).trimEnd('/')
        return manifestUrl to baseUrl
    }

    suspend fun getJsonObject(url: String): JSONObject =
        getJsonObjectWithHeaders(url = url, extraHeaders = emptyMap())

    suspend fun getJsonObjectWithHeaders(
        url: String,
        extraHeaders: Map<String, String>
    ): JSONObject = withContext(Dispatchers.IO) {
        val uri = Uri.parse(url)
        val scheme = uri.scheme?.lowercase()
        if ((scheme != "http" && scheme != "https") || uri.host.isNullOrBlank()) {
            throw AddonHttpException(
                category = AddonErrorCategory.APP_OR_CONFIG,
                message = "Invalid addon endpoint URL"
            )
        }

        val reqBuilder = Request.Builder()
            .url(url)
            .header("Accept", "application/json, text/plain;q=0.9, */*;q=0.8")
            .header("User-Agent", "MovieLink-Android/2.0 (Stremio-Compatible)")
        extraHeaders.forEach { (k, v) ->
            if (k.isNotBlank() && v.isNotBlank()) {
                reqBuilder.header(k.trim(), v.trim())
            }
        }
        val req = reqBuilder.build()

        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val msg = when (resp.code) {
                        401, 403 -> "Addon server rejected request (HTTP ${resp.code} — check addon config/key)"
                        404 -> "Addon endpoint not found (HTTP 404)"
                        429 -> "Addon server rate-limited requests (HTTP 429)"
                        in 500..599 -> "Addon server error (HTTP ${resp.code})"
                        else -> "HTTP ${resp.code} from addon endpoint"
                    }
                    throw AddonHttpException(
                        category = AddonErrorCategory.ADDON_SERVER,
                        httpCode = resp.code,
                        message = msg
                    )
                }
                val body = resp.body ?: throw AddonHttpException(
                    category = AddonErrorCategory.ADDON_SERVER,
                    message = "Empty response body from addon server"
                )
                val contentLen = body.contentLength()
                if (contentLen > MAX_JSON_BYTES) {
                    throw AddonHttpException(
                        category = AddonErrorCategory.ADDON_SERVER,
                        message = "Addon response exceeds 5 MB limit"
                    )
                }

                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                body.byteStream().use { stream ->
                    while (true) {
                        val n = stream.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_JSON_BYTES) {
                            throw AddonHttpException(
                                category = AddonErrorCategory.ADDON_SERVER,
                                message = "Addon response exceeds 5 MB limit"
                            )
                        }
                        out.write(buf, 0, n)
                    }
                }

                val text = out.toString(Charsets.UTF_8.name())
                    .removePrefix("\uFEFF")
                    .trim()
                if (text.isEmpty() || !text.startsWith("{")) {
                    throw AddonHttpException(
                        category = AddonErrorCategory.ADDON_SERVER,
                        message = "Addon server returned invalid JSON payload"
                    )
                }
                JSONObject(text)
            }
        } catch (e: AddonHttpException) {
            throw e
        } catch (e: java.net.UnknownHostException) {
            throw AddonHttpException(
                category = AddonErrorCategory.NETWORK,
                message = "Network/DNS failure: unable to reach ${uri.host}",
                cause = e
            )
        } catch (e: java.net.SocketTimeoutException) {
            throw AddonHttpException(
                category = AddonErrorCategory.NETWORK,
                message = "Network timeout waiting for ${uri.host}",
                cause = e
            )
        } catch (e: javax.net.ssl.SSLException) {
            throw AddonHttpException(
                category = AddonErrorCategory.NETWORK,
                message = "SSL/TLS connection error contacting ${uri.host}",
                cause = e
            )
        } catch (e: IOException) {
            throw AddonHttpException(
                category = AddonErrorCategory.NETWORK,
                message = "Network connection failed: ${e.message ?: "check internet"}",
                cause = e
            )
        }
    }
}

class AddonManifestRepository {
    suspend fun fetchAndValidateManifest(rawUrl: String): Result<InstalledAddon> {
        return try {
            val (manifestUrl, baseUrl) = AddonHttp.normalizeAndValidateManifestUrl(rawUrl)
            val json = AddonHttp.getJsonObject(manifestUrl)
            val manifest = StremioManifestCodec.fromJson(json)
                ?: return Result.failure(
                    IllegalArgumentException("Invalid Stremio manifest: missing required id, name, or version")
                )

            val status = if (manifest.behaviorHints.configurationRequired) {
                AddonConnectionStatus.CONFIG_REQUIRED
            } else {
                AddonConnectionStatus.CONNECTED
            }

            Result.success(
                InstalledAddon(
                    id = manifest.id,
                    manifestUrl = manifestUrl,
                    baseUrl = baseUrl,
                    manifest = manifest,
                    enabled = true,
                    status = status,
                    lastError = null,
                    lastCheckedAt = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
