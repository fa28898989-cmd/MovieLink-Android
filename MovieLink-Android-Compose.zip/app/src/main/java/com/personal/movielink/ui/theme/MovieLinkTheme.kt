package com.personal.movielink.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import com.personal.movielink.Config
import com.personal.movielink.UserSettings

@Immutable
data class MovieLinkPalette(
    val pageBg: Color,
    val cardBg: Color,
    val altBg: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val fg: Color,
    val border: Color,
    val boxBg: Color,
    val boxBorder: Color,
    val onAccent: Color,
    val onPureAccent: Color = Color.White,
    val isLightBg: Boolean
)

val LocalMovieLinkPalette = staticCompositionLocalOf {
    MovieLinkPalette(
        pageBg = Color.Black,
        cardBg = Color(0xFF0C0C0E),
        altBg = Color(0xFF141418),
        textPrimary = Color(0xFFF4F4F5),
        textSecondary = Color(0xFFA1A1AA),
        accent = Color(0xFF06B6D4),
        fg = Color(0xFF22D3EE),
        border = Color(0xFF06B6D4),
        boxBg = Color(0xFF0A2129),
        boxBorder = Color(0xFF22D3EE),
        onAccent = Color(0xFF0A0D12),
        onPureAccent = Color(0xFF0A0D12),
        isLightBg = false
    )
}

@Composable
fun MovieLinkTheme(
    settings: UserSettings,
    content: @Composable () -> Unit
) {
    val resolvedBg = Config.resolveBg(settings.bgPresetId, settings.customBgHex)
    val resolvedTheme = Config.resolveTheme(settings.themePresetId, settings.customThemeHex)

    val pageInt = resolvedBg.pageInt()
    val cardInt = resolvedBg.cardInt()
    val altInt = resolvedBg.altInt()
    val accentInt = resolvedTheme.accentInt()
    val fgInt = resolvedTheme.fgInt()

    val isLightBg = resolvedBg.isLight
    val boxBorderInt = when {
        isLightBg && resolvedTheme.isBrightAccent() ->
            ColorUtils.blendARGB(accentInt, android.graphics.Color.BLACK, 0.35f)
        isLightBg -> accentInt
        resolvedTheme.id == "black" || resolvedTheme.isDarkAccent() -> android.graphics.Color.parseColor("#3F3F46")
        resolvedTheme.id == "white" -> android.graphics.Color.WHITE
        resolvedTheme.id == "grey" -> android.graphics.Color.parseColor("#9CA3AF")
        else -> fgInt
    }

    val blendAmount = when {
        isLightBg -> 0.12f
        resolvedTheme.id == "black" -> 0.25f
        resolvedTheme.id == "white" -> 0.08f
        resolvedTheme.id == "grey" -> 0.14f
        else -> 0.18f
    }
    val boxBgInt = ColorUtils.blendARGB(cardInt, accentInt, blendAmount)

    val effectiveFgInt = when {
        isLightBg && resolvedTheme.isBrightAccent() ->
            ColorUtils.blendARGB(accentInt, android.graphics.Color.BLACK, 0.38f)
        isLightBg -> accentInt
        resolvedTheme.isDarkAccent() -> android.graphics.Color.parseColor("#E4E4E7")
        else -> fgInt
    }
    val onAccentInt = if (ColorUtils.calculateLuminance(effectiveFgInt) > 0.42) {
        android.graphics.Color.parseColor("#0A0D12")
    } else {
        android.graphics.Color.WHITE
    }
    val onPureAccentInt = resolvedTheme.onPureAccentInt()

    val palette = MovieLinkPalette(
        pageBg = Color(pageInt),
        cardBg = Color(cardInt),
        altBg = Color(altInt),
        textPrimary = if (isLightBg) Color(0xFF18181B) else Color(0xFFF4F4F5),
        textSecondary = if (isLightBg) Color(0xFF52525B) else Color(0xFFA1A1AA),
        accent = Color(accentInt),
        fg = Color(effectiveFgInt),
        border = Color(resolvedTheme.borderInt()),
        boxBg = Color(boxBgInt),
        boxBorder = Color(boxBorderInt),
        onAccent = Color(onAccentInt),
        onPureAccent = Color(onPureAccentInt),
        isLightBg = isLightBg
    )

    val colorScheme = if (isLightBg) {
        lightColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.pageBg,
            onBackground = palette.textPrimary,
            surface = palette.cardBg,
            onSurface = palette.textPrimary,
            surfaceVariant = palette.altBg,
            onSurfaceVariant = palette.textSecondary,
            outline = palette.boxBorder
        )
    } else {
        darkColorScheme(
            primary = palette.accent,
            onPrimary = palette.onAccent,
            background = palette.pageBg,
            onBackground = palette.textPrimary,
            surface = palette.cardBg,
            onSurface = palette.textPrimary,
            surfaceVariant = palette.altBg,
            onSurfaceVariant = palette.textSecondary,
            outline = palette.boxBorder
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.setDecorFitsSystemWindows(window, false)
                @Suppress("DEPRECATION")
                window.statusBarColor = android.graphics.Color.TRANSPARENT
                @Suppress("DEPRECATION")
                window.navigationBarColor = android.graphics.Color.TRANSPARENT
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    window.isNavigationBarContrastEnforced = false
                }
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = isLightBg
                controller.isAppearanceLightNavigationBars = isLightBg
            }
        }
    }

    CompositionLocalProvider(LocalMovieLinkPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
