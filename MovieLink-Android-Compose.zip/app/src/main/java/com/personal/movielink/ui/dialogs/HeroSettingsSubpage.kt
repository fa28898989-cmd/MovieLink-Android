package com.personal.movielink.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.personal.movielink.HeroSourceOption
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.ContentProviderKind
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@Composable
fun HeroSettingsSubpage(
    settings: UserSettings,
    heroSources: List<HeroSourceOption>,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val nuvioHeroAvailable = settings.nuvioIntegrationEnabled && settings.nuvioHeroEnabled
    val mlSources = heroSources.filter { it.provider == ContentProviderKind.MOVIELINK_BD }
    val addonSources = heroSources.filter { it.provider == ContentProviderKind.STREMIO_ADDON }

    val selectedKey = settings.heroSourceKey?.takeIf { it.isNotBlank() }
    val selectedOption = heroSources.firstOrNull { it.key == selectedKey }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "Choose which provider and catalogue supplies the Home screen hero carousel. Uses live posters and metadata with zero hardcoded fallback items.",
            color = palette.textSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )

        HeroSectionHeader("Hero Provider Switches")
        HeroToggleRow(
            title = "MovieLinkBD Hero Content",
            subtitle = "Allow MovieLinkBD catalogues to supply hero posters",
            checked = settings.movieLinkHeroEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(movieLinkHeroEnabled = v) } }
        )
        HeroToggleRow(
            title = "Nuvio Hero Content",
            subtitle = if (settings.nuvioIntegrationEnabled) {
                "Allow installed Stremio addon catalogues to supply hero posters"
            } else {
                "Requires Nuvio Addon Integration to be enabled in Providers"
            },
            checked = settings.nuvioHeroEnabled,
            enabled = settings.nuvioIntegrationEnabled,
            onCheckedChange = { v -> onUpdateSettings { it.copy(nuvioHeroEnabled = v) } }
        )
        HeroToggleRow(
            title = "Automatic Poster Rotation",
            subtitle = "Automatically cycle through hero carousel posters every 4.5s",
            checked = settings.heroAutoRotate,
            onCheckedChange = { v -> onUpdateSettings { it.copy(heroAutoRotate = v) } }
        )

        if (!settings.movieLinkHeroEnabled && !nuvioHeroAvailable) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.altBg)
                    .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "Both MovieLinkBD and Nuvio hero sources are disabled. The hero carousel is currently hidden on the Home screen.",
                    color = Color(0xFFFBBF24),
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        } else if (selectedKey != null && selectedOption == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.altBg)
                    .border(1.dp, Color(0xFFFBBF24).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "The previously selected hero catalogue is currently unavailable or its addon was removed. Pick another source below.",
                    color = Color(0xFFFBBF24),
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(Modifier.height(2.dp))
        HeroSectionHeader("MovieLinkBD Hero Sources")

        HeroRadioOptionRow(
            title = "Auto (MovieLinkBD Default)",
            badge = "MovieLinkBD",
            subtitle = "Prioritizes Movies & Featured titles from live Home",
            selected = selectedKey == null,
            enabled = settings.movieLinkHeroEnabled,
            isAddonBadge = false,
            onClick = { onUpdateSettings { it.copy(heroSourceKey = null) } }
        )

        mlSources.forEach { src ->
            HeroRadioOptionRow(
                title = src.title,
                badge = src.providerLabel,
                subtitle = if (settings.movieLinkHeroEnabled) "Use live ${src.title} posters" else "MovieLinkBD Hero disabled",
                selected = selectedKey == src.key,
                enabled = settings.movieLinkHeroEnabled && src.isAvailable,
                isAddonBadge = false,
                onClick = { onUpdateSettings { it.copy(heroSourceKey = src.key) } }
            )
        }

        Spacer(Modifier.height(2.dp))
        HeroSectionHeader("Nuvio Addon Hero Sources")

        if (addonSources.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(palette.altBg)
                    .padding(12.dp)
            ) {
                Text(
                    text = "No enabled Stremio addon catalogues found. Install and enable an addon in Settings → Addons to select it as your Hero source.",
                    color = palette.textSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            }
        } else {
            addonSources.forEach { src ->
                HeroRadioOptionRow(
                    title = src.title,
                    badge = src.providerLabel,
                    subtitle = when {
                        !settings.nuvioIntegrationEnabled -> "Turn ON Nuvio Integration first"
                        !settings.nuvioHeroEnabled -> "Turn ON Nuvio Hero Content above to activate"
                        else -> "Live posters from ${src.providerLabel}"
                    },
                    selected = selectedKey == src.key,
                    enabled = nuvioHeroAvailable && src.isAvailable,
                    isAddonBadge = true,
                    onClick = { onUpdateSettings { it.copy(heroSourceKey = src.key) } }
                )
            }
        }
    }
}

@Composable
private fun HeroSectionHeader(title: String) {
    val palette = LocalMovieLinkPalette.current
    Text(
        text = title,
        color = palette.fg,
        fontSize = 13.5.sp,
        fontWeight = FontWeight.ExtraBold
    )
}

@Composable
private fun HeroToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .clickable(enabled = enabled) { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(
                text = title,
                color = if (enabled) palette.textPrimary else palette.textSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                color = palette.textSecondary,
                fontSize = 11.sp,
                lineHeight = 14.5.sp
            )
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.fg
            )
        )
    }
}

@Composable
private fun HeroRadioOptionRow(
    title: String,
    badge: String,
    subtitle: String,
    selected: Boolean,
    enabled: Boolean,
    isAddonBadge: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) palette.boxBg else palette.altBg)
            .border(
                width = if (selected) 1.2.dp else 1.dp,
                color = if (selected) palette.fg else palette.border.copy(alpha = 0.25f),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            enabled = enabled,
            onClick = if (enabled) onClick else null,
            colors = RadioButtonDefaults.colors(
                selectedColor = palette.fg,
                unselectedColor = palette.textSecondary
            )
        )
        Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = title,
                    color = if (enabled) palette.textPrimary else palette.textSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(5.dp))
                        .background(if (isAddonBadge) palette.boxBg else palette.cardBg)
                        .border(
                            0.8.dp,
                            if (isAddonBadge) palette.boxBorder.copy(alpha = 0.7f) else palette.border.copy(alpha = 0.4f),
                            RoundedCornerShape(5.dp)
                        )
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = badge,
                        color = if (isAddonBadge) palette.fg else palette.textSecondary,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1
                    )
                }
            }
            Text(
                text = subtitle,
                color = palette.textSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
