package com.personal.movielink.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.AddonDetailedMeta
import com.personal.movielink.addons.AddonEpisodeItem
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddonDetailScreen(
    meta: AddonDetailedMeta?,
    titleHint: String,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onOpenSettings: () -> Unit,
    onWatchFromAddons: (type: String, streamId: String, title: String, subtitle: String, posterUrl: String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val watchFromAddonsActive = settings.nuvioIntegrationEnabled && settings.watchFromAddonsEnabled

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = palette.textPrimary
                )
            }
            Column(modifier = Modifier.weight(1f).padding(end = 6.dp)) {
                Text(
                    text = meta?.title?.ifBlank { titleHint } ?: titleHint.ifBlank { "Addon Details" },
                    color = palette.textPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val sourceLabel = meta?.sourceAddonName?.takeIf { it.isNotBlank() }
                if (sourceLabel != null) {
                    Text(
                        text = "Nuvio Addon · $sourceLabel",
                        color = palette.fg,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onRetry) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "Refresh",
                    tint = palette.textPrimary
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = "Settings",
                    tint = palette.fg
                )
            }
        }

        PullToRefreshBox(
            isRefreshing = isLoading && meta != null,
            onRefresh = onRetry,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isLoading && meta == null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(color = palette.fg)
                            Text(
                                text = "Fetching addon metadata…",
                                color = palette.textSecondary,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                errorMessage != null && meta == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Unable to load metadata",
                                color = palette.textPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = errorMessage,
                                color = palette.textSecondary,
                                fontSize = 13.sp
                            )
                            Button(
                                onClick = onRetry,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.fg,
                                    contentColor = palette.onAccent
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Retry", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                meta != null -> {
                    AddonDetailBody(
                        meta = meta,
                        watchFromAddonsActive = watchFromAddonsActive,
                        imageLoader = imageLoader,
                        onOpenSettings = onOpenSettings,
                        onWatchFromAddons = onWatchFromAddons
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddonDetailBody(
    meta: AddonDetailedMeta,
    watchFromAddonsActive: Boolean,
    imageLoader: ImageLoader,
    onOpenSettings: () -> Unit,
    onWatchFromAddons: (type: String, streamId: String, title: String, subtitle: String, posterUrl: String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current

    val seasons = remember(meta.videos) {
        val raw = meta.videos.map { it.season }.distinct()
        val regular = raw.filter { it > 0 }.sorted()
        val specials = raw.filter { it <= 0 }.sorted()
        regular + specials
    }
    var selectedSeason by remember(meta.id, seasons) {
        mutableStateOf(seasons.firstOrNull())
    }
    var episodeQuery by remember(meta.id) { mutableStateOf("") }

    val filteredEpisodes = remember(meta.videos, selectedSeason, episodeQuery) {
        val q = episodeQuery.trim().lowercase()
        meta.videos.filter { ep ->
            val seasonMatch = selectedSeason == null || ep.season == selectedSeason
            val queryMatch = q.isEmpty() ||
                ep.title.lowercase().contains(q) ||
                ep.overview.lowercase().contains(q) ||
                "e${ep.episode}".contains(q) ||
                "${ep.episode}" == q
            seasonMatch && queryMatch
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Backdrop Banner + Poster + Title Header
        item(key = "header_banner") {
            Box(modifier = Modifier.fillMaxWidth()) {
                val bannerUrl = meta.backdropUrl.ifBlank { meta.posterUrl }
                if (bannerUrl.isNotBlank()) {
                    AsyncImage(
                        model = bannerUrl,
                        imageLoader = imageLoader,
                        contentDescription = meta.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(210.dp)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(170.dp)
                            .background(palette.cardBg)
                    )
                }

                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    palette.pageBg.copy(alpha = 0.2f),
                                    palette.pageBg.copy(alpha = 0.85f),
                                    palette.pageBg
                                )
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomStart)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    AsyncImage(
                        model = meta.posterUrl.ifBlank { meta.backdropUrl },
                        imageLoader = imageLoader,
                        contentDescription = meta.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .width(102.dp)
                            .aspectRatio(2f / 2.85f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.cardBg)
                            .border(1.dp, palette.border.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = meta.title,
                            color = palette.textPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )

                        val summaryMeta = listOfNotNull(
                            meta.type.takeIf { it.isNotBlank() }?.replaceFirstChar { it.uppercase() },
                            meta.releaseYear.takeIf { it.isNotBlank() },
                            meta.rating.takeIf { it.isNotBlank() }?.let { "★ $it" },
                            meta.runtime.takeIf { it.isNotBlank() }
                        ).joinToString(" · ")
                        if (summaryMeta.isNotBlank()) {
                            Text(
                                text = summaryMeta,
                                color = palette.fg,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (meta.status.isNotBlank() || meta.country.isNotBlank()) {
                            Text(
                                text = listOfNotNull(
                                    meta.status.takeIf { it.isNotBlank() },
                                    meta.country.takeIf { it.isNotBlank() }
                                ).joinToString(" · "),
                                color = palette.textSecondary,
                                fontSize = 11.5.sp
                            )
                        }

                        Text(
                            text = if (meta.fromFallbackPreview) {
                                "Preview metadata · Addon did not expose full metadata"
                            } else {
                                "ID: ${meta.id} · ${meta.sourceAddonName}"
                            },
                            color = palette.textSecondary,
                            fontSize = 10.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Genres
        if (meta.genres.isNotEmpty()) {
            item(key = "genres") {
                FlowRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    meta.genres.take(10).forEach { genre ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(palette.cardBg)
                                .border(1.dp, palette.border.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = genre,
                                color = palette.textPrimary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Option B: Watch from Addons CTA
        item(key = "watch_from_addons_cta") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (watchFromAddonsActive) {
                    val primaryEpisode = filteredEpisodes.firstOrNull() ?: meta.videos.firstOrNull()
                    val ctaTitle = if (primaryEpisode != null) {
                        "Watch S${primaryEpisode.season} E${primaryEpisode.episode} from Addons"
                    } else {
                        "Watch from Addons"
                    }
                    val targetStreamId = primaryEpisode?.id ?: meta.id
                    val targetSubtitle = if (primaryEpisode != null) {
                        "S${primaryEpisode.season} E${primaryEpisode.episode} · ${primaryEpisode.title}"
                    } else {
                        listOfNotNull(
                            meta.releaseYear.takeIf { it.isNotBlank() },
                            meta.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
                        ).joinToString(" · ")
                    }

                    val accentLum = ColorUtils.calculateLuminance(palette.accent.toArgb())
                    val buttonBorder = if (!palette.isLightBg && accentLum < 0.06) {
                        BorderStroke(1.2.dp, Color(0xFF3F3F46))
                    } else {
                        null
                    }
                    Button(
                        onClick = {
                            onWatchFromAddons(
                                meta.type,
                                targetStreamId,
                                meta.title,
                                targetSubtitle,
                                meta.posterUrl
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = palette.onPureAccent
                        ),
                        border = buttonBorder,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = ctaTitle,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.cardBg)
                            .border(1.dp, palette.border.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Watch from Addons is OFF in Settings → Search & Streaming.",
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f).padding(end = 10.dp)
                        )
                        OutlinedButton(
                            onClick = onOpenSettings,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Enable", color = palette.fg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Description / Overview
        if (meta.description.isNotBlank()) {
            item(key = "overview") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.cardBg)
                        .border(1.dp, palette.border.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Overview",
                        color = palette.fg,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = meta.description,
                        color = palette.textPrimary,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Series Seasons & Episodes
        if (meta.videos.isNotEmpty()) {
            item(key = "episodes_header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Seasons & Episodes (${meta.videos.size})",
                        color = palette.textPrimary,
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    if (seasons.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(seasons) { s ->
                                val label = if (s <= 0) "Specials" else "Season $s"
                                val active = selectedSeason == s
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(if (active) palette.fg else palette.cardBg)
                                        .border(
                                            1.dp,
                                            if (active) palette.fg else palette.border.copy(alpha = 0.4f),
                                            RoundedCornerShape(20.dp)
                                        )
                                        .clickable { selectedSeason = s }
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (active) palette.onAccent else palette.textPrimary,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (meta.videos.size > 8) {
                        OutlinedTextField(
                            value = episodeQuery,
                            onValueChange = { episodeQuery = it },
                            placeholder = {
                                Text("Filter episodes…", fontSize = 13.sp, color = palette.textSecondary)
                            },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = palette.cardBg,
                                unfocusedContainerColor = palette.cardBg,
                                focusedBorderColor = palette.fg,
                                unfocusedBorderColor = palette.border.copy(alpha = 0.4f),
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            items(
                items = filteredEpisodes,
                key = { ep -> "${ep.season}:${ep.episode}:${ep.id}" }
            ) { ep ->
                AddonEpisodeCard(
                    ep = ep,
                    watchFromAddonsActive = watchFromAddonsActive,
                    imageLoader = imageLoader,
                    onWatchClick = {
                        onWatchFromAddons(
                            meta.type,
                            ep.id,
                            meta.title,
                            "S${ep.season} E${ep.episode} · ${ep.title}",
                            meta.posterUrl
                        )
                    },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // Cast & Director info (if returned by metadata addon)
        if (meta.director.isNotEmpty() || meta.cast.isNotEmpty()) {
            item(key = "credits") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(palette.cardBg)
                        .border(1.dp, palette.border.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (meta.director.isNotEmpty()) {
                        Text(
                            text = "Director: ${meta.director.joinToString(", ")}",
                            color = palette.textPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (meta.cast.isNotEmpty()) {
                        Text(
                            text = "Cast: ${meta.cast.take(10).joinToString(", ")}",
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AddonEpisodeCard(
    ep: AddonEpisodeItem,
    watchFromAddonsActive: Boolean,
    imageLoader: ImageLoader,
    onWatchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .then(if (watchFromAddonsActive) Modifier.clickable(onClick = onWatchClick) else Modifier)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (ep.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = ep.thumbnailUrl,
                    imageLoader = imageLoader,
                    contentDescription = ep.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(104.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.altBg)
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = if (ep.episode > 0) "S${ep.season} E${ep.episode} · ${ep.title}" else ep.title,
                    color = palette.textPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (ep.released.isNotBlank()) {
                    Text(
                        text = ep.released,
                        color = palette.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            if (watchFromAddonsActive) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.fg)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Streams",
                        color = palette.onAccent,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (ep.overview.isNotBlank()) {
            Text(
                text = ep.overview,
                color = palette.textSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
