package com.personal.movielink.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import coil.ImageLoader
import coil.compose.AsyncImage
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.AddonCastMember
import com.personal.movielink.addons.AddonDetailedMeta
import com.personal.movielink.addons.AddonEpisodeItem
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddonDetailScreen(
    meta: AddonDetailedMeta?,
    titleHint: String,
    isLoading: Boolean,
    errorMessage: String?,
    settings: UserSettings,
    imageLoader: ImageLoader,
    isInMyList: Boolean = false,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onToggleMyList: ((AddonDetailedMeta) -> Unit)? = null,
    onOpenSettings: () -> Unit,
    onWatchFromAddons: (type: String, streamId: String, title: String, subtitle: String, posterUrl: String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val watchFromAddonsActive = settings.nuvioIntegrationEnabled && settings.watchFromAddonsEnabled

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        PullToRefreshBox(
            isRefreshing = isLoading && meta != null,
            onRefresh = onRetry,
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isLoading && meta == null -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(color = palette.fg)
                            Text(
                                text = "Fetching addon metadata…",
                                color = palette.textSecondary,
                                fontSize = 13.sp
                            )
                            if (titleHint.isNotBlank()) {
                                Text(
                                    text = titleHint,
                                    color = palette.textPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
                errorMessage != null && meta == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "Unable to load metadata",
                                color = palette.textPrimary,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = errorMessage,
                                color = palette.textSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onRetry,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = palette.fg,
                                    contentColor = palette.onAccent
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Retry", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                meta != null -> {
                    AddonDetailBody(
                        meta = meta,
                        watchFromAddonsActive = watchFromAddonsActive,
                        imageLoader = imageLoader,
                        onOpenSettings = onOpenSettings,
                        onWatchFromAddons = onWatchFromAddons
                    )
                }
            }
        }

        // Overlaid floating translucent circular top bar controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            AddonDetailCircleButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "Back",
                onClick = onBack
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (meta != null && onToggleMyList != null) {
                    AddonDetailCircleButton(
                        icon = if (isInMyList) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (isInMyList) "Remove from My List" else "Add to My List",
                        tint = if (isInMyList) Color(0xFFEF4444) else Color.White,
                        onClick = { onToggleMyList(meta) }
                    )
                }
                AddonDetailCircleButton(
                    icon = Icons.Rounded.Refresh,
                    contentDescription = "Refresh",
                    onClick = onRetry
                )
                AddonDetailCircleButton(
                    icon = Icons.Rounded.Tune,
                    contentDescription = "Settings",
                    tint = palette.fg,
                    onClick = onOpenSettings
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddonDetailBody(
    meta: AddonDetailedMeta,
    watchFromAddonsActive: Boolean,
    imageLoader: ImageLoader,
    onOpenSettings: () -> Unit,
    onWatchFromAddons: (type: String, streamId: String, title: String, subtitle: String, posterUrl: String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var plotExpanded by remember(meta.id) { mutableStateOf(false) }

    val seasons = remember(meta.videos) {
        val raw = meta.videos.map { it.season }.distinct()
        val regular = raw.filter { it > 0 }.sorted()
        val specials = raw.filter { it <= 0 }.sorted()
        regular + specials
    }
    var selectedSeason by remember(meta.id, seasons) {
        mutableStateOf(seasons.firstOrNull())
    }
    var episodeQuery by remember(meta.id) { mutableStateOf("") }

    val filteredEpisodes = remember(meta.videos, selectedSeason, episodeQuery) {
        val q = episodeQuery.trim().lowercase()
        meta.videos.filter { ep ->
            val seasonMatch = selectedSeason == null || ep.season == selectedSeason
            val queryMatch = q.isEmpty() ||
                ep.title.lowercase().contains(q) ||
                ep.overview.lowercase().contains(q) ||
                "e${ep.episode}".contains(q) ||
                "${ep.episode}" == q
            seasonMatch && queryMatch
        }
    }

    val castEntries = remember(meta.castDetails, meta.cast) {
        meta.castDetails.ifEmpty { meta.cast.map { AddonCastMember(name = it) } }
    }

    val primaryEpisode = filteredEpisodes.firstOrNull() ?: meta.videos.firstOrNull()
    val ctaTitle = if (primaryEpisode != null) {
        "Watch S${primaryEpisode.season} E${primaryEpisode.episode} from Addons"
    } else {
        "Watch from Addons"
    }
    val targetStreamId = primaryEpisode?.id ?: meta.id
    val targetSubtitle = if (primaryEpisode != null) {
        "S${primaryEpisode.season} E${primaryEpisode.episode} · ${primaryEpisode.title}"
    } else {
        listOfNotNull(
            meta.releaseYear.takeIf { it.isNotBlank() },
            meta.rating.takeIf { it.isNotBlank() }?.let { "★ $it" }
        ).joinToString(" · ")
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Full-Bleed Backdrop / Poster Hero + Smooth Scrim + Centered Play CTA + Centered Headline
        item(key = "hero_cover") {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                ) {
                    val bannerUrl = meta.backdropUrl.ifBlank { meta.posterUrl }
                    if (bannerUrl.isNotBlank()) {
                        AsyncImage(
                            model = bannerUrl,
                            imageLoader = imageLoader,
                            contentDescription = meta.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(palette.cardBg)
                        )
                    }

                    // Top subtle scrim
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .height(86.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0x99000000), Color.Transparent)
                                )
                            )
                    )

                    // Smooth bottom scrim into pageBg
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(190.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        palette.pageBg.copy(alpha = 0.78f),
                                        palette.pageBg
                                    )
                                )
                            )
                    )

                    // Centered Circular Play CTA matching Reference Image 3
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 14.dp)
                            .size(58.dp)
                            .shadow(12.dp, CircleShape)
                            .clip(CircleShape)
                            .background(Color(0xFFE50914))
                            .clickable {
                                if (watchFromAddonsActive) {
                                    onWatchFromAddons(
                                        meta.type,
                                        targetStreamId,
                                        meta.title,
                                        targetSubtitle,
                                        meta.posterUrl
                                    )
                                } else {
                                    onOpenSettings()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Play",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = meta.title,
                        color = palette.textPrimary,
                        fontSize = 24.sp,
                        lineHeight = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )

                    val primaryGenres = meta.genres.take(2).joinToString(", ")
                    val summaryLine = listOfNotNull(
                        meta.releaseYear.takeIf { it.isNotBlank() },
                        primaryGenres.takeIf { it.isNotBlank() } ?: meta.type.takeIf { it.isNotBlank() }?.replaceFirstChar { it.uppercase() },
                        meta.runtime.takeIf { it.isNotBlank() },
                        meta.videos.takeIf { it.isNotEmpty() }?.let { "${it.size} Episodes" }
                    ).joinToString(" · ")

                    if (summaryLine.isNotBlank()) {
                        Text(
                            text = summaryLine,
                            color = palette.textSecondary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                    }

                    if (meta.rating.isNotBlank() || meta.status.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (meta.rating.isNotBlank()) {
                                Icon(
                                    imageVector = Icons.Rounded.Star,
                                    contentDescription = null,
                                    tint = Color(0xFFFBBF24),
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = meta.rating,
                                    color = palette.textPrimary,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (meta.status.isNotBlank()) {
                                Text(
                                    text = if (meta.rating.isNotBlank()) "· ${meta.status}" else meta.status,
                                    color = palette.textSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    if (meta.externalRatings.isNotEmpty()) {
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            meta.externalRatings.forEach { badge ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(palette.cardBg)
                                        .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "${badge.source} · ${badge.value}",
                                        color = palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    val sourceCaption = if (meta.fromFallbackPreview) {
                        "Preview metadata · Addon did not expose full metadata"
                    } else {
                        listOfNotNull(
                            meta.sourceAddonName.takeIf { it.isNotBlank() },
                            meta.country.takeIf { it.isNotBlank() }
                        ).joinToString(" · ")
                    }
                    if (sourceCaption.isNotBlank()) {
                        Text(
                            text = sourceCaption,
                            color = palette.fg,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // Watch from Addons CTA / Enable Prompt
        item(key = "watch_from_addons_cta") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (watchFromAddonsActive) {
                    val accentLum = ColorUtils.calculateLuminance(palette.accent.toArgb())
                    val buttonBorder = if (!palette.isLightBg && accentLum < 0.06) {
                        BorderStroke(1.2.dp, Color(0xFF3F3F46))
                    } else {
                        null
                    }
                    Button(
                        onClick = {
                            onWatchFromAddons(
                                meta.type,
                                targetStreamId,
                                meta.title,
                                targetSubtitle,
                                meta.posterUrl
                            )
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = palette.accent,
                            contentColor = palette.onPureAccent
                        ),
                        border = buttonBorder,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = ctaTitle,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.cardBg)
                            .border(1.dp, palette.border.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Watch from Addons is OFF in Settings → Search & Streaming.",
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f).padding(end = 10.dp)
                        )
                        OutlinedButton(
                            onClick = onOpenSettings,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Enable", color = palette.fg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Genres Chips
        if (meta.genres.isNotEmpty()) {
            item(key = "genres") {
                FlowRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    meta.genres.take(10).forEach { genre ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(palette.cardBg)
                                .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(50))
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = genre,
                                color = palette.textPrimary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // The Plot (Expandable Synopsis matching Reference Image 3)
        if (meta.description.isNotBlank()) {
            item(key = "the_plot") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "The Plot",
                        color = palette.textPrimary,
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = meta.description,
                        color = palette.textSecondary,
                        fontSize = 13.5.sp,
                        lineHeight = 20.sp,
                        maxLines = if (plotExpanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (meta.description.length > 135) {
                        Text(
                            text = if (plotExpanded) "Show Less" else "Read More",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFEF4444),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { plotExpanded = !plotExpanded }
                                .padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Casts (Circular Avatars Carousel matching Reference Image 3)
        if (castEntries.isNotEmpty() || meta.director.isNotEmpty()) {
            item(key = "casts") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Casts",
                            color = palette.textPrimary,
                            fontSize = 15.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (meta.director.isNotEmpty()) {
                            Text(
                                text = "Dir: ${meta.director.first()}",
                                color = palette.textSecondary,
                                fontSize = 11.5.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    if (castEntries.isNotEmpty()) {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(castEntries.take(18)) { actor ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.width(68.dp)
                                ) {
                                    if (actor.avatarUrl.isNotBlank()) {
                                        AsyncImage(
                                            model = actor.avatarUrl,
                                            imageLoader = imageLoader,
                                            contentDescription = actor.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(60.dp)
                                                .clip(CircleShape)
                                                .background(palette.cardBg)
                                                .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(60.dp)
                                                .clip(CircleShape)
                                                .background(palette.altBg)
                                                .border(1.dp, palette.border.copy(alpha = 0.25f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            val initials = actor.name
                                                .split(' ')
                                                .filter { it.isNotBlank() }
                                                .take(2)
                                                .joinToString("") { it.take(1).uppercase() }
                                            Text(
                                                text = initials.ifBlank { "?" },
                                                color = palette.fg,
                                                fontSize = 17.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = actor.name,
                                        color = palette.textPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 2,
                                        lineHeight = 14.sp,
                                        textAlign = TextAlign.Center,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Episodes
        if (meta.videos.isNotEmpty()) {
            item(key = "episodes_header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Episodes (${meta.videos.size})",
                        color = palette.textPrimary,
                        fontSize = 15.5.sp,
                        fontWeight = FontWeight.Bold
                    )

                    if (seasons.size > 1) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(seasons) { s ->
                                val label = if (s <= 0) "Specials" else "Season $s"
                                val active = selectedSeason == s
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(if (active) palette.fg else palette.cardBg)
                                        .border(
                                            1.dp,
                                            if (active) palette.fg else palette.border.copy(alpha = 0.4f),
                                            RoundedCornerShape(20.dp)
                                        )
                                        .clickable { selectedSeason = s }
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (active) palette.onAccent else palette.textPrimary,
                                        fontSize = 12.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    if (meta.videos.size > 8) {
                        OutlinedTextField(
                            value = episodeQuery,
                            onValueChange = { episodeQuery = it },
                            placeholder = {
                                Text("Filter episodes…", fontSize = 13.sp, color = palette.textSecondary)
                            },
                            leadingIcon = {
                                Icon(Icons.Rounded.Search, contentDescription = null, tint = palette.fg)
                            },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = palette.cardBg,
                                unfocusedContainerColor = palette.cardBg,
                                focusedBorderColor = palette.fg,
                                unfocusedBorderColor = palette.border.copy(alpha = 0.4f),
                                focusedTextColor = palette.textPrimary,
                                unfocusedTextColor = palette.textPrimary
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            items(
                items = filteredEpisodes,
                key = { ep -> "${ep.season}:${ep.episode}:${ep.id}" }
            ) { ep ->
                AddonEpisodeCard(
                    ep = ep,
                    watchFromAddonsActive = watchFromAddonsActive,
                    imageLoader = imageLoader,
                    onWatchClick = {
                        onWatchFromAddons(
                            meta.type,
                            ep.id,
                            meta.title,
                            "S${ep.season} E${ep.episode} · ${ep.title}",
                            meta.posterUrl
                        )
                    },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }
    }
}

@Composable
private fun AddonDetailCircleButton(
    icon: ImageVector,
    contentDescription: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color(0x9916161C))
            .border(1.dp, Color(0x2EFFFFFF), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun AddonEpisodeCard(
    ep: AddonEpisodeItem,
    watchFromAddonsActive: Boolean,
    imageLoader: ImageLoader,
    onWatchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalMovieLinkPalette.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.cardBg)
            .border(1.dp, palette.border.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .then(if (watchFromAddonsActive) Modifier.clickable(onClick = onWatchClick) else Modifier)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (ep.thumbnailUrl.isNotBlank()) {
                AsyncImage(
                    model = ep.thumbnailUrl,
                    imageLoader = imageLoader,
                    contentDescription = ep.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .width(104.dp)
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.altBg)
                )
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = if (ep.episode > 0) "S${ep.season} E${ep.episode} · ${ep.title}" else ep.title,
                    color = palette.textPrimary,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (ep.released.isNotBlank()) {
                    Text(
                        text = ep.released,
                        color = palette.textSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            if (watchFromAddonsActive) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(palette.fg)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Streams",
                        color = palette.onAccent,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        if (ep.overview.isNotBlank()) {
            Text(
                text = ep.overview,
                color = palette.textSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
