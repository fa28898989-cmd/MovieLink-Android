package com.personal.movielink.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.ContentProviderKind
import com.personal.movielink.addons.UnifiedPosterItem
import com.personal.movielink.ui.theme.LocalMovieLinkPalette

@Composable
fun AddonCatalogGridScreen(
    title: String,
    addonName: String,
    items: List<UnifiedPosterItem>,
    isLoading: Boolean,
    hasMore: Boolean,
    errorMessage: String?,
    imageLoader: ImageLoader,
    settings: UserSettings? = null,
    isPosterInMyList: ((UnifiedPosterItem) -> Boolean)? = null,
    onTogglePosterMyList: ((UnifiedPosterItem) -> Boolean)? = null,
    onQuickAddonStreams: ((UnifiedPosterItem) -> Unit)? = null,
    onBack: () -> Unit,
    onRetry: () -> Unit,
    onLoadMore: () -> Unit,
    onOpenPoster: (UnifiedPosterItem) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var contextMenuPoster by remember { mutableStateOf<UnifiedPosterItem?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.pageBg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = palette.textPrimary
                )
            }
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                Text(
                    text = title,
                    color = palette.textPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (addonName.isNotBlank()) {
                    Text(
                        text = "Nuvio Addon · $addonName",
                        color = palette.fg,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onRetry) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "Refresh",
                    tint = palette.textPrimary
                )
            }
        }

        when {
            isLoading && items.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = palette.fg)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "Loading addon catalog…",
                            color = palette.textSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
            errorMessage != null && items.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Could not load addon catalog",
                            color = palette.textPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = errorMessage,
                            color = palette.textSecondary,
                            fontSize = 12.5.sp
                        )
                        Button(
                            onClick = onRetry,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.fg,
                                contentColor = palette.onAccent
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Retry", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            items.isEmpty() -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No titles returned by this addon catalog.", color = palette.textSecondary)
                }
            }
            else -> {
                val rows = items.chunked(2)
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(rows) { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowItems.forEach { poster ->
                                MediaPosterCard(
                                    card = poster.toMediaCard(),
                                    imageLoader = imageLoader,
                                    onClick = { onOpenPoster(poster) },
                                    onLongClick = { contextMenuPoster = poster },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (rowItems.size == 1) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }

                    if (hasMore) {
                        item {
                            OutlinedButton(
                                enabled = !isLoading,
                                onClick = onLoadMore,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        color = palette.fg,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else {
                                    Text("Load More", color = palette.fg, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    contextMenuPoster?.let { poster ->
        PosterContextMenuDialog(
            poster = poster,
            inMyList = isPosterInMyList?.invoke(poster) == true,
            canQuickAddonStreams = settings?.nuvioIntegrationEnabled == true &&
                settings.watchFromAddonsEnabled &&
                poster.provider == ContentProviderKind.STREMIO_ADDON &&
                !poster.stremioId.isNullOrBlank() &&
                onQuickAddonStreams != null,
            imageLoader = imageLoader,
            onOpenDetails = {
                contextMenuPoster = null
                onOpenPoster(poster)
            },
            onToggleMyList = {
                onTogglePosterMyList?.invoke(poster)
                contextMenuPoster = null
            },
            onQuickAddonStreams = {
                contextMenuPoster = null
                onQuickAddonStreams?.invoke(poster)
            },
            onDismiss = { contextMenuPoster = null }
        )
    }
}
