package com.personal.movielink

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.personal.movielink.addons.AddonCatalogDescriptor
import com.personal.movielink.addons.AddonCatalogPage
import com.personal.movielink.addons.AddonCatalogRepository
import com.personal.movielink.addons.AddonCatalogSearchGroup
import com.personal.movielink.addons.AddonDetailedMeta
import com.personal.movielink.addons.AddonManager
import com.personal.movielink.addons.AddonMetadataRepository
import com.personal.movielink.addons.AddonStreamGroupResult
import com.personal.movielink.addons.AddonStreamRepository
import com.personal.movielink.addons.ContentProviderKind
import com.personal.movielink.addons.InstalledAddon
import com.personal.movielink.addons.StremioCatalogSpec
import com.personal.movielink.addons.UnifiedHomeCatalogEntry
import com.personal.movielink.addons.UnifiedHomeCatalogManager
import com.personal.movielink.addons.UnifiedPosterItem
import com.personal.movielink.addons.UnifiedSearchRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface NavScreen {
    data class Catalog(val url: String) : NavScreen
    data class Detail(val url: String) : NavScreen
    data class AddonCatalogGrid(
        val entryKey: String,
        val addonManifestUrl: String,
        val catalogType: String,
        val catalogId: String,
        val title: String
    ) : NavScreen
    data class AddonDetail(
        val type: String,
        val id: String,
        val addonManifestUrl: String? = null,
        val addonNameHint: String? = null,
        val titleHint: String = "",
        val posterHint: String = "",
        val backdropHint: String = "",
        val yearHint: String = "",
        val ratingHint: String = "",
        val descriptionHint: String = "",
        val genresHint: List<String> = emptyList(),
        val logoHint: String = ""
    ) : NavScreen
    data class AddonSources(
        val contentType: String,
        val streamId: String,
        val title: String,
        val subtitle: String,
        val posterUrl: String
    ) : NavScreen
}

data class AddonDetailUiState(
    val meta: AddonDetailedMeta? = null,
    val isLoading: Boolean = false,
    val error: String? = null
)

data class AddonSourcesUiState(
    val contentType: String = "",
    val streamId: String = "",
    val title: String = "",
    val subtitle: String = "",
    val posterUrl: String = "",
    val groupResults: List<AddonStreamGroupResult> = emptyList(),
    val isLoadingAny: Boolean = false
)

data class AddonHomeRowData(
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val hasMore: Boolean = false
)

data class CombinedHomeSectionState(
    val key: String,
    val provider: ContentProviderKind,
    val title: String,
    val addonName: String? = null,
    val addonManifestUrl: String? = null,
    val catalogType: String? = null,
    val catalogId: String? = null,
    val items: List<UnifiedPosterItem> = emptyList(),
    val moreUrl: String? = null,
    val hasAddonViewAll: Boolean = false,
    val isLoading: Boolean = false,
    val error: String? = null
)

data class AddonGridState(
    val title: String = "",
    val addonName: String = "",
    val addonManifestUrl: String = "",
    val catalogType: String = "",
    val catalogId: String = "",
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val hasMore: Boolean = false,
    val nextSkip: Int = 0,
    val error: String? = null
)

data class HeroSourceOption(
    val key: String,
    val provider: ContentProviderKind,
    val title: String,
    val providerLabel: String,
    val isAvailable: Boolean = true
)

data class HeroSectionState(
    val items: List<UnifiedPosterItem> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val activeSourceTitle: String? = null,
    val hidden: Boolean = false
)

data class MovieLinkSearchSectionState(
    val items: List<UnifiedPosterItem> = emptyList(),
    val nextPageUrl: String? = null,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val error: String? = null
)

data class AddonSearchSectionState(
    val groups: List<AddonCatalogSearchGroup> = emptyList(),
    val noSearchableAddons: Boolean = false
)

data class UnifiedSearchState(
    val query: String = "",
    val hasSearched: Boolean = false,
    val movieLink: MovieLinkSearchSectionState = MovieLinkSearchSectionState(),
    val addons: AddonSearchSectionState = AddonSearchSectionState()
)

data class PendingVideoChoice(
    val url: String,
    val title: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

data class PendingDownloaderChoice(
    val url: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

data class FallbackWebRequest(
    val url: String,
    val title: String,
    val isCloudflareChallenge: Boolean = false,
    val retryTargetUrl: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val settingsStore = AppSettingsStore(application)
    val addonManager = AddonManager(application)
    val addonCatalogRepository = AddonCatalogRepository()
    val addonMetadataRepository = AddonMetadataRepository()
    val addonStreamRepository = AddonStreamRepository()
    val unifiedSearchRepository = UnifiedSearchRepository(addonCatalogRepository)
    val unifiedHomeCatalogManager = UnifiedHomeCatalogManager(application)
    val imageLoader = MovieLinkNetwork.buildImageLoader(application)
    val httpClient = MovieLinkNetwork.buildHttpClient { settingsStore.settings.value }
    private val repository = MovieLinkRepository(httpClient) { settingsStore.settings.value }

    val settings: StateFlow<UserSettings> = settingsStore.settings
    val addons: StateFlow<List<InstalledAddon>> = addonManager.addons
    val addonsBusy: StateFlow<Boolean> = addonManager.isBusy
    val unifiedHomeCatalogs: StateFlow<List<UnifiedHomeCatalogEntry>> = unifiedHomeCatalogManager.entries
    val history: StateFlow<List<HistoryItem>> = settingsStore.history
    val myList: StateFlow<List<MyListItem>> = settingsStore.myList
    val sessionBlockedCount: StateFlow<Int> = AdBlocker.sessionBlockedCount
    private var latestMovieLinkHomeSections: List<CatalogSection>? = null

    private val _backStack = MutableStateFlow<List<NavScreen>>(emptyList())
    val backStack: StateFlow<List<NavScreen>> = _backStack.asStateFlow()

    private val _catalog = MutableStateFlow<CatalogPage?>(null)
    val catalog: StateFlow<CatalogPage?> = _catalog.asStateFlow()

    private val _catalogLoading = MutableStateFlow(false)
    val catalogLoading: StateFlow<Boolean> = _catalogLoading.asStateFlow()

    private val _catalogError = MutableStateFlow<String?>(null)
    val catalogError: StateFlow<String?> = _catalogError.asStateFlow()

    private val _detail = MutableStateFlow<MediaDetail?>(null)
    val detail: StateFlow<MediaDetail?> = _detail.asStateFlow()

    private val _detailLoading = MutableStateFlow(false)
    val detailLoading: StateFlow<Boolean> = _detailLoading.asStateFlow()

    private val _detailError = MutableStateFlow<String?>(null)
    val detailError: StateFlow<String?> = _detailError.asStateFlow()

    private val _playerRequest = MutableStateFlow<PlayerLaunchRequest?>(null)
    val playerRequest: StateFlow<PlayerLaunchRequest?> = _playerRequest.asStateFlow()

    private val _fallbackWeb = MutableStateFlow<FallbackWebRequest?>(null)
    val fallbackWeb: StateFlow<FallbackWebRequest?> = _fallbackWeb.asStateFlow()

    private val _trailerId = MutableStateFlow<Pair<String, String>?>(null)
    val trailerId: StateFlow<Pair<String, String>?> = _trailerId.asStateFlow()

    private val _pendingVideoChoice = MutableStateFlow<PendingVideoChoice?>(null)
    val pendingVideoChoice: StateFlow<PendingVideoChoice?> = _pendingVideoChoice.asStateFlow()

    private val _pendingDownloaderChoice = MutableStateFlow<PendingDownloaderChoice?>(null)
    val pendingDownloaderChoice: StateFlow<PendingDownloaderChoice?> = _pendingDownloaderChoice.asStateFlow()

    private val _addonHomeRows = MutableStateFlow<Map<String, AddonHomeRowData>>(emptyMap())
    private val inFlightAddonCatalogKeys = HashSet<String>()

    private val _heroAddonRows = MutableStateFlow<Map<String, AddonHomeRowData>>(emptyMap())
    private val inFlightHeroKeys = HashSet<String>()

    private val _addonGridState = MutableStateFlow<AddonGridState?>(null)
    val addonGridState: StateFlow<AddonGridState?> = _addonGridState.asStateFlow()

    private val _addonDetailState = MutableStateFlow(AddonDetailUiState())
    val addonDetailState: StateFlow<AddonDetailUiState> = _addonDetailState.asStateFlow()

    private val _addonSourcesState = MutableStateFlow(AddonSourcesUiState())
    val addonSourcesState: StateFlow<AddonSourcesUiState> = _addonSourcesState.asStateFlow()

    private val _unifiedSearch = MutableStateFlow(UnifiedSearchState())
    val unifiedSearch: StateFlow<UnifiedSearchState> = _unifiedSearch.asStateFlow()
    private var activeSearchJob: Job? = null

    val availableHeroSources: StateFlow<List<HeroSourceOption>> = combine(
        _catalog,
        addons
    ) { page, addonList ->
        val mlTitles = if (page != null && !page.isSearchOrGrid && isHomePageUrl(page.url) && page.sections.isNotEmpty()) {
            page.sections.map { it.title.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }
        } else {
            UnifiedHomeCatalogManager.DEFAULT_MOVIELINK_SECTIONS
        }
        val mlOptions = mlTitles.map { title ->
            HeroSourceOption(
                key = UnifiedHomeCatalogManager.movieLinkKey(title),
                provider = ContentProviderKind.MOVIELINK_BD,
                title = title,
                providerLabel = "MovieLinkBD",
                isAvailable = true
            )
        }
        val addonOptions = addonCatalogRepository.availableHomeCatalogs(addonList).map { desc ->
            HeroSourceOption(
                key = UnifiedHomeCatalogManager.addonKey(desc.addon.manifestUrl, desc.catalog.type, desc.catalog.id),
                provider = ContentProviderKind.STREMIO_ADDON,
                title = desc.catalog.name,
                providerLabel = "Nuvio · ${desc.addon.manifest.name}",
                isAvailable = true
            )
        }
        mlOptions + addonOptions
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val heroState: StateFlow<HeroSectionState> = combine(
        _catalog,
        settings,
        addons,
        _heroAddonRows
    ) { page, userSettings, addonList, heroRowsMap ->
        val nuvioHeroOn = userSettings.nuvioIntegrationEnabled && userSettings.nuvioHeroEnabled
        val mlHeroOn = userSettings.movieLinkHeroEnabled
        if (!mlHeroOn && !nuvioHeroOn) {
            return@combine HeroSectionState(hidden = true)
        }
        val selectedKey = userSettings.heroSourceKey?.takeIf { it.isNotBlank() }

        when {
            selectedKey != null && selectedKey.startsWith("addon:") -> {
                if (!nuvioHeroOn) {
                    HeroSectionState(hidden = true)
                } else {
                    val parts = selectedKey.removePrefix("addon:").split("|")
                    val manifestUrl = parts.getOrNull(0).orEmpty()
                    val catType = parts.getOrNull(1).orEmpty()
                    val catId = parts.getOrNull(2).orEmpty()
                    val addon = addonList.firstOrNull { it.enabled && it.manifestUrl == manifestUrl }
                    val spec = addon?.manifest?.catalogs?.firstOrNull {
                        it.type.equals(catType, ignoreCase = true) && it.id.equals(catId, ignoreCase = true)
                    }
                    if (addon == null || spec == null) {
                        HeroSectionState(hidden = true)
                    } else {
                        val cached = heroRowsMap[selectedKey]
                        val items = cached?.items.orEmpty()
                            .filter { it.posterUrl.isNotBlank() }
                            .take(8)
                        HeroSectionState(
                            items = items,
                            isLoading = cached?.isLoading ?: true,
                            error = cached?.error,
                            activeSourceTitle = "${addon.manifest.name} · ${spec.name}",
                            hidden = false
                        )
                    }
                }
            }
            selectedKey != null && selectedKey.startsWith("ml:") -> {
                if (!mlHeroOn) {
                    HeroSectionState(hidden = true)
                } else if (page == null || page.isSearchOrGrid || !isHomePageUrl(page.url)) {
                    HeroSectionState(hidden = true)
                } else {
                    val targetTitle = selectedKey.removePrefix("ml:").trim().lowercase()
                    val sec = page.sections.firstOrNull { it.title.trim().lowercase() == targetTitle }
                    val items = sec?.items.orEmpty()
                        .filter { it.posterUrl.isNotBlank() }
                        .distinctBy { it.url }
                        .take(8)
                        .map { UnifiedPosterItem.fromMovieLink(it) }
                    HeroSectionState(
                        items = items,
                        activeSourceTitle = sec?.title,
                        hidden = items.isEmpty()
                    )
                }
            }
            else -> {
                // Auto default: preserve existing MovieLinkBD Home hero prioritization
                if (!mlHeroOn || page == null || page.isSearchOrGrid || !isHomePageUrl(page.url)) {
                    HeroSectionState(hidden = true)
                } else {
                    val movieSectionItems = page.sections
                        .filter {
                            it.title.equals("Movies", ignoreCase = true) ||
                                (it.title.contains("Movie", ignoreCase = true) &&
                                    !it.title.contains("Recently", ignoreCase = true))
                        }
                        .flatMap { it.items }
                    val otherMovieItems = page.sections
                        .filterNot {
                            it.title.contains("Recently Updated", ignoreCase = true) ||
                                it.title.contains("Recently Uploaded", ignoreCase = true)
                        }
                        .flatMap { it.items }
                        .filter { it.url.contains("/movie/", ignoreCase = true) }
                    val nonRecentFallback = page.sections
                        .filterNot {
                            it.title.contains("Recently Updated", ignoreCase = true) ||
                                it.title.contains("Recently Uploaded", ignoreCase = true)
                        }
                        .flatMap { it.items }
                    val prioritized = (movieSectionItems + otherMovieItems).ifEmpty {
                        nonRecentFallback.ifEmpty { page.sections.flatMap { it.items } }
                    }
                    val items = prioritized
                        .filter { it.posterUrl.isNotBlank() }
                        .distinctBy { it.url }
                        .take(6)
                        .map { UnifiedPosterItem.fromMovieLink(it) }
                    HeroSectionState(
                        items = items,
                        activeSourceTitle = "MovieLinkBD Auto",
                        hidden = items.isEmpty()
                    )
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, HeroSectionState())

    val combinedHomeSections: StateFlow<List<CombinedHomeSectionState>> = combine(
        _catalog,
        settings,
        unifiedHomeCatalogs,
        _addonHomeRows
    ) { page, userSettings, entries, addonRowsMap ->
        if (page == null || page.isSearchOrGrid || !isHomePageUrl(page.url)) {
            emptyList()
        } else {
            val mlSectionByLower = page.sections.associateBy { it.title.trim().lowercase() }
            if (entries.isEmpty()) {
                page.sections.map { sec ->
                    CombinedHomeSectionState(
                        key = UnifiedHomeCatalogManager.movieLinkKey(sec.title),
                        provider = ContentProviderKind.MOVIELINK_BD,
                        title = sec.title,
                        items = sec.items.map { UnifiedPosterItem.fromMovieLink(it) },
                        moreUrl = sec.moreUrl
                    )
                }
            } else {
                val showNuvio = userSettings.nuvioIntegrationEnabled && userSettings.nuvioHomeCatalogsEnabled
                entries.mapNotNull { entry ->
                    if (!entry.enabled || !entry.isAvailable) return@mapNotNull null
                    when (entry.provider) {
                        ContentProviderKind.MOVIELINK_BD -> {
                            val secTitle = (entry.movieLinkSectionTitle ?: entry.title).trim().lowercase()
                            val matched = mlSectionByLower[secTitle] ?: return@mapNotNull null
                            CombinedHomeSectionState(
                                key = entry.key,
                                provider = ContentProviderKind.MOVIELINK_BD,
                                title = matched.title,
                                items = matched.items.map { UnifiedPosterItem.fromMovieLink(it) },
                                moreUrl = matched.moreUrl
                            )
                        }
                        ContentProviderKind.STREMIO_ADDON -> {
                            if (!showNuvio) return@mapNotNull null
                            val rowState = addonRowsMap[entry.key] ?: AddonHomeRowData(isLoading = true)
                            CombinedHomeSectionState(
                                key = entry.key,
                                provider = ContentProviderKind.STREMIO_ADDON,
                                title = entry.title,
                                addonName = entry.addonName,
                                addonManifestUrl = entry.addonManifestUrl,
                                catalogType = entry.addonCatalogType,
                                catalogId = entry.addonCatalogId,
                                items = rowState.items,
                                hasAddonViewAll = rowState.items.isNotEmpty(),
                                isLoading = rowState.isLoading,
                                error = rowState.error
                            )
                        }
                    }
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        unifiedHomeCatalogManager.syncSources(null, addons.value)
        val startUrl = settingsStore.startupUrl()
        if (isDetailUrl(startUrl)) {
            _backStack.value = listOf(
                NavScreen.Catalog(settings.value.mirrorUrl),
                NavScreen.Detail(startUrl)
            )
            loadCatalog(settings.value.mirrorUrl, recordVisit = false)
            loadDetail(startUrl)
        } else {
            _backStack.value = listOf(NavScreen.Catalog(startUrl))
            loadCatalog(startUrl, recordVisit = true)
        }

        viewModelScope.launch {
            combine(settings, unifiedHomeCatalogs, addons) { s, list, _ ->
                Triple(s.nuvioIntegrationEnabled, s.nuvioHomeCatalogsEnabled, list)
            }.collect { (nuvioOn, homeOn, _) ->
                if (nuvioOn && homeOn) {
                    refreshEnabledAddonHomeSections(forceRefresh = false)
                }
            }
        }

        viewModelScope.launch {
            combine(settings, addons) { s, _ ->
                Triple(s.nuvioIntegrationEnabled, s.nuvioHeroEnabled, s.heroSourceKey)
            }.collect { (nuvioOn, heroOn, heroKey) ->
                if (nuvioOn && heroOn && heroKey != null && heroKey.startsWith("addon:")) {
                    refreshHeroAddonSource(forceRefresh = false)
                }
            }
        }
    }

    fun currentUrl(): String {
        return when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> top.url
            is NavScreen.Catalog -> top.url
            is NavScreen.AddonCatalogGrid, is NavScreen.AddonDetail, is NavScreen.AddonSources, null -> settings.value.mirrorUrl
        }
    }

    fun isDetailUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("/movie/") ||
            lower.contains("/series/") ||
            lower.contains("/drama/") ||
            lower.contains("/anime/")
    }

    fun openCatalogUrl(url: String) {
        val normalized = Config.normalizeUrl(url)
        _backStack.value = listOf(NavScreen.Catalog(normalized))
        loadCatalog(normalized, recordVisit = true)
    }

    fun searchCatalog(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        val currentSearch = _unifiedSearch.value
        val currentlyBusy = currentSearch.movieLink.isLoading ||
            currentSearch.addons.groups.any { it.isLoading }
        if (currentSearch.hasSearched && currentSearch.query == trimmed && currentlyBusy) {
            return
        }

        activeSearchJob?.cancel()
        val s = settings.value
        val runMl = s.movieLinkSearchEnabled
        val runAddons = s.nuvioIntegrationEnabled && s.nuvioSearchEnabled
        val searchableCatalogs = if (runAddons) {
            unifiedSearchRepository.discoverSearchableCatalogs(addons.value)
        } else {
            emptyList()
        }

        val initialGroups = searchableCatalogs.map { desc ->
            AddonCatalogSearchGroup(
                key = desc.catalogKey,
                addon = desc.addon,
                catalog = desc.catalog,
                isLoading = true
            )
        }

        _unifiedSearch.value = UnifiedSearchState(
            query = trimmed,
            hasSearched = true,
            movieLink = MovieLinkSearchSectionState(isLoading = runMl),
            addons = AddonSearchSectionState(
                groups = initialGroups,
                noSearchableAddons = runAddons && searchableCatalogs.isEmpty()
            )
        )

        if (!runMl && searchableCatalogs.isEmpty()) return

        activeSearchJob = viewModelScope.launch {
            if (runMl) {
                launch {
                    executeMovieLinkSearch(trimmed)
                }
            }
            if (runAddons) {
                for (desc in searchableCatalogs) {
                    launch {
                        val res = unifiedSearchRepository.searchAddonCatalog(desc, trimmed, skip = 0)
                        _unifiedSearch.update { state ->
                            val nextGroups = state.addons.groups.map { grp ->
                                if (grp.key != desc.catalogKey) {
                                    grp
                                } else {
                                    res.fold(
                                        onSuccess = { page ->
                                            grp.copy(
                                                items = page.items,
                                                isLoading = false,
                                                hasMore = page.hasMore,
                                                nextSkip = page.nextSkip,
                                                error = null
                                            )
                                        },
                                        onFailure = { err ->
                                            grp.copy(
                                                isLoading = false,
                                                error = err.message ?: "Addon search failed"
                                            )
                                        }
                                    )
                                }
                            }
                            state.copy(addons = state.addons.copy(groups = nextGroups))
                        }
                    }
                }
            }
        }
    }

    private suspend fun executeMovieLinkSearch(query: String) {
        try {
            val page = repository.searchCatalog(query)
            val items = page.sections
                .flatMap { it.items }
                .distinctBy { it.url }
                .map { UnifiedPosterItem.fromMovieLink(it) }
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = MovieLinkSearchSectionState(
                        items = items,
                        nextPageUrl = page.nextPageUrl,
                        isLoading = false,
                        error = null
                    )
                )
            }
            settingsStore.recordHistory(page.pageTitle, page.url)
        } catch (cf: CloudflareRequiredException) {
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = state.movieLink.copy(
                        isLoading = false,
                        error = "Cloudflare verification required"
                    )
                )
            }
            _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
        } catch (e: Exception) {
            _unifiedSearch.update { state ->
                state.copy(
                    movieLink = state.movieLink.copy(
                        isLoading = false,
                        error = e.message ?: "Unable to search MovieLinkBD"
                    )
                )
            }
        }
    }

    fun clearUnifiedSearch() {
        activeSearchJob?.cancel()
        _unifiedSearch.value = UnifiedSearchState()
    }

    fun retryMovieLinkSearch() {
        val q = _unifiedSearch.value.query.trim()
        if (q.isEmpty() || !settings.value.movieLinkSearchEnabled) return
        _unifiedSearch.update { state ->
            state.copy(movieLink = state.movieLink.copy(isLoading = true, error = null))
        }
        viewModelScope.launch {
            executeMovieLinkSearch(q)
        }
    }

    fun loadMoreMovieLinkSearch() {
        val ml = _unifiedSearch.value.movieLink
        val nextUrl = ml.nextPageUrl ?: return
        if (ml.isLoading || ml.isLoadingMore) return
        _unifiedSearch.update { state ->
            state.copy(movieLink = state.movieLink.copy(isLoadingMore = true, error = null))
        }
        viewModelScope.launch {
            try {
                val page = repository.fetchCatalogPage(nextUrl)
                val nextItems = page.sections.flatMap { it.items }.map { UnifiedPosterItem.fromMovieLink(it) }
                _unifiedSearch.update { state ->
                    val merged = (state.movieLink.items + nextItems).distinctBy { it.stableKey }
                    state.copy(
                        movieLink = state.movieLink.copy(
                            items = merged,
                            nextPageUrl = page.nextPageUrl,
                            isLoadingMore = false,
                            error = null
                        )
                    )
                }
            } catch (cf: CloudflareRequiredException) {
                _unifiedSearch.update { state ->
                    state.copy(movieLink = state.movieLink.copy(isLoadingMore = false, error = "Cloudflare verification required"))
                }
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _unifiedSearch.update { state ->
                    state.copy(movieLink = state.movieLink.copy(isLoadingMore = false, error = e.message ?: "Failed to load more results"))
                }
            }
        }
    }

    fun retryAddonSearchGroup(groupKey: String) {
        val state = _unifiedSearch.value
        val q = state.query.trim()
        val group = state.addons.groups.firstOrNull { it.key == groupKey } ?: return
        if (q.isEmpty() || group.isLoading) return

        _unifiedSearch.update { curr ->
            val updated = curr.addons.groups.map {
                if (it.key == groupKey) it.copy(isLoading = true, error = null) else it
            }
            curr.copy(addons = curr.addons.copy(groups = updated))
        }
        viewModelScope.launch {
            val res = unifiedSearchRepository.searchAddonCatalog(
                AddonCatalogDescriptor(group.addon, group.catalog),
                query = q,
                skip = 0,
                forceRefresh = true
            )
            _unifiedSearch.update { curr ->
                val updated = curr.addons.groups.map {
                    if (it.key != groupKey) it else res.fold(
                        onSuccess = { p ->
                            it.copy(items = p.items, isLoading = false, hasMore = p.hasMore, nextSkip = p.nextSkip, error = null)
                        },
                        onFailure = { e ->
                            it.copy(isLoading = false, error = e.message ?: "Addon search failed")
                        }
                    )
                }
                curr.copy(addons = curr.addons.copy(groups = updated))
            }
        }
    }

    fun loadMoreAddonSearchGroup(groupKey: String) {
        val state = _unifiedSearch.value
        val q = state.query.trim()
        val group = state.addons.groups.firstOrNull { it.key == groupKey } ?: return
        if (q.isEmpty() || group.isLoading || group.isLoadingMore || !group.hasMore) return

        _unifiedSearch.update { curr ->
            val updated = curr.addons.groups.map {
                if (it.key == groupKey) it.copy(isLoadingMore = true, error = null) else it
            }
            curr.copy(addons = curr.addons.copy(groups = updated))
        }
        viewModelScope.launch {
            val res = unifiedSearchRepository.searchAddonCatalog(
                AddonCatalogDescriptor(group.addon, group.catalog),
                query = q,
                skip = group.nextSkip
            )
            _unifiedSearch.update { curr ->
                val updated = curr.addons.groups.map {
                    if (it.key != groupKey) it else res.fold(
                        onSuccess = { p ->
                            val merged = (it.items + p.items).distinctBy { item -> item.stableKey }
                            it.copy(
                                items = merged,
                                isLoadingMore = false,
                                hasMore = p.hasMore && p.items.isNotEmpty(),
                                nextSkip = p.nextSkip,
                                error = null
                            )
                        },
                        onFailure = { e ->
                            it.copy(isLoadingMore = false, error = e.message ?: "Failed to load more")
                        }
                    )
                }
                curr.copy(addons = curr.addons.copy(groups = updated))
            }
        }
    }

    fun openDetailUrl(url: String, titleHint: String? = null, posterHint: String = "") {
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + NavScreen.Detail(url)
        _detail.value = null
        loadDetail(url, titleHint, posterHint)
    }

    fun openUrlSmart(url: String, titleHint: String? = null, posterHint: String = "") {
        if (isDetailUrl(url)) {
            openDetailUrl(url, titleHint, posterHint)
        } else {
            openCatalogUrl(url)
        }
    }

    fun refreshCurrent() {
        when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> loadDetail(top.url)
            is NavScreen.Catalog -> {
                loadCatalog(top.url, recordVisit = false)
                if (isHomePageUrl(top.url) && settings.value.nuvioIntegrationEnabled) {
                    if (settings.value.nuvioHomeCatalogsEnabled) {
                        refreshEnabledAddonHomeSections(forceRefresh = true)
                    }
                    if (settings.value.nuvioHeroEnabled && settings.value.heroSourceKey?.startsWith("addon:") == true) {
                        refreshHeroAddonSource(forceRefresh = true)
                    }
                }
            }
            is NavScreen.AddonCatalogGrid -> loadAddonGridInitial(top, forceRefresh = true)
            is NavScreen.AddonDetail -> loadAddonDetail(top, forceRefresh = true)
            is NavScreen.AddonSources -> loadAddonSources(top, forceRefresh = true)
            null -> openCatalogUrl(settings.value.mirrorUrl)
        }
    }

    fun navigateBack(): Boolean {
        val stack = _backStack.value
        if (stack.size <= 1) return false
        val next = stack.dropLast(1)
        _backStack.value = next
        when (val top = next.last()) {
            is NavScreen.Detail -> loadDetail(top.url)
            is NavScreen.Catalog -> {
                if (_catalog.value?.url != top.url) {
                    loadCatalog(top.url, recordVisit = false)
                }
            }
            is NavScreen.AddonCatalogGrid -> {
                if (_addonGridState.value?.catalogId != top.catalogId ||
                    _addonGridState.value?.addonManifestUrl != top.addonManifestUrl
                ) {
                    loadAddonGridInitial(top, forceRefresh = false)
                }
            }
            is NavScreen.AddonDetail -> {
                val curr = _addonDetailState.value.meta
                if (curr == null || curr.id != top.id || curr.type != top.type) {
                    loadAddonDetail(top, forceRefresh = false)
                }
            }
            is NavScreen.AddonSources -> {
                val curr = _addonSourcesState.value
                if (curr.streamId != top.streamId || curr.contentType != top.contentType) {
                    loadAddonSources(top, forceRefresh = false)
                }
            }
        }
        return true
    }

    fun isHomePageUrl(url: String): Boolean {
        val cleanPath = android.net.Uri.parse(Config.normalizeUrl(url)).path?.trim('/').orEmpty()
        return cleanPath.isEmpty() || cleanPath.equals("index.php", ignoreCase = true)
    }

    private fun loadCatalog(url: String, recordVisit: Boolean) {
        viewModelScope.launch {
            _catalogLoading.value = true
            _catalogError.value = null
            try {
                val page = repository.fetchCatalogPage(url)
                _catalog.value = page
                if (!page.isSearchOrGrid && isHomePageUrl(page.url)) {
                    latestMovieLinkHomeSections = page.sections
                    unifiedHomeCatalogManager.syncSources(page.sections, addons.value)
                }
                if (recordVisit) {
                    settingsStore.recordHistory(page.pageTitle, page.url)
                }
            } catch (cf: CloudflareRequiredException) {
                _catalogError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _catalogError.value = e.message ?: "Connection failed"
            } finally {
                _catalogLoading.value = false
            }
        }
    }

    private fun loadDetail(url: String, titleHint: String? = null, posterHint: String = "") {
        viewModelScope.launch {
            _detailLoading.value = true
            _detailError.value = null
            try {
                val d = repository.fetchDetail(url)
                _detail.value = d
                settingsStore.recordHistory(d.title.ifBlank { titleHint }, d.url, d.posterUrl.ifBlank { posterHint })
            } catch (cf: CloudflareRequiredException) {
                _detailError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _detailError.value = e.message ?: "Unable to load movie details"
            } finally {
                _detailLoading.value = false
            }
        }
    }

    fun launchPlayer(request: PlayerLaunchRequest) {
        _playerRequest.value = request
    }

    fun closePlayer() {
        _playerRequest.value = null
    }

    fun openFallbackWeb(url: String, title: String = "MovieLink Browser") {
        _fallbackWeb.value = FallbackWebRequest(url, title, isCloudflareChallenge = false, retryTargetUrl = null)
    }

    fun closeFallbackWeb() {
        _fallbackWeb.value = null
    }

    fun onCloudflareSolved() {
        val retryUrl = _fallbackWeb.value?.retryTargetUrl
        _fallbackWeb.value = null
        if (!retryUrl.isNullOrBlank()) {
            when {
                retryUrl.contains("/search", ignoreCase = true) && _unifiedSearch.value.hasSearched ->
                    retryMovieLinkSearch()
                isDetailUrl(retryUrl) -> loadDetail(retryUrl)
                else -> loadCatalog(retryUrl, recordVisit = true)
            }
        } else {
            refreshCurrent()
        }
    }

    fun openTrailer(youtubeId: String, title: String) {
        _trailerId.value = youtubeId to title
    }

    fun closeTrailer() {
        _trailerId.value = null
    }

    fun showVideoChoice(choice: PendingVideoChoice) {
        _pendingVideoChoice.value = choice
    }

    fun dismissVideoChoice() {
        _pendingVideoChoice.value = null
    }

    fun showDownloaderChoice(choice: PendingDownloaderChoice) {
        _pendingDownloaderChoice.value = choice
    }

    fun dismissDownloaderChoice() {
        _pendingDownloaderChoice.value = null
    }

    suspend fun installAddon(url: String): Result<InstalledAddon> {
        val res = addonManager.installAddon(url)
        if (res.isSuccess) {
            addonCatalogRepository.clearCache()
            unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, addons.value)
        }
        return res
    }

    fun setAddonEnabled(manifestUrl: String, enabled: Boolean) {
        addonManager.setAddonEnabled(manifestUrl, enabled)
        addonCatalogRepository.clearCache()
        unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, addons.value)
    }

    fun removeAddon(manifestUrl: String) {
        addonManager.removeAddon(manifestUrl)
        addonCatalogRepository.clearCache()
        unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, addons.value)
    }

    suspend fun refreshAddon(manifestUrl: String): Result<InstalledAddon> {
        val res = addonManager.refreshAddon(manifestUrl)
        addonCatalogRepository.clearCache()
        unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, addons.value)
        return res
    }

    fun refreshAllAddons() {
        viewModelScope.launch {
            addonManager.refreshAllAddons()
            addonCatalogRepository.clearCache()
            unifiedHomeCatalogManager.syncSources(latestMovieLinkHomeSections, addons.value)
        }
    }

    fun setUnifiedHomeCatalogEnabled(key: String, enabled: Boolean) {
        unifiedHomeCatalogManager.setCatalogEnabled(key, enabled)
    }

    fun moveUnifiedHomeCatalog(fromIndex: Int, toIndex: Int) {
        unifiedHomeCatalogManager.moveCatalog(fromIndex, toIndex)
    }

    fun removeUnifiedHomeCatalogEntry(key: String) {
        unifiedHomeCatalogManager.removeEntry(key)
    }

    fun availableAddonHomeCatalogs(): List<AddonCatalogDescriptor> =
        addonCatalogRepository.availableHomeCatalogs(addons.value)

    suspend fun fetchAddonCatalog(
        addon: InstalledAddon,
        catalog: StremioCatalogSpec,
        skip: Int = 0,
        searchQuery: String? = null,
        genre: String? = null,
        forceRefresh: Boolean = false
    ): Result<AddonCatalogPage> =
        addonCatalogRepository.fetchCatalog(
            addon = addon,
            catalog = catalog,
            skip = skip,
            searchQuery = searchQuery,
            genre = genre,
            forceRefresh = forceRefresh
        )

    fun refreshEnabledAddonHomeSections(forceRefresh: Boolean = false) {
        val s = settings.value
        if (!s.nuvioIntegrationEnabled || !s.nuvioHomeCatalogsEnabled) return
        val enabledAddonEntries = unifiedHomeCatalogs.value.filter {
            it.provider == ContentProviderKind.STREMIO_ADDON && it.enabled && it.isAvailable
        }
        val currentAddons = addons.value.associateBy { it.manifestUrl }
        for (entry in enabledAddonEntries) {
            val manifestUrl = entry.addonManifestUrl ?: continue
            val catType = entry.addonCatalogType ?: continue
            val catId = entry.addonCatalogId ?: continue
            val existing = _addonHomeRows.value[entry.key]
            if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) {
                continue
            }
            if (!inFlightAddonCatalogKeys.add(entry.key)) continue

            val addon = currentAddons[manifestUrl]
            val spec = addon?.manifest?.catalogs?.firstOrNull {
                it.type.equals(catType, ignoreCase = true) && it.id.equals(catId, ignoreCase = true)
            }
            if (addon == null || spec == null) {
                inFlightAddonCatalogKeys.remove(entry.key)
                _addonHomeRows.update { map ->
                    map + (entry.key to AddonHomeRowData(isLoading = false, error = "Catalog unavailable"))
                }
                continue
            }

            _addonHomeRows.update { map ->
                map + (entry.key to AddonHomeRowData(
                    items = existing?.items.orEmpty(),
                    isLoading = true,
                    error = null
                ))
            }

            viewModelScope.launch {
                try {
                    val res = addonCatalogRepository.fetchCatalog(
                        addon = addon,
                        catalog = spec,
                        skip = 0,
                        forceRefresh = forceRefresh
                    )
                    res.fold(
                        onSuccess = { page ->
                            _addonHomeRows.update { map ->
                                map + (entry.key to AddonHomeRowData(
                                    items = page.items,
                                    isLoading = false,
                                    error = null,
                                    hasMore = page.hasMore
                                ))
                            }
                        },
                        onFailure = { err ->
                            _addonHomeRows.update { map ->
                                map + (entry.key to AddonHomeRowData(
                                    items = existing?.items.orEmpty(),
                                    isLoading = false,
                                    error = err.message ?: "Failed to load catalog"
                                ))
                            }
                        }
                    )
                } finally {
                    inFlightAddonCatalogKeys.remove(entry.key)
                }
            }
        }
    }

    fun retryAddonHomeSection(entryKey: String) {
        _addonHomeRows.update { map -> map - entryKey }
        refreshEnabledAddonHomeSections(forceRefresh = true)
    }

    fun refreshHeroAddonSource(forceRefresh: Boolean = false) {
        val s = settings.value
        val key = s.heroSourceKey?.takeIf { it.startsWith("addon:") } ?: return
        if (!s.nuvioIntegrationEnabled || !s.nuvioHeroEnabled) return
        val existing = _heroAddonRows.value[key]
        if (!forceRefresh && existing != null && existing.items.isNotEmpty() && existing.error == null) return
        if (!inFlightHeroKeys.add(key)) return

        val parts = key.removePrefix("addon:").split("|")
        val manifestUrl = parts.getOrNull(0).orEmpty()
        val catType = parts.getOrNull(1).orEmpty()
        val catId = parts.getOrNull(2).orEmpty()
        val addon = addons.value.firstOrNull { it.enabled && it.manifestUrl == manifestUrl }
        val spec = addon?.manifest?.catalogs?.firstOrNull {
            it.type.equals(catType, ignoreCase = true) && it.id.equals(catId, ignoreCase = true)
        }
        if (addon == null || spec == null) {
            inFlightHeroKeys.remove(key)
            return
        }

        _heroAddonRows.update { map ->
            map + (key to AddonHomeRowData(items = existing?.items.orEmpty(), isLoading = true, error = null))
        }
        viewModelScope.launch {
            try {
                val res = addonCatalogRepository.fetchCatalog(
                    addon = addon,
                    catalog = spec,
                    skip = 0,
                    forceRefresh = forceRefresh
                )
                res.fold(
                    onSuccess = { page ->
                        _heroAddonRows.update { map ->
                            map + (key to AddonHomeRowData(items = page.items, isLoading = false, error = null))
                        }
                    },
                    onFailure = { err ->
                        _heroAddonRows.update { map ->
                            map + (key to AddonHomeRowData(
                                items = existing?.items.orEmpty(),
                                isLoading = false,
                                error = err.message ?: "Failed to load hero catalogue"
                            ))
                        }
                    }
                )
            } finally {
                inFlightHeroKeys.remove(key)
            }
        }
    }

    fun openAddonCatalogGrid(section: CombinedHomeSectionState) {
        val manifestUrl = section.addonManifestUrl ?: return
        val type = section.catalogType ?: return
        val catalogId = section.catalogId ?: return
        val nav = NavScreen.AddonCatalogGrid(
            entryKey = section.key,
            addonManifestUrl = manifestUrl,
            catalogType = type,
            catalogId = catalogId,
            title = section.title
        )
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + nav
        loadAddonGridInitial(nav, forceRefresh = false)
    }

    private fun loadAddonGridInitial(nav: NavScreen.AddonCatalogGrid, forceRefresh: Boolean) {
        val addon = addons.value.firstOrNull { it.manifestUrl == nav.addonManifestUrl }
        val spec = addon?.manifest?.catalogs?.firstOrNull {
            it.type.equals(nav.catalogType, ignoreCase = true) && it.id.equals(nav.catalogId, ignoreCase = true)
        }
        val initialCached = _addonHomeRows.value[nav.entryKey]
        _addonGridState.value = AddonGridState(
            title = nav.title,
            addonName = addon?.manifest?.name.orEmpty(),
            addonManifestUrl = nav.addonManifestUrl,
            catalogType = nav.catalogType,
            catalogId = nav.catalogId,
            items = if (forceRefresh) emptyList() else initialCached?.items.orEmpty(),
            isLoading = true,
            hasMore = initialCached?.hasMore ?: false,
            nextSkip = initialCached?.items?.size ?: 0,
            error = null
        )
        if (addon == null || spec == null) {
            _addonGridState.update { it?.copy(isLoading = false, error = "Addon or catalog unavailable") }
            return
        }
        viewModelScope.launch {
            val res = addonCatalogRepository.fetchCatalog(addon, spec, skip = 0, forceRefresh = forceRefresh)
            res.fold(
                onSuccess = { page ->
                    _addonGridState.value = AddonGridState(
                        title = nav.title,
                        addonName = addon.manifest.name,
                        addonManifestUrl = nav.addonManifestUrl,
                        catalogType = nav.catalogType,
                        catalogId = nav.catalogId,
                        items = page.items,
                        isLoading = false,
                        hasMore = page.hasMore,
                        nextSkip = page.nextSkip,
                        error = null
                    )
                },
                onFailure = { err ->
                    _addonGridState.update { curr ->
                        curr?.copy(isLoading = false, error = err.message ?: "Failed to load catalog")
                    }
                }
            )
        }
    }

    fun loadMoreAddonCatalogGrid() {
        val curr = _addonGridState.value ?: return
        if (curr.isLoading || !curr.hasMore) return
        val addon = addons.value.firstOrNull { it.manifestUrl == curr.addonManifestUrl } ?: return
        val spec = addon.manifest.catalogs.firstOrNull {
            it.type.equals(curr.catalogType, ignoreCase = true) && it.id.equals(curr.catalogId, ignoreCase = true)
        } ?: return

        _addonGridState.value = curr.copy(isLoading = true, error = null)
        viewModelScope.launch {
            val res = addonCatalogRepository.fetchCatalog(addon, spec, skip = curr.nextSkip)
            res.fold(
                onSuccess = { page ->
                    val merged = (curr.items + page.items).distinctBy { it.stableKey }
                    _addonGridState.update {
                        it?.copy(
                            items = merged,
                            isLoading = false,
                            hasMore = page.hasMore && page.items.isNotEmpty(),
                            nextSkip = page.nextSkip,
                            error = null
                        )
                    }
                },
                onFailure = { err ->
                    _addonGridState.update {
                        it?.copy(isLoading = false, error = err.message ?: "Failed to load more items")
                    }
                }
            )
        }
    }

    fun retryAddonGrid() {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonCatalogGrid ?: return
        loadAddonGridInitial(top, forceRefresh = true)
    }

    fun openUnifiedPoster(item: UnifiedPosterItem) {
        when (item.provider) {
            ContentProviderKind.MOVIELINK_BD -> {
                val url = item.movieLinkUrl.orEmpty()
                if (url.isNotBlank()) {
                    openUrlSmart(url, item.title, item.posterUrl)
                }
            }
            ContentProviderKind.STREMIO_ADDON -> {
                val itemId = item.stremioId.orEmpty().trim()
                if (itemId.isBlank()) return
                val itemType = item.stremioType?.takeIf { it.isNotBlank() }
                    ?: item.type.takeIf { it.isNotBlank() }
                    ?: "movie"
                val nav = NavScreen.AddonDetail(
                    type = itemType,
                    id = itemId,
                    addonManifestUrl = item.addonManifestUrl,
                    addonNameHint = item.addonName,
                    titleHint = item.title,
                    posterHint = item.posterUrl,
                    backdropHint = item.backdropUrl,
                    yearHint = item.yearOrRelease,
                    ratingHint = item.rating,
                    descriptionHint = item.description,
                    genresHint = item.genres,
                    logoHint = item.logoUrl
                )
                val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
                _backStack.value = currentStack + nav
                loadAddonDetail(nav, forceRefresh = false)
            }
        }
    }

    private fun loadAddonDetail(nav: NavScreen.AddonDetail, forceRefresh: Boolean) {
        val fallback = if (nav.titleHint.isNotBlank()) {
            AddonDetailedMeta(
                id = nav.id,
                type = nav.type,
                title = nav.titleHint,
                posterUrl = nav.posterHint,
                backdropUrl = nav.backdropHint.ifBlank { nav.posterHint },
                logoUrl = nav.logoHint,
                description = nav.descriptionHint,
                releaseYear = nav.yearHint,
                rating = nav.ratingHint,
                genres = nav.genresHint,
                sourceAddonName = nav.addonNameHint.orEmpty(),
                sourceManifestUrl = nav.addonManifestUrl.orEmpty(),
                fromFallbackPreview = true
            )
        } else {
            null
        }
        _addonDetailState.value = AddonDetailUiState(
            meta = fallback,
            isLoading = true,
            error = null
        )
        viewModelScope.launch {
            val res = addonMetadataRepository.fetchMeta(
                addons = addons.value,
                type = nav.type,
                id = nav.id,
                preferredManifestUrl = nav.addonManifestUrl,
                fallbackPreview = fallback,
                forceRefresh = forceRefresh
            )
            res.fold(
                onSuccess = { fetched ->
                    _addonDetailState.value = AddonDetailUiState(
                        meta = fetched,
                        isLoading = false,
                        error = null
                    )
                },
                onFailure = { err ->
                    _addonDetailState.value = AddonDetailUiState(
                        meta = fallback,
                        isLoading = false,
                        error = if (fallback == null) err.message ?: "Unable to fetch addon metadata" else null
                    )
                }
            )
        }
    }

    fun retryAddonDetail() {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonDetail ?: return
        loadAddonDetail(top, forceRefresh = true)
    }

    fun openAddonSourcesScreen(contentType: String, streamId: String, title: String, subtitle: String, posterUrl: String) {
        val nav = NavScreen.AddonSources(
            contentType = contentType,
            streamId = streamId,
            title = title,
            subtitle = subtitle,
            posterUrl = posterUrl
        )
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + nav
        loadAddonSources(nav, forceRefresh = false)
    }

    private fun loadAddonSources(nav: NavScreen.AddonSources, forceRefresh: Boolean) {
        val enabledAddons = addons.value.filter { it.enabled && it.manifest.supportsResource("stream", nav.contentType, nav.streamId) }
        val initialGroups = enabledAddons.map { addon ->
            AddonStreamGroupResult(
                addonManifestUrl = addon.manifestUrl,
                addonName = addon.manifest.name,
                isLoading = true
            )
        }
        _addonSourcesState.value = AddonSourcesUiState(
            contentType = nav.contentType,
            streamId = nav.streamId,
            title = nav.title,
            subtitle = nav.subtitle,
            posterUrl = nav.posterUrl,
            groupResults = initialGroups,
            isLoadingAny = true
        )

        for (addon in enabledAddons) {
            viewModelScope.launch {
                val res = addonStreamRepository.fetchStreamsForAddon(
                    addon = addon,
                    type = nav.contentType,
                    streamId = nav.streamId,
                    forceRefresh = forceRefresh
                )
                _addonSourcesState.update { state ->
                    val updatedGroups = state.groupResults.map { grp ->
                        if (grp.addonManifestUrl != addon.manifestUrl) {
                            grp
                        } else {
                            res.fold(
                                onSuccess = { (streams, subs) ->
                                    grp.copy(
                                        streams = streams,
                                        subtitles = subs,
                                        isLoading = false,
                                        error = null
                                    )
                                },
                                onFailure = { err ->
                                    grp.copy(
                                        isLoading = false,
                                        error = err.message ?: "Failed to fetch streams"
                                    )
                                }
                            )
                        }
                    }
                    state.copy(
                        groupResults = updatedGroups,
                        isLoadingAny = updatedGroups.any { it.isLoading }
                    )
                }
            }
        }
    }

    fun retryAddonStreamGroup(addonManifestUrl: String) {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonSources ?: return
        val addon = addons.value.firstOrNull { it.manifestUrl == addonManifestUrl } ?: return

        _addonSourcesState.update { state ->
            val updated = state.groupResults.map { g ->
                if (g.addonManifestUrl == addonManifestUrl) g.copy(isLoading = true, error = null) else g
            }
            state.copy(groupResults = updated, isLoadingAny = true)
        }

        viewModelScope.launch {
            val res = addonStreamRepository.fetchStreamsForAddon(
                addon = addon,
                type = top.contentType,
                streamId = top.streamId,
                forceRefresh = true
            )
            _addonSourcesState.update { state ->
                val updatedGroups = state.groupResults.map { grp ->
                    if (grp.addonManifestUrl != addonManifestUrl) grp.copy() else {
                        res.fold(
                            onSuccess = { (streams, subs) ->
                                grp.copy(streams = streams, subtitles = subs, isLoading = false, error = null)
                            },
                            onFailure = { err ->
                                grp.copy(isLoading = false, error = err.message ?: "Stream request failed")
                            }
                        )
                    }
                }
                state.copy(groupResults = updatedGroups, isLoadingAny = updatedGroups.any { it.isLoading })
            }
        }
    }

    fun refreshAddonSources() {
        val top = _backStack.value.lastOrNull() as? NavScreen.AddonSources ?: return
        loadAddonSources(top, forceRefresh = true)
    }
}
