package com.personal.movielink

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface NavScreen {
    data class Catalog(val url: String) : NavScreen
    data class Detail(val url: String) : NavScreen
}

data class PendingVideoChoice(
    val url: String,
    val title: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

data class PendingDownloaderChoice(
    val url: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

data class FallbackWebRequest(
    val url: String,
    val title: String,
    val isCloudflareChallenge: Boolean = false,
    val retryTargetUrl: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val settingsStore = AppSettingsStore(application)
    val imageLoader = MovieLinkNetwork.buildImageLoader(application)
    val httpClient = MovieLinkNetwork.buildHttpClient { settingsStore.settings.value }
    private val repository = MovieLinkRepository(httpClient) { settingsStore.settings.value }

    val settings: StateFlow<UserSettings> = settingsStore.settings
    val history: StateFlow<List<HistoryItem>> = settingsStore.history
    val myList: StateFlow<List<MyListItem>> = settingsStore.myList
    val sessionBlockedCount: StateFlow<Int> = AdBlocker.sessionBlockedCount

    private val _backStack = MutableStateFlow<List<NavScreen>>(emptyList())
    val backStack: StateFlow<List<NavScreen>> = _backStack.asStateFlow()

    private val _catalog = MutableStateFlow<CatalogPage?>(null)
    val catalog: StateFlow<CatalogPage?> = _catalog.asStateFlow()

    private val _catalogLoading = MutableStateFlow(false)
    val catalogLoading: StateFlow<Boolean> = _catalogLoading.asStateFlow()

    private val _catalogError = MutableStateFlow<String?>(null)
    val catalogError: StateFlow<String?> = _catalogError.asStateFlow()

    private val _detail = MutableStateFlow<MediaDetail?>(null)
    val detail: StateFlow<MediaDetail?> = _detail.asStateFlow()

    private val _detailLoading = MutableStateFlow(false)
    val detailLoading: StateFlow<Boolean> = _detailLoading.asStateFlow()

    private val _detailError = MutableStateFlow<String?>(null)
    val detailError: StateFlow<String?> = _detailError.asStateFlow()

    private val _playerRequest = MutableStateFlow<PlayerLaunchRequest?>(null)
    val playerRequest: StateFlow<PlayerLaunchRequest?> = _playerRequest.asStateFlow()

    private val _fallbackWeb = MutableStateFlow<FallbackWebRequest?>(null)
    val fallbackWeb: StateFlow<FallbackWebRequest?> = _fallbackWeb.asStateFlow()

    private val _trailerId = MutableStateFlow<Pair<String, String>?>(null)
    val trailerId: StateFlow<Pair<String, String>?> = _trailerId.asStateFlow()

    private val _pendingVideoChoice = MutableStateFlow<PendingVideoChoice?>(null)
    val pendingVideoChoice: StateFlow<PendingVideoChoice?> = _pendingVideoChoice.asStateFlow()

    private val _pendingDownloaderChoice = MutableStateFlow<PendingDownloaderChoice?>(null)
    val pendingDownloaderChoice: StateFlow<PendingDownloaderChoice?> = _pendingDownloaderChoice.asStateFlow()

    init {
        val startUrl = settingsStore.startupUrl()
        if (isDetailUrl(startUrl)) {
            _backStack.value = listOf(
                NavScreen.Catalog(settings.value.mirrorUrl),
                NavScreen.Detail(startUrl)
            )
            loadCatalog(settings.value.mirrorUrl, recordVisit = false)
            loadDetail(startUrl)
        } else {
            _backStack.value = listOf(NavScreen.Catalog(startUrl))
            loadCatalog(startUrl, recordVisit = true)
        }
    }

    fun currentUrl(): String {
        return when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> top.url
            is NavScreen.Catalog -> top.url
            null -> settings.value.mirrorUrl
        }
    }

    fun isDetailUrl(url: String): Boolean {
        val lower = url.lowercase()
        return lower.contains("/movie/") ||
            lower.contains("/series/") ||
            lower.contains("/drama/") ||
            lower.contains("/anime/")
    }

    fun openCatalogUrl(url: String) {
        val normalized = Config.normalizeUrl(url)
        _backStack.value = listOf(NavScreen.Catalog(normalized))
        loadCatalog(normalized, recordVisit = true)
    }

    fun searchCatalog(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return
        val searchUrl = "${settings.value.mirrorUrl.trimEnd('/')}/search?q=${java.net.URLEncoder.encode(trimmed, "UTF-8")}"
        _backStack.value = listOf(NavScreen.Catalog(searchUrl))
        viewModelScope.launch {
            _catalogLoading.value = true
            _catalogError.value = null
            try {
                val page = repository.searchCatalog(trimmed)
                _catalog.value = page
                settingsStore.recordHistory(page.pageTitle, page.url)
            } catch (cf: CloudflareRequiredException) {
                _catalogError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _catalogError.value = e.message ?: "Unable to search catalog"
            } finally {
                _catalogLoading.value = false
            }
        }
    }

    fun openDetailUrl(url: String, titleHint: String? = null, posterHint: String = "") {
        val currentStack = _backStack.value.ifEmpty { listOf(NavScreen.Catalog(settings.value.mirrorUrl)) }
        _backStack.value = currentStack + NavScreen.Detail(url)
        _detail.value = null
        loadDetail(url, titleHint, posterHint)
    }

    fun openUrlSmart(url: String, titleHint: String? = null, posterHint: String = "") {
        if (isDetailUrl(url)) {
            openDetailUrl(url, titleHint, posterHint)
        } else {
            openCatalogUrl(url)
        }
    }

    fun refreshCurrent() {
        when (val top = _backStack.value.lastOrNull()) {
            is NavScreen.Detail -> loadDetail(top.url)
            is NavScreen.Catalog -> loadCatalog(top.url, recordVisit = false)
            null -> openCatalogUrl(settings.value.mirrorUrl)
        }
    }

    fun navigateBack(): Boolean {
        val stack = _backStack.value
        if (stack.size <= 1) return false
        val next = stack.dropLast(1)
        _backStack.value = next
        when (val top = next.last()) {
            is NavScreen.Detail -> loadDetail(top.url)
            is NavScreen.Catalog -> {
                if (_catalog.value?.url != top.url) {
                    loadCatalog(top.url, recordVisit = false)
                }
            }
        }
        return true
    }

    private fun loadCatalog(url: String, recordVisit: Boolean) {
        viewModelScope.launch {
            _catalogLoading.value = true
            _catalogError.value = null
            try {
                val page = repository.fetchCatalogPage(url)
                _catalog.value = page
                if (recordVisit) {
                    settingsStore.recordHistory(page.pageTitle, page.url)
                }
            } catch (cf: CloudflareRequiredException) {
                _catalogError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _catalogError.value = e.message ?: "Connection failed"
            } finally {
                _catalogLoading.value = false
            }
        }
    }

    private fun loadDetail(url: String, titleHint: String? = null, posterHint: String = "") {
        viewModelScope.launch {
            _detailLoading.value = true
            _detailError.value = null
            try {
                val d = repository.fetchDetail(url)
                _detail.value = d
                settingsStore.recordHistory(d.title.ifBlank { titleHint }, d.url, d.posterUrl.ifBlank { posterHint })
            } catch (cf: CloudflareRequiredException) {
                _detailError.value = "Cloudflare verification required"
                _fallbackWeb.value = FallbackWebRequest(cf.url, "Security Check", isCloudflareChallenge = true, retryTargetUrl = cf.url)
            } catch (e: Exception) {
                _detailError.value = e.message ?: "Unable to load movie details"
            } finally {
                _detailLoading.value = false
            }
        }
    }

    fun launchPlayer(request: PlayerLaunchRequest) {
        _playerRequest.value = request
    }

    fun closePlayer() {
        _playerRequest.value = null
    }

    fun openFallbackWeb(url: String, title: String = "MovieLink Browser") {
        _fallbackWeb.value = FallbackWebRequest(url, title, isCloudflareChallenge = false, retryTargetUrl = null)
    }

    fun closeFallbackWeb() {
        _fallbackWeb.value = null
    }

    fun onCloudflareSolved() {
        val retryUrl = _fallbackWeb.value?.retryTargetUrl
        _fallbackWeb.value = null
        if (!retryUrl.isNullOrBlank()) {
            if (isDetailUrl(retryUrl)) loadDetail(retryUrl) else loadCatalog(retryUrl, recordVisit = true)
        } else {
            refreshCurrent()
        }
    }

    fun openTrailer(youtubeId: String, title: String) {
        _trailerId.value = youtubeId to title
    }

    fun closeTrailer() {
        _trailerId.value = null
    }

    fun showVideoChoice(choice: PendingVideoChoice) {
        _pendingVideoChoice.value = choice
    }

    fun dismissVideoChoice() {
        _pendingVideoChoice.value = null
    }

    fun showDownloaderChoice(choice: PendingDownloaderChoice) {
        _pendingDownloaderChoice.value = choice
    }

    fun dismissDownloaderChoice() {
        _pendingDownloaderChoice.value = null
    }
}
