package com.personal.movielink.ui.dialogs

import android.annotation.SuppressLint
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ViewCarousel
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.ColorUtils
import com.personal.movielink.AppSettingsStore
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.HeroSourceOption
import com.personal.movielink.HistoryItem
import com.personal.movielink.MyListItem
import com.personal.movielink.UserSettings
import com.personal.movielink.addons.InstalledAddon
import com.personal.movielink.addons.UnifiedHomeCatalogEntry
import com.personal.movielink.ui.components.ColorWheelDialog
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import kotlin.math.roundToInt

private enum class SettingsSubpage(val title: String) {
    GENERAL("MovieLink Settings"),
    HOME_CATALOGS("Home Screen Catalogues"),
    HERO_CONFIG("Hero Section"),
    PROVIDERS("Providers"),
    ADDONS("Stremio Addons"),
    SEARCH_STREAMING("Search & Streaming"),
    METADATA("Metadata & Posters")
}

@Composable
fun SettingsDialog(
    settings: UserSettings,
    addons: List<InstalledAddon>,
    addonsBusy: Boolean,
    unifiedHomeCatalogs: List<UnifiedHomeCatalogEntry>,
    heroSources: List<HeroSourceOption>,
    currentUrl: String,
    sessionBlockedCount: Int,
    onUpdateSettings: ((UserSettings) -> UserSettings) -> Unit,
    onReloadHome: (String) -> Unit,
    onOpenCurrentUrlInPlayer: (String) -> Unit,
    onPlayLocalVideo: () -> Unit,
    onSaveCustomDomains: (String, String) -> Unit,
    onInstallAddon: suspend (String) -> Result<InstalledAddon>,
    onToggleAddon: (String, Boolean) -> Unit,
    onRefreshAddon: suspend (String) -> Result<InstalledAddon>,
    onRefreshAllAddons: () -> Unit,
    onRemoveAddon: (String) -> Unit,
    onToggleHomeCatalog: (String, Boolean) -> Unit,
    onMoveHomeCatalog: (Int, Int) -> Unit,
    onRemoveHomeCatalogEntry: (String) -> Unit,
    onTestMetadataIntegration: suspend (
        kind: String,
        tmdbKey: String,
        mdbKey: String,
        bpProvider: Config.BetterPosterProvider,
        rpdbKey: String,
        customTemplate: String
    ) -> Result<String> = { _, _, _, _, _, _ -> Result.failure(UnsupportedOperationException()) },
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var activeSubpage by remember { mutableStateOf(SettingsSubpage.GENERAL) }
    var mirrorInput by remember(settings.mirrorUrl) { mutableStateOf(settings.mirrorUrl) }
    var showBgWheel by remember { mutableStateOf(false) }
    var showThemeWheel by remember { mutableStateOf(false) }
    var showFloatingNavWheel by remember { mutableStateOf(false) }
    var showDetailBoxWheel by remember { mutableStateOf(false) }
    var showDomainsDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 720.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(palette.cardBg)
                .border(1.5.dp, palette.boxBorder, RoundedCornerShape(18.dp))
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (activeSubpage != SettingsSubpage.GENERAL) {
                        IconButton(onClick = { activeSubpage = SettingsSubpage.GENERAL }) {
                            Icon(
                                Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back to Settings",
                                tint = palette.textPrimary
                            )
                        }
                    }
                    Column(modifier = Modifier.padding(start = if (activeSubpage == SettingsSubpage.GENERAL) 4.dp else 0.dp)) {
                        Text(
                            text = activeSubpage.title,
                            color = palette.textPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = when (activeSubpage) {
                                SettingsSubpage.GENERAL -> if (settings.adBlockEnabled) {
                                    "Blocked $sessionBlockedCount ad/tracker requests this session"
                                } else {
                                    "Ad-blocker paused"
                                }
                                SettingsSubpage.HOME_CATALOGS -> {
                                    val activeCount = unifiedHomeCatalogs.count { it.enabled && it.isAvailable }
                                    "$activeCount active sections · Drag to reorder"
                                }
                                SettingsSubpage.HERO_CONFIG -> {
                                    val selectedKeys = settings.effectiveHeroSourceKeys()
                                    val selected = heroSources.filter { it.key in selectedKeys }
                                    when {
                                        !settings.movieLinkHeroEnabled && !(settings.nuvioIntegrationEnabled && settings.nuvioHeroEnabled) ->
                                            "Hero carousel hidden"
                                        selected.size > 1 -> "${selected.size} catalogues selected · Rotates on open/refresh"
                                        selected.size == 1 -> "${selected.first().providerLabel} · ${selected.first().title}"
                                        selectedKeys.isNotEmpty() -> "${selectedKeys.size} selected (unavailable)"
                                        else -> "MovieLinkBD · Auto Default"
                                    }
                                }
                                SettingsSubpage.PROVIDERS -> if (settings.nuvioIntegrationEnabled) {
                                    "MovieLinkBD + Nuvio Addons active"
                                } else {
                                    "MovieLinkBD active · Nuvio OFF"
                                }
                                SettingsSubpage.ADDONS -> "${addons.size} installed (${addons.count { it.enabled }} enabled)"
                                SettingsSubpage.SEARCH_STREAMING -> "Independent provider switches"
                                SettingsSubpage.METADATA -> "Optional TMDB, MDBD & Better Poster"
                            },
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = palette.textPrimary)
                }
            }

            HorizontalDivider(color = palette.border.copy(alpha = 0.25f))

            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                when (activeSubpage) {
                    SettingsSubpage.HOME_CATALOGS -> {
                        HomeCatalogManagerSubpage(
                            settings = settings,
                            entries = unifiedHomeCatalogs,
                            onUpdateSettings = onUpdateSettings,
                            onToggleCatalog = onToggleHomeCatalog,
                            onMoveCatalog = onMoveHomeCatalog,
                            onRemoveEntry = onRemoveHomeCatalogEntry
                        )
                    }
                    SettingsSubpage.HERO_CONFIG -> {
                        HeroSettingsSubpage(
                            settings = settings,
                            heroSources = heroSources,
                            onUpdateSettings = onUpdateSettings
                        )
                    }
                    SettingsSubpage.PROVIDERS -> {
                        ProvidersSettingsSubpage(
                            settings = settings,
                            onUpdateSettings = onUpdateSettings
                        )
                    }
                    SettingsSubpage.ADDONS -> {
                        AddonManagerSubpage(
                            settings = settings,
                            addons = addons,
                            isBusy = addonsBusy,
                            onUpdateSettings = onUpdateSettings,
                            onInstallAddon = onInstallAddon,
                            onToggleAddon = onToggleAddon,
                            onRefreshAddon = onRefreshAddon,
                            onRefreshAllAddons = onRefreshAllAddons,
                            onRemoveAddon = onRemoveAddon
                        )
                    }
                    SettingsSubpage.SEARCH_STREAMING -> {
                        SearchAndStreamingSubpage(
                            settings = settings,
                            onUpdateSettings = onUpdateSettings
                        )
                    }
                    SettingsSubpage.METADATA -> {
                        MetadataIntegrationsSubpage(
                            settings = settings,
                            onUpdateSettings = onUpdateSettings,
                            onTestMetadataIntegration = onTestMetadataIntegration
                        )
                    }
                    SettingsSubpage.GENERAL -> {
                        // 0. Hybrid Provider & Addon Subpages
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SectionHeader("Home Screen, Providers & Addons")
                            SettingsSubpageEntryRow(
                                icon = Icons.Rounded.ViewList,
                                title = "Home Screen Catalogues",
                                subtitle = "${unifiedHomeCatalogs.count { it.enabled && it.isAvailable }} active across MovieLinkBD & Nuvio · Drag to reorder",
                                onClick = { activeSubpage = SettingsSubpage.HOME_CATALOGS }
                            )
                            SettingsSubpageEntryRow(
                                icon = Icons.Rounded.ViewCarousel,
                                title = "Hero Section",
                                subtitle = run {
                                    val selectedKeys = settings.effectiveHeroSourceKeys()
                                    val selected = heroSources.filter { it.key in selectedKeys }
                                    when {
                                        !settings.movieLinkHeroEnabled && !(settings.nuvioIntegrationEnabled && settings.nuvioHeroEnabled) ->
                                            "Hidden · Both providers OFF"
                                        selected.size > 1 -> "${selected.size} catalogues selected · Fresh item on open"
                                        selected.size == 1 -> "${selected.first().providerLabel} · ${selected.first().title}"
                                        selectedKeys.isNotEmpty() -> "${selectedKeys.size} selected (unavailable)"
                                        else -> "MovieLinkBD · Auto Default"
                                    }
                                },
                                onClick = { activeSubpage = SettingsSubpage.HERO_CONFIG }
                            )
                            SettingsSubpageEntryRow(
                                icon = Icons.Rounded.Tune,
                                title = "Providers",
                                subtitle = if (settings.nuvioIntegrationEnabled) {
                                    "MovieLinkBD ON · Nuvio Integration ON"
                                } else {
                                    "MovieLinkBD ON · Nuvio Integration OFF"
                                },
                                onClick = { activeSubpage = SettingsSubpage.PROVIDERS }
                            )
                            SettingsSubpageEntryRow(
                                icon = Icons.Rounded.Extension,
                                title = "Addons",
                                subtitle = if (addons.isEmpty()) {
                                    "Install & manage Stremio-compatible addons"
                                } else {
                                    "${addons.size} installed · ${addons.count { it.enabled }} enabled"
                                },
                                onClick = { activeSubpage = SettingsSubpage.ADDONS }
                            )
                            SettingsSubpageEntryRow(
                                icon = Icons.Rounded.Search,
                                title = "Search & Streaming",
                                subtitle = "Independent MovieLinkBD & Addon switches",
                                onClick = { activeSubpage = SettingsSubpage.SEARCH_STREAMING }
                            )
                            SettingsSubpageEntryRow(
                                icon = Icons.Rounded.AutoAwesome,
                                title = "Metadata & Posters",
                                subtitle = buildList {
                                    if (settings.tmdbMetadataEnabled) add("TMDB")
                                    if (settings.mdbListEnabled) add("MDBD")
                                    if (settings.betterPosterProvider != Config.BetterPosterProvider.NONE) {
                                        add(settings.betterPosterProvider.label)
                                    }
                                }.let { active ->
                                    if (active.isEmpty()) {
                                        "Optional TMDB, MDBD & Better Poster (OFF)"
                                    } else {
                                        "Active: ${active.joinToString(" · ")}"
                                    }
                                },
                                onClick = { activeSubpage = SettingsSubpage.METADATA }
                            )
                        }

                        // 1. Dynamic Mirror & Resume
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader("Mirror URL & Startup")
                    OutlinedTextField(
                        value = mirrorInput,
                        onValueChange = { mirrorInput = it },
                        singleLine = true,
                        label = { Text("Active Mirror URL", fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = palette.fg,
                            unfocusedBorderColor = palette.border.copy(alpha = 0.5f),
                            focusedTextColor = palette.textPrimary,
                            unfocusedTextColor = palette.textPrimary
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val norm = Config.normalizeUrl(mirrorInput)
                                mirrorInput = norm
                                onUpdateSettings { it.copy(mirrorUrl = norm) }
                                onReloadHome(norm)
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.fg,
                                contentColor = palette.onAccent
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save & Reload", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                mirrorInput = Config.DEFAULT_HOME_URL
                                onUpdateSettings { it.copy(mirrorUrl = Config.DEFAULT_HOME_URL) }
                                onReloadHome(Config.DEFAULT_HOME_URL)
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Reset to default", color = palette.textPrimary, fontSize = 12.5.sp)
                        }
                    }

                    SettingsToggleRow(
                        title = "Resume last visited page on startup",
                        subtitle = "Reopens the last movie, series, or page on launch",
                        checked = settings.resumeLastPage,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(resumeLastPage = v) } }
                    )
                }

                // 2. Downloader & Video Player
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader("Downloader & Video Player")

                    Text("Downloader Mode", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = palette.textSecondary)
                    Config.DownloaderMode.entries.forEach { mode ->
                        RadioChoiceRow(
                            label = mode.label,
                            selected = settings.downloaderMode == mode,
                            onClick = { onUpdateSettings { it.copy(downloaderMode = mode) } }
                        )
                    }

                    Spacer(Modifier.height(4.dp))
                    Text("Video Link Behavior", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = palette.textSecondary)
                    Config.VideoActionMode.entries.forEach { mode ->
                        RadioChoiceRow(
                            label = mode.label,
                            selected = settings.videoActionMode == mode,
                            onClick = { onUpdateSettings { it.copy(videoActionMode = mode) } }
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onOpenCurrentUrlInPlayer(currentUrl)
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Open current URL in video player", color = palette.fg, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onPlayLocalVideo()
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Play Local Video File (MP4 / MKV / HLS)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }

                    SettingsToggleRow(
                        title = "Hide bottom progress bar in fullscreen",
                        subtitle = "Removes persistent bottom seek bar in fullscreen landscape",
                        checked = settings.hideVideoProgressBar,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(hideVideoProgressBar = v) } }
                    )

                    SettingsToggleRow(
                        title = "Left-edge brightness controls screen",
                        subtitle = "Smoothly dims window brightness in fullscreen only (volume untouched)",
                        checked = settings.playerBrightnessSync,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(playerBrightnessSync = v) } }
                    )

                    SettingsToggleRow(
                        title = "Desktop User-Agent",
                        subtitle = "Uses desktop Chrome headers for catalog & fallback WebView",
                        checked = settings.desktopMode,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(desktopMode = v) } }
                    )
                }

                // 3. Clean English UI & Ad-Blocker
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader("Clean UI & Ad-Blocker")

                    SettingsToggleRow(
                        title = "English UI & clean movie boxes",
                        subtitle = "Translates Bangla labels & numerals, aligns detail boxes, hides site clutter",
                        checked = settings.sitePolishEnabled,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(sitePolishEnabled = v) } }
                    )

                    SettingsToggleRow(
                        title = "Ad, popup & tracker blocker",
                        subtitle = "Blocks ad networks & popups across catalog, ExoPlayer, and WebView",
                        checked = settings.adBlockEnabled,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(adBlockEnabled = v) } }
                    )

                    OutlinedButton(
                        onClick = { showDomainsDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Manage Blocked (${settings.customBlockedDomains.size}) & Allowed (${settings.customAllowedDomains.size}) Domains",
                            color = palette.textPrimary,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // 3B. Home & Floating Navigation Bar
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader("Home & Navigation Bar")

                    SettingsToggleRow(
                        title = "Show Watch by OTT section",
                        subtitle = "Displays OTT platform shortcuts below Continue Watching on Home",
                        checked = settings.showOttSection,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(showOttSection = v) } }
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(palette.altBg)
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "Continue Watching Layout",
                                color = palette.textPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Switch between portrait poster cards and wide horizontal cards",
                                color = palette.textSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Config.ContinueWatchingLayout.entries.forEach { layoutMode ->
                                val isSelected = settings.continueWatchingLayout == layoutMode
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(9.dp))
                                        .background(if (isSelected) palette.fg else palette.cardBg)
                                        .border(
                                            1.dp,
                                            if (isSelected) palette.fg else palette.border.copy(alpha = 0.35f),
                                            RoundedCornerShape(9.dp)
                                        )
                                        .clickable {
                                            onUpdateSettings { it.copy(continueWatchingLayout = layoutMode) }
                                        }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = layoutMode.label,
                                        color = if (isSelected) palette.onAccent else palette.textPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    SettingsToggleRow(
                        title = "Show local media player tab in bottom bar",
                        subtitle = "Adds a local video file picker shortcut tab to the bottom navigation bar",
                        checked = settings.showLocalPlayerTab,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(showLocalPlayerTab = v) } }
                    )

                    SettingsToggleRow(
                        title = "Floating navigation bar",
                        subtitle = "Replaces docked bottom bar with a customizable floating capsule",
                        checked = settings.floatingNavBar,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(floatingNavBar = v) } }
                    )

                    if (settings.floatingNavBar) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.altBg)
                                .border(1.dp, palette.boxBorder.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            FloatingSliderRow(
                                label = "Bar Height",
                                valueLabel = "${settings.floatingNavHeightDp} dp",
                                value = settings.floatingNavHeightDp.toFloat(),
                                range = 44f..76f,
                                onValueChange = { v ->
                                    onUpdateSettings { it.copy(floatingNavHeightDp = v.roundToInt()) }
                                }
                            )
                            FloatingSliderRow(
                                label = "Bar Width",
                                valueLabel = "${settings.floatingNavWidthPercent}%",
                                value = settings.floatingNavWidthPercent.toFloat(),
                                range = 62f..96f,
                                onValueChange = { v ->
                                    onUpdateSettings { it.copy(floatingNavWidthPercent = v.roundToInt()) }
                                }
                            )
                            FloatingSliderRow(
                                label = "Bottom Spacing",
                                valueLabel = "${settings.floatingNavSpacingDp} dp",
                                value = settings.floatingNavSpacingDp.toFloat(),
                                range = 4f..34f,
                                onValueChange = { v ->
                                    onUpdateSettings { it.copy(floatingNavSpacingDp = v.roundToInt()) }
                                }
                            )
                            FloatingSliderRow(
                                label = "Opacity (Transparency)",
                                valueLabel = "${settings.floatingNavAlphaPercent}%",
                                value = settings.floatingNavAlphaPercent.toFloat(),
                                range = 20f..100f,
                                onValueChange = { v ->
                                    onUpdateSettings { it.copy(floatingNavAlphaPercent = v.roundToInt()) }
                                }
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Floating Bar Color",
                                    color = palette.textPrimary,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                TextButton(onClick = { showFloatingNavWheel = true }) {
                                    Text(
                                        text = if (settings.floatingNavColorHex != null) "Color Wheel (${settings.floatingNavColorHex})" else "Color Wheel",
                                        color = palette.fg,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            val navSwatches = remember {
                                listOf(
                                    null to "Auto",
                                    "#141418" to "Dark",
                                    "#0F172A" to "Navy",
                                    "#1E1B4B" to "Indigo",
                                    "#064E3B" to "Emerald",
                                    "#4C0519" to "Wine",
                                    "#FFFFFF" to "Light"
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                navSwatches.forEach { (hex, label) ->
                                    val isSelected = settings.floatingNavColorHex.equals(hex, ignoreCase = true) ||
                                        (hex == null && settings.floatingNavColorHex == null)
                                    val swatchColor = if (hex == null) {
                                        palette.cardBg
                                    } else {
                                        Color(android.graphics.Color.parseColor(hex))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(30.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(swatchColor)
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) palette.fg else palette.border.copy(alpha = 0.55f),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                onUpdateSettings { it.copy(floatingNavColorHex = hex) }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (hex == null) {
                                            Text(
                                                text = label,
                                                color = palette.textPrimary,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    onUpdateSettings {
                                        it.copy(
                                            floatingNavHeightDp = 56,
                                            floatingNavWidthPercent = 88,
                                            floatingNavSpacingDp = 14,
                                            floatingNavAlphaPercent = 90,
                                            floatingNavColorHex = null
                                        )
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Reset Floating Bar Defaults", color = palette.textPrimary, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // 4. Background Color (8 Presets + HSV Color Wheel)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader("Background Color")
                        TextButton(onClick = { showBgWheel = true }) {
                            Text(
                                text = if (settings.bgPresetId == "custom") "Color Wheel (Custom)" else "Color Wheel",
                                color = palette.fg,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp
                            )
                        }
                    }

                    val bgRows = Config.BgPreset.entries.chunked(4)
                    bgRows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { preset ->
                                val selected = settings.bgPresetId == preset.id
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(android.graphics.Color.parseColor(preset.pageHex)))
                                        .border(
                                            width = if (selected) 2.dp else 1.dp,
                                            color = if (selected) palette.fg else Color(0xFF3F3F46),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            onUpdateSettings { it.copy(bgPresetId = preset.id) }
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = preset.label,
                                        color = Color.White,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 5. Theme Accent Color (Unlinked from Movie/Series Detail Boxes)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader("Theme Accent Color")
                        TextButton(onClick = { showThemeWheel = true }) {
                            Text(
                                text = if (settings.themePresetId == "custom") "Color Wheel (Custom)" else "Color Wheel",
                                color = palette.fg,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp
                            )
                        }
                    }

                    val themeRows = Config.ThemePreset.entries.chunked(3)
                    themeRows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { preset ->
                                val selected = settings.themePresetId == preset.id
                                val accentInt = android.graphics.Color.parseColor(preset.accentHex)
                                val borderInt = android.graphics.Color.parseColor(preset.borderHex)
                                val darkText = selected && ColorUtils.calculateLuminance(accentInt) > 0.42
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (selected) Color(accentInt) else palette.altBg)
                                        .border(
                                            width = if (selected) 2.dp else 1.5.dp,
                                            color = if (preset == Config.ThemePreset.BLACK && selected) Color(0xFF71717A) else Color(borderInt),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            onUpdateSettings { it.copy(themePresetId = preset.id) }
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = preset.label,
                                        color = if (darkText) Color(0xFF0A0D12) else palette.textPrimary,
                                        fontSize = 11.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // 6. Movie / Series Screen Boxes (Separate from Theme Accent Color)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeader("Movie / Series Screen Boxes")

                    SettingsToggleRow(
                        title = "Show info & action boxes",
                        subtitle = "When off, hides Type/Language/Quality/Trailer/My List boxes while keeping text positions exact",
                        checked = settings.detailBoxEnabled,
                        onCheckedChange = { v -> onUpdateSettings { it.copy(detailBoxEnabled = v) } }
                    )

                    if (settings.detailBoxEnabled) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(palette.altBg)
                                .border(1.dp, palette.boxBorder.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Box Style",
                                color = palette.textPrimary,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Config.DetailBoxStyle.entries.forEach { style ->
                                    val isSelected = settings.detailBoxStyle == style
                                    val chipShape = when (style) {
                                        Config.DetailBoxStyle.SQUARE -> RoundedCornerShape(0.dp)
                                        Config.DetailBoxStyle.CIRCLE -> RoundedCornerShape(50)
                                        Config.DetailBoxStyle.ROUNDED -> RoundedCornerShape(10.dp)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(chipShape)
                                            .background(if (isSelected) palette.fg else palette.cardBg)
                                            .border(
                                                width = 1.2.dp,
                                                color = if (isSelected) palette.fg else palette.border.copy(alpha = 0.45f),
                                                shape = chipShape
                                            )
                                            .clickable {
                                                onUpdateSettings { it.copy(detailBoxStyle = style) }
                                            }
                                            .padding(vertical = 9.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = style.label,
                                            color = if (isSelected) palette.onAccent else palette.textPrimary,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            FloatingSliderRow(
                                label = "Box Opacity",
                                valueLabel = "${settings.detailBoxOpacityPercent}%",
                                value = settings.detailBoxOpacityPercent.toFloat(),
                                range = 0f..100f,
                                onValueChange = { v ->
                                    onUpdateSettings { it.copy(detailBoxOpacityPercent = v.roundToInt()) }
                                }
                            )

                            FloatingSliderRow(
                                label = "Box Size",
                                valueLabel = "${settings.detailBoxSizePercent}%",
                                value = settings.detailBoxSizePercent.toFloat(),
                                range = 75f..130f,
                                onValueChange = { v ->
                                    onUpdateSettings { it.copy(detailBoxSizePercent = v.roundToInt()) }
                                }
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Box Color (${settings.detailBoxColorHex})",
                                    color = palette.textPrimary,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                TextButton(onClick = { showDetailBoxWheel = true }) {
                                    Text(
                                        text = "Color Wheel",
                                        color = palette.fg,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            val boxSwatches = remember {
                                listOf(
                                    "#000000" to "Black",
                                    "#71717A" to "Grey",
                                    "#E4E4E7" to "White",
                                    "#22D3EE" to "Cyan",
                                    "#3B82F6" to "Blue",
                                    "#22C55E" to "Green",
                                    "#EF4444" to "Red",
                                    "#A855F7" to "Purple",
                                    "#F59E0B" to "Amber"
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                boxSwatches.forEach { (hex, _) ->
                                    val isSelected = settings.detailBoxColorHex.equals(hex, ignoreCase = true)
                                    val isBlackSwatch = hex == "#000000"
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(28.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(android.graphics.Color.parseColor(hex)))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = when {
                                                    isSelected -> palette.textPrimary
                                                    isBlackSwatch -> Color(0xFF3F3F46)
                                                    else -> Color.Transparent
                                                },
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                onUpdateSettings { it.copy(detailBoxColorHex = hex) }
                                            }
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    onUpdateSettings {
                                        it.copy(
                                            detailBoxEnabled = true,
                                            detailBoxStyle = Config.DetailBoxStyle.ROUNDED,
                                            detailBoxOpacityPercent = 85,
                                            detailBoxSizePercent = 100,
                                            detailBoxColorHex = "#71717A"
                                        )
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Reset Boxes Defaults", color = palette.textPrimary, fontSize = 12.sp)
                            }
                        }
                    }
                }
                    }
                }
            }
        }
    }

    if (showBgWheel) {
        val currentBgHex = Config.resolveBg(settings.bgPresetId, settings.customBgHex).pageHex
        ColorWheelDialog(
            title = "Custom Background Color",
            initialHex = currentBgHex,
            minBrightness = 0.02f,
            onDismiss = { showBgWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(bgPresetId = "custom", customBgHex = hex) }
                showBgWheel = false
            }
        )
    }

    if (showThemeWheel) {
        val currentThemeHex = Config.resolveTheme(settings.themePresetId, settings.customThemeHex).accentHex
        ColorWheelDialog(
            title = "Custom Theme & Box Color",
            initialHex = currentThemeHex,
            minBrightness = 0.25f,
            onDismiss = { showThemeWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(themePresetId = "custom", customThemeHex = hex) }
                showThemeWheel = false
            }
        )
    }

    if (showFloatingNavWheel) {
        val initialNavHex = settings.floatingNavColorHex
            ?: Config.resolveBg(settings.bgPresetId, settings.customBgHex).cardHex
        ColorWheelDialog(
            title = "Floating Bar Color",
            initialHex = initialNavHex,
            minBrightness = 0.02f,
            onDismiss = { showFloatingNavWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(floatingNavColorHex = hex) }
                showFloatingNavWheel = false
            }
        )
    }

    if (showDetailBoxWheel) {
        ColorWheelDialog(
            title = "Detail Boxes Color",
            initialHex = settings.detailBoxColorHex,
            minBrightness = 0.15f,
            onDismiss = { showDetailBoxWheel = false },
            onConfirm = { hex ->
                onUpdateSettings { it.copy(detailBoxColorHex = hex) }
                showDetailBoxWheel = false
            }
        )
    }

    if (showDomainsDialog) {
        DomainRulesDialog(
            blockedDomains = settings.customBlockedDomains,
            allowedDomains = settings.customAllowedDomains,
            onDismiss = { showDomainsDialog = false },
            onSave = { blocked, allowed ->
                onSaveCustomDomains(blocked, allowed)
                showDomainsDialog = false
            }
        )
    }
}

@Composable
private fun FloatingSliderRow(
    label: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(text = valueLabel, color = palette.fg, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = palette.fg,
                activeTrackColor = palette.fg,
                inactiveTrackColor = palette.border.copy(alpha = 0.35f)
            )
        )
    }
}

@Composable
private fun SectionHeader(title: String) {
    val palette = LocalMovieLinkPalette.current
    Text(
        text = title,
        color = palette.fg,
        fontSize = 13.5.sp,
        fontWeight = FontWeight.ExtraBold
    )
}

@Composable
private fun SettingsSubpageEntryRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .border(1.dp, palette.boxBorder.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = palette.fg,
            modifier = Modifier.size(20.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
            Text(text = subtitle, color = palette.textSecondary, fontSize = 11.5.sp)
        }
        Icon(
            imageVector = Icons.Rounded.ChevronRight,
            contentDescription = null,
            tint = palette.textSecondary,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.altBg)
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(text = title, color = palette.textPrimary, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = palette.textSecondary, fontSize = 11.5.sp, lineHeight = 15.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.onAccent,
                checkedTrackColor = palette.fg
            )
        )
    }
}

@Composable
private fun RadioChoiceRow(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) palette.boxBg else palette.altBg)
            .border(
                width = 1.dp,
                color = if (selected) palette.boxBorder else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = palette.textPrimary,
            fontSize = 12.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
        if (selected) {
            Text("Active", color = palette.fg, fontSize = 11.5.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun DomainRulesDialog(
    blockedDomains: Set<String>,
    allowedDomains: Set<String>,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    var blockedRaw by remember { mutableStateOf(blockedDomains.sorted().joinToString("\n")) }
    var allowedRaw by remember { mutableStateOf(allowedDomains.sorted().joinToString("\n")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        title = { Text("Domain Rules", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Enter one domain per line (e.g. doubleclick.net).",
                    fontSize = 12.sp,
                    color = palette.textSecondary
                )
                OutlinedTextField(
                    value = blockedRaw,
                    onValueChange = { blockedRaw = it },
                    label = { Text("Custom Blocked Domains") },
                    minLines = 3,
                    maxLines = 5,
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.fg,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = allowedRaw,
                    onValueChange = { allowedRaw = it },
                    label = { Text("Allowed / Bypass Domains") },
                    minLines = 3,
                    maxLines = 5,
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = palette.fg,
                        focusedTextColor = palette.textPrimary,
                        unfocusedTextColor = palette.textPrimary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(blockedRaw, allowedRaw) }) {
                Text("Save", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = palette.textSecondary)
            }
        }
    )
}

@Composable
fun HistoryDialog(
    items: List<HistoryItem>,
    onSelect: (HistoryItem) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Visit History (${items.size}/25)", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                if (items.isNotEmpty()) {
                    TextButton(onClick = onClear) {
                        Text("Clear", color = palette.fg, fontSize = 12.5.sp)
                    }
                }
            }
        },
        text = {
            if (items.isEmpty()) {
                Text("No recent visits yet.", color = palette.textSecondary, fontSize = 13.5.sp)
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items, key = { it.url }) { item ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.altBg)
                                .clickable {
                                    onSelect(item)
                                    onDismiss()
                                }
                                .padding(10.dp)
                        ) {
                            Text(
                                text = item.title,
                                color = palette.textPrimary,
                                fontSize = 13.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${item.url.removePrefix("https://")} · ${AppSettingsStore.formatRelativeTime(item.timestamp)}",
                                color = palette.textSecondary,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun MyListDialog(
    items: List<MyListItem>,
    onSelect: (MyListItem) -> Unit,
    onRemove: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardBg,
        titleContentColor = palette.textPrimary,
        title = { Text("My List (${items.size})", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
        text = {
            if (items.isEmpty()) {
                Text(
                    text = "Tap ＋ My List on any movie or series to save it here.",
                    color = palette.textSecondary,
                    fontSize = 13.5.sp
                )
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(items, key = { it.url }) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(palette.altBg)
                                .clickable {
                                    onSelect(item)
                                    onDismiss()
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    color = palette.textPrimary,
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.type} · ${item.language} · ${item.quality}",
                                    color = palette.textSecondary,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { onRemove(item.url) }) {
                                Icon(
                                    Icons.Rounded.Delete,
                                    contentDescription = "Remove",
                                    tint = palette.textSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = palette.fg, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TrailerDialog(
    youtubeId: String,
    title: String,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current
    val embedUrl = "https://www.youtube-nocookie.com/embed/$youtubeId?autoplay=1&rel=0&playsinline=1"
    var webRef by remember { mutableStateOf<WebView?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
                .border(1.5.dp, palette.boxBorder, RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.cardBg)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Trailer — $title",
                    color = palette.textPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    DownloadAndPlayerRouter.openExternal(context, "https://www.youtube.com/watch?v=$youtubeId")
                }) {
                    Icon(Icons.Rounded.OpenInBrowser, contentDescription = "Open in YouTube", tint = palette.fg)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = palette.textPrimary)
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(android.graphics.Color.BLACK)
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            }
                            webChromeClient = WebChromeClient()
                            loadUrl(embedUrl)
                            webRef = this
                        }
                    }
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webRef?.stopLoading()
            webRef?.destroy()
            webRef = null
        }
    }
}
