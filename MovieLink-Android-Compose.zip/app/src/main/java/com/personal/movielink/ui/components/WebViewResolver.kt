package com.personal.movielink.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.personal.movielink.AdBlocker
import com.personal.movielink.Config
import com.personal.movielink.DownloadAndPlayerRouter
import com.personal.movielink.UserSettings
import com.personal.movielink.ui.theme.LocalMovieLinkPalette
import java.io.ByteArrayInputStream

data class ResolvedDownloadHit(
    val url: String,
    val userAgent: String,
    val contentDisposition: String?,
    val mimeType: String?
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun FallbackWebViewDialog(
    initialUrl: String,
    title: String,
    settings: UserSettings,
    isCloudflareChallenge: Boolean = false,
    onCloudflareSolved: () -> Unit = {},
    onPlayUrl: (String) -> Unit,
    onDownloadDetected: (ResolvedDownloadHit) -> Unit,
    onDismiss: () -> Unit
) {
    val palette = LocalMovieLinkPalette.current
    val context = LocalContext.current
    var progress by remember { mutableIntStateOf(0) }
    var currentUrl by remember { mutableStateOf(initialUrl) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var cfNotified by remember { mutableStateOf(false) }

    val resolvedBg = remember(settings) {
        Config.resolveBg(settings.bgPresetId, settings.customBgHex)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.pageBg)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(palette.cardBg)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = palette.textPrimary)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 6.dp)
                ) {
                    Text(
                        text = if (isCloudflareChallenge) "Security Check" else title,
                        color = palette.textPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentUrl.removePrefix("https://").removePrefix("http://"),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = { onPlayUrl(currentUrl) }) {
                    Icon(
                        Icons.Rounded.PlayCircle,
                        contentDescription = "Open current URL in video player",
                        tint = palette.fg
                    )
                }

                IconButton(onClick = { webViewRef?.reload() }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Reload", tint = palette.textPrimary)
                }

                IconButton(onClick = { DownloadAndPlayerRouter.openInChrome(context, currentUrl) }) {
                    Icon(Icons.Rounded.OpenInBrowser, contentDescription = "Open in Chrome", tint = palette.textPrimary)
                }
            }

            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    color = palette.fg,
                    trackColor = palette.cardBg,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                )
            }

            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(palette.pageBg.toArgb())
                            CookieManager.getInstance().setAcceptCookie(true)
                            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                            this.settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                cacheMode = WebSettings.LOAD_DEFAULT
                                mediaPlaybackRequiresUserGesture = false
                                javaScriptCanOpenWindowsAutomatically = false
                                setSupportMultipleWindows(true)
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                userAgentString = if (settings.desktopMode) {
                                    Config.DESKTOP_USER_AGENT
                                } else {
                                    Config.MOBILE_USER_AGENT
                                }
                                useWideViewPort = settings.desktopMode
                                loadWithOverviewMode = settings.desktopMode
                            }

                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView,
                                    request: WebResourceRequest
                                ): WebResourceResponse? {
                                    return if (AdBlocker.shouldBlock(request.url, settings)) {
                                        WebResourceResponse(
                                            "text/plain",
                                            "utf-8",
                                            ByteArrayInputStream(ByteArray(0))
                                        )
                                    } else {
                                        null
                                    }
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView,
                                    request: WebResourceRequest
                                ): Boolean {
                                    val uri = request.url
                                    if (uri.scheme != "http" && uri.scheme != "https") return true
                                    if (AdBlocker.shouldBlock(uri, settings)) return true
                                    return false
                                }

                                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                                    if (!url.isNullOrBlank()) currentUrl = url
                                }

                                override fun onPageFinished(view: WebView, url: String?) {
                                    if (!url.isNullOrBlank()) currentUrl = url
                                    CookieManager.getInstance().flush()

                                    // Paint fallback WebView pages with user's chosen background color
                                    val bgHex = resolvedBg.pageHex
                                    val txtHex = if (resolvedBg.isLight) "#18181B" else "#F4F4F5"
                                    val accHex = Config.resolveTheme(settings.themePresetId, settings.customThemeHex).fgHex
                                    view.evaluateJavascript(
                                        """
                                        (function(){
                                          try {
                                            if(document.documentElement) document.documentElement.style.background='$bgHex';
                                            if(document.body) {
                                              document.body.style.background='$bgHex';
                                              document.body.style.color='$txtHex';
                                            }
                                            var st=document.getElementById('__mlbd_fallback_style');
                                            if(!st){
                                              st=document.createElement('style');
                                              st.id='__mlbd_fallback_style';
                                              (document.head||document.documentElement).appendChild(st);
                                            }
                                            st.textContent='a{color:$accHex!important;} ins,.adsbygoogle,[id*="ad_"],[class*="ad-slot"]{display:none!important;}';
                                          }catch(e){}
                                        })();
                                        """.trimIndent(),
                                        null
                                    )

                                    if (isCloudflareChallenge && !cfNotified && url != null) {
                                        view.evaluateJavascript(
                                            "(document.title||'') + ':::' + (document.body ? document.body.innerText.slice(0,200) : '')",
                                        ) { raw ->
                                            val text = raw.orEmpty().lowercase()
                                            val stillChallenge = text.contains("just a moment") ||
                                                text.contains("checking your browser") ||
                                                text.contains("attention required")
                                            if (!stillChallenge) {
                                                cfNotified = true
                                                onCloudflareSolved()
                                            }
                                        }
                                    }
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onCreateWindow(
                                    v: WebView,
                                    isDialog: Boolean,
                                    isUserGesture: Boolean,
                                    resultMsg: Message?
                                ): Boolean {
                                    if (settings.adBlockEnabled) return false
                                    return super.onCreateWindow(v, isDialog, isUserGesture, resultMsg)
                                }

                                override fun onProgressChanged(view: WebView, newProgress: Int) {
                                    progress = newProgress
                                }
                            }

                            setDownloadListener { url, ua, cd, mime, _ ->
                                onDownloadDetected(ResolvedDownloadHit(url, ua, cd, mime))
                            }

                            loadUrl(initialUrl)
                            webViewRef = this
                        }
                    }
                )
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.stopLoading()
            webViewRef?.destroy()
            webViewRef = null
        }
    }
}
